<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	if(isset($_GET['discount_id'])){
		$discount_id = $_GET['discount_id'];
		$editdiscount = get_discount($discount_id);
	}

	$discount_content = "";
	$notif_comment = "has updated a post on discounts.";
	$posted_time = date('Y-m-d h:ia');

	if(isset($_POST['submit']))
	{
		$discount_content = trim($_POST['discount_content']);

		add_notification($user_id, $notif_comment, $posted_time);
		edit_discount($discount_id, $discount_content);
		header('Location: discounts.php');
	}
?>
<div class="container">
	<div class="thumbnail">
		<form method="post">
			<input type="hidden" name="user_id" value="<?php echo htmlentities($editdiscount['user_id']); ?>">
			<input type="hidden" name="notif_comment">

			<div class="form-group">
				<label class="control-label">Post Discount</label>
				<textarea name="discount_content" class="form-control" required><?php echo htmlentities($editdiscount['discount_content']); ?></textarea>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Edit">
				<a href="discounts.php" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
