<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	if(isset($_GET['health_id'])){
		$health_id = $_GET['health_id'];
		$edithealth = get_health($health_id);
	}

	$health_content = "";
	$notif_comment = "has updated a post on health.";
	$posted_time = date('Y-m-d h:ia');

	if(isset($_POST['submit']))
	{
		$health_content = trim($_POST['health_content']);

		add_notification($user_id, $notif_comment, $posted_time);
		edit_health($health_id, $health_content);
		header('Location: health.php');
	}
?>
<div class="container">
	<div class="thumbnail">
		<form method="post">
			<input type="hidden" name="user_id" value="<?php echo htmlentities($edithealth['user_id']); ?>">
			<input type="hidden" name="notif_comment">

			<div class="form-group">
				<label class="control-label">Post article about health</label>
				<textarea name="health_content" class="form-control" required><?php echo htmlentities($edithealth['health_content']); ?></textarea>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Edit">
				<a href="health.php" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
</div>