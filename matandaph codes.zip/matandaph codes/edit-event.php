<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	
	$event_id = $_GET['event_id'];
	$editevent = get_event($event_id);

	$notif_comment = "has updated a post on events.";
	$posted_time = date('Y-m-d h:ia');

	$event = "";
	$event_organizer = "";
	$event_description = "";
	$event_location = "";
	$event_date = "";
	$event_start = "";
	$event_end = "";

	$current_date = date('Y-m-d');
	$current_time = date('h:i A');

	if(isset($_POST['submit']))
	{
		$event = trim($_POST['event']);
		$event_organizer = trim($_POST['event_organizer']);
		$event_description = trim($_POST['event_description']);
		$event_location = trim($_POST['event_location']);
		$event_date = trim($_POST['event_date']);
		$event_start = trim($_POST['event_start']);
		$event_end = trim($_POST['event_end']);

		if($event_date < $current_date){
			$message = "<div class='alert alert-danger'><b><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> Date Invalid. You can not enter a date that is behind the current date.</b></div>";
		}
		else{
			add_notification($user_id, $notif_comment, $posted_time);
			edit_event($event_id, $event, $event_organizer, $event_description, $event_location, $event_date, $event_start, $event_end);
			header('Location: events.php');
		}

	}
?>
<div class="container">
	<div class="thumbnail">
		<?php echo $message; ?>
		<form method="post" enctype="multipart/form-data">
			<input type="text" name="user_id" value="<?php echo htmlentities($editevent['user_id']); ?>">
			<input type="hidden" name="notif_comment">

			<div class="form-group">
				<label class="control-label">Event/Activity Title</label>
				<input type="text" name="event" class="form-control" id="showform" placeholder="Enter event/activity" value="<?php echo htmlentities($editevent['event']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Event Organizer</label>
				<input type="text" name="event_organizer" class="form-control" value="<?php echo htmlentities($editevent['event_organizer']); ?>" required>
			</div>

			<div id="form">
				<div class="form-group">
					<label class="control-label">Event Details</label>
					<textarea name="event_description" class="form-control" placeholder="Enter details" required><?php echo htmlentities($editevent['event_description']); ?></textarea>
				</div>

				<div class="form-group">
					<label class="control-label">Event Location</label>
					<input type="text" name="event_location" class="form-control" placeholder="Enter location" value="<?php echo htmlentities($editevent['event_location']); ?>" required>
				</div>

				<div class="form-group">
					<label class="control-label">Date ofEvent</label>
					<input type="date" name="event_date" class="form-control" value="<?php 
						$date = date_create($editevent['event_date']);
						echo htmlentities(date_format($date, 'Y-m-d'));
					 ?>" required>
				</div>

				<div class="form-group">
					<div class="row">
						<div class="col-sm-6">
							<label class="control-label">Time Start</label>
							<input type="time" name="event_start" class="form-control" value="<?php
								$stime = date_create($editevent['event_start']);
								echo htmlentities(date_format($stime, 'H:i'));
							?>" required>
						</div>

						<div class="col-sm-6">
							<label class="control-label">Time End</label>
							<input type="time" name="event_end" class="form-control" value="<?php
								$etime = date_create($editevent['event_end']);
								echo htmlentities(date_format($etime, 'H:i'));
							?>" required>
						</div>
					</div>
				</div>

				<div class="form-group">
					<input type="submit" name="submit" class="btn btn-primary" value="Edit">
					<a href="events.php" class="btn btn-default">Cancel</a>
				</div>
			</div>
		</form>
	</div>
</div>