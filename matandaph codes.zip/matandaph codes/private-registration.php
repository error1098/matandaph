<?php
	include_once("matandaph.php");

	error_reporting( ~E_NOTICE );

	$organization = "";
	$org_address = "";
	$org_num = "";
	$org_email = "";
	$org_website = "";
	// $rep_name = "";
	// $rep_position = "";
	$username = "";
	$password = "";
	// $confirm_password = "";
	$type = "";
	$status = "";
	$message = "";

	if(isset($_POST['submit']))
	{
		$organization = trim($_POST['organization']);
		$org_address = trim($_POST['org_address']);
		$org_num = trim($_POST['org_num']);
		$org_email = trim($_POST['org_email']);
		$org_website = trim($_POST['org_website']);
		// $rep_name = trim($_POST['rep_name']);
		// $rep_position = trim($_POST['rep_position']);
		$username = trim($_POST['username']);
		$password = trim($_POST['password']);
		// $confirm_password = trim($_POST['confirm_password']);
		$type = trim($_POST['type']);
		$status = trim($_POST['status']);

		$existing_acct = find_user($organization);
		if($existing_acct){
			$message = "<div class='alert alert-danger'>Agency already exist.</div>";
		}
		else{
			add_user($organization, $org_address, $org_num, $org_email, $org_website, $username, $password, "private", "active");

			$message = "<div class='alert alert-info'>You have successfully registered.</div>";

			$organization = "";
			$org_address = "";
			$org_num = "";
			$org_email = "";
			$org_website = "";
			// $rep_name = "";
			// $rep_position = "";
			$username = "";
			$password = "";
			// $confirm_password = "";
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Private Company Registartion Form</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="css/registration.css">
	<script type="text/javascript" src="bootstrap/js/jquery.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
</head>
<body>


	<nav class="navbar navbar-default navbar-static-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigationbar">
        			<span class="icon-bar"></span>
        			<span class="icon-bar"></span>
        			<span class="icon-bar"></span> 
      			</button>
				<b><a href="index.php" class="navbar-brand">MatandaPH</a></b>
			</div>

			<ul class="nav navbar-nav navbar-right">
				<li><a href="login.php"><span class="glyphicon glyphicon-chevron-left"></span> back</a></li>
			</ul>
		</div>
	</nav>

	<div class="container">
		<div class="thumbnail">
			<div id="error"><?php echo $message; ?></div>
			<form method="post">
				<div class="form-group">
					<label class="control-label">Company Name</label>
					<input type="text" name="organization" class="form-control" value="<?php echo $organization; ?>" required>
				</div>

				<div class="form-group">
					<label class="control-label">Company Address</label>
					<input type="text" name="org_address" class="form-control" value="<?php echo $org_address; ?>" required>
				</div>

				<div class="form-group">
					<label class="control-label">Company's Contact Number</label>
					<input type="text" name="org_num" class="form-control" value="<?php echo $org_num; ?>" required>
				</div>

				<div class="form-group">
					<label class="control-label">Company's Email Address</label>(optional)
					<input type="email" name="org_email" class="form-control" value="<?php echo $org_email; ?>">
				</div>

				<div class="form-group">
					<label class="control-label">Company's Official Website</label>(optional)
					<input type="url" name="org_website" class="form-control" value="<?php echo $org_website; ?>">
				</div>

				<!-- <div class="form-group">
					<label class="control-label">Company's Representative</label>
					<input type="text" name="rep_name" placeholder="First Name Middle Initial Surname" class="form-control" value="<?php echo $rep_name; ?>" required>
				</div>

				<div class="form-group">
					<label class="control-label">Representative's Position</label>
					<input type="text" name="rep_position" class="form-control" value="<?php echo $rep_position; ?>" required>
				</div> -->

				<div class="form-group">
					<label class="control-label">Username</label>
					<input type="text" name="username" class="form-control" value="<?php echo $username; ?>" required>
				</div>

				<div class="form-group">
					<label class="control-label">Password</label>
					<input type="password" name="password" class="form-control" value="<?php echo $password; ?>" required>
				</div>

				<!-- <div class="form-group">
					<label class="control-label">Confirm Password</label>
					<input type="password" name="confirm_password" class="form-control" value="<?php echo $confirm_password; ?>" required>
				</div> -->

				<input type="hidden" name="type">
				<input type="hidden" name="status">

				<div class="form-group">
					<input type="submit" name="submit" class="btn btn-primary" value="Register">
					<input type="reset" name="" class="btn btn-default" value="Cancel">
				</div>
			</form>
		</div>
	</div>

</body>
</html>