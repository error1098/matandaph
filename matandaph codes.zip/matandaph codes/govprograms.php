<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$notif_comment = "has posted a new program.";
	$program_title = "";
	$program_description = "";
	$message = "";

	if(isset($_POST['submit']))
	{
		$user_id = trim($_POST['user_id']);
		$program_title = trim($_POST['program_title']);
		$program_description = trim($_POST['program_description']);
		$posted_time = trim($_POST['posted_time']);

		add_notification($user_id, $notif_comment, $notif_link, $posted_time);
		add_program($user_id, $program_title, $program_description, $posted_time);
		$message = "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> You have posted a program successfully!</div>";
		$program_title = "";
		$program_description = "";
	}

	$govprograms = get_all_programs();

	if(isset($_GET['program_id'])){
		$program_id = $_GET['program_id'];
		del_program($program_id);
		header('Location: govprograms.php');
	}
?>

<div class="container">
	<?php
		if(count($users)>0){
			foreach($users as $row){
				if($row['type'] == 'government' && $row['status'] == 'active'){
	?>
	<div class="thumbnail">
		<?php echo $message; ?>
		<form method="post">
			<input type="hidden" name="user_id" value="<?php echo htmlentities($row['user_id']); ?>">
			<input type="hidden" name="notif_comment">

			<div class="form-group">
				<label class="control-label">Program Title</label>
				<input type="text" name="program_title" class="form-control" placeholder="Enter title" value="<?php echo $program_title; ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Title Description</label>
				<textarea class="form-control" name="program_description" placeholder="Enter description" required><?php echo $program_description; ?></textarea>
			</div>

			<input type="hidden" name="posted_time" value="<?php echo date('Y-m-d h:ia'); ?>">

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Post">
				<input type="reset" name="" class="btn btn-default" value="Cancel">
			</div>
		</form>
	</div>
	<?php
			}
		}
	}
	?>

	<?php
		if(count($govprograms)>0){
			foreach($govprograms as $row){
	?>
	<div class="content-container">
		<div class="content">
			<?php
				if(!empty($row['profilepicture'])){
			?>
			<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b><br /><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></span>
			<?php
			}
			else{
			?>
			<span><img src="images/img_avatar3.png" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b><br /><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></span>
			<?php } ?>
			<span><b class="control-label"><?php echo htmlentities($row['program_title']); ?></b></span>
			<span><b><?php echo htmlentities($row['program_description']); ?></b></span>
		</div>

		<?php
		if($row['user_id'] == $_SESSION['user_id'] && $row['type'] == 'government'){
		?>
		<div style="border-top: 1px solid #ccc; padding-top: 5px; margin-top: 15px;">
			<a href="edit-program.php?program_id=<?php echo htmlentities($row['program_id']); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a> | <a href="govprograms.php?program_id=<?php echo htmlentities($row['program_id']); ?>" onclick="return confirm('Are you sure you want to delete this?')"><span class="glyphicon glyphicon-remove"></span> Delete</a>
		</div>
		<?php } ?>
	</div>
	<?php
		}
	}
	?>
</div>