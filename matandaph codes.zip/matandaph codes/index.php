<?php
	include_once("matandaph.php");

	date_default_timezone_set('Asia/Manila');

	if(user_islogin()){
		if($_SESSION['type'] == 'government' || $_SESSION['type'] == 'business' || $_SESSION['type'] == 'private'){
			header('Location: user-homepage.php');
			exit();
		}
		elseif($_SESSION['type'] == 'senior'){
			header('Location: senior-homepage.php');
			exit();
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome to MatandaPH</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="css/homepage-design.css">
	<link rel="stylesheet" type="text/css" href="css/content-design.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<script type="text/javascript" src="bootstrap/js/jquery.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
	<script>
		$(document).ready(function(){
		  // Add smooth scrolling to all links in navbar + footer link
		  $(".navbar a, footer a[href='#mypage']").on('click', function(event) {
		    // Make sure this.hash has a value before overriding default behavior
		    if (this.hash !== ""){
		      // Prevent default anchor click behavior
		      event.preventDefault();

		      // Store hash
		      var hash = this.hash;

		      // Using jQuery's animate() method to add smooth page scroll
		      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
		      $('html, body').animate({
		        scrollTop: $(hash).offset().top
		      }, 900, function(){
		   
		        // Add hash (#) to URL when done scrolling (default click behavior)
		        window.location.hash = hash;
		      });
		    } // End if
		  });
		});

		$(window).scroll(function() {
		 	$(".slideanim").each(function(){
			    var pos = $(this).offset().top;

			    var winTop = $(window).scrollTop();
			    if (pos < winTop + 600) {
			      $(this).addClass("slide");
			    }
		  	});
		});
	</script>
</head>
<body id="mypage" data-spy="scroll" data-target=".navbar" data-offset="60">

	<nav class="navbar navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigationbar">
        			<span class="icon-bar"></span>
        			<span class="icon-bar"></span>
        			<span class="icon-bar"></span> 
      			</button>
				<b><a href="index.php" class="navbar-brand">MatandaPH</a></b>
			</div>
			<div class="collapse navbar-collapse" id="navigationbar">
				<ul class="nav navbar-nav navbar-right">
					<li><a href="#about">ABOUT</a></li>
					<li><a href="#user-classification">USER CLASSIFICATION</a></li>
					<li><a href="#services">SERVICES</a></li>
					<li><a href="#portfolio">PORTFOLIO</a></li>
					<li><a href="#team">THE TEAM</a></li>
					<li>
						<a href="login.php"><span class="glyphicon glyphicon-log-in"></span> LOG IN</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

	<div class="jumbotron text-center">
		<h1>Welcome to <b id="title"><u>MatandaPH</u></b></h1>
		<h2><u>A Web Portal for Philippine Senior Citizens</u></h2>
	</div>

	<div id="about" class="container-fluid">
		<div class="row">
			<div class="col-sm-8">
				<h2>ABOUT</h2>
				<p id="inform"><b style="font-family: 'Lucida Handwriting'; color: #668cff !important;">MatandaPH</b> is a web-based portal for Philippine senior citizens. We provide important updates and information to all senior citizens residing in the Philippines. Information like a senior's discout and privileges, events and activities that are intended for them, government services where they can benifit from, job oppurtunities to those who still wants to work for living, and all government programs that are intended for a senior citizen. These informations are provided by the Government, Business Establishments, and Private-Owned Companies. MatandaPH is like an online bulletin where senior citizens can find all the information that are specifically for them.</p>
			</div>
			<div class="col-sm-4 text-center">
				<span class="glyphicon glyphicon-info-sign logo slideanim"></span>
			</div>
		</div>
	</div>

	<div id="user-classification" class="container-fluid bg-grey text-center">
		<h1>USER CLASSIFICATION</h1>
		<br>
		<div class="row slideanim">
			<div class="col-sm-6">
				<span class="glyphicon glyphicon-user logo-small"></span>
				<h4>SENIOR CITIZENS</h4>
			</div>

			<div class="col-sm-6">
				<span class="glyphicon glyphicon-briefcase logo-small"></span>
				<h4>GOVERNMENT</h4>
			</div>
		</div>

		<div class="row slide">
			<div class="col-sm-6">
				<span class="glyphicon glyphicon-shopping-cart logo-small"></span>
				<h4>BUSINESS ESTABLISHMENTS</h4>
			</div>

			<div class="col-sm-6">
				<span class="glyphicon glyphicon-certificate logo-small"></span>
				<h4>PRIVATE COMPANIES</h4>
			</div>
		</div>
	</div>

	<div id="services" class="container-fluid text-center">
		<h1>SERVICES</h1>
		<div class="row slideanim">
			<div class="col-sm-4">
				<span class="glyphicon glyphicon-tags logo-small"></span>
				<h4>DISCOUNTS</h4>
			</div>

			<div class="col-sm-4">
				<span class="glyphicon glyphicon-tent logo-small"></span>
				<h4>EVENTS</h4>
			</div>

			<div class="col-sm-4">
				<span class="glyphicon glyphicon-usd logo-small"></span>
				<h4>JOBS</h4>
			</div>
		</div>

		<div class="row slideanim">
			<div class="col-sm-6">
				<span class="glyphicon glyphicon-heart logo-small"></span>
				<h4>SERVICES</h4>
			</div>

			<div class="col-sm-6">
				<span class="glyphicon glyphicon-folder-open logo-small"></span>
				<h4>GOVERNMENT PROGRAMS</h4>
			</div>
		</div>
	</div>

	<div id="portfolio" class="container-fluid bg-grey text-center">
		<h1>PORTFOLIO</h1>	
		<div class="row slideanim">
			<div class="col-sm-3">
				<div class="img-thumbnail">
					<img src="seniors/senior1.jpg" height="200" width="100%">
				</div>
			</div>

			<div class="col-sm-3">
				<div class="img-thumbnail">
					<img src="seniors/senior3.jpg" height="200" width="100%">
				</div>
			</div>

			<div class="col-sm-3">
				<div class="img-thumbnail">
					<img src="seniors/senior5.jpg" height="200" width="100%">
				</div>
			</div>

			<div class="col-sm-3">
				<div class="img-thumbnail">
					<img src="seniors/senior6.jpg" height="200" width="100%">
				</div>
			</div>
		</div>

		<div class="row slideanim">
			<div class="col-sm-3">
				<div class="img-thumbnail">
					<img src="seniors/senior7.jpg" height="200" width="100%">
				</div>
			</div>

			<div class="col-sm-3">
				<div class="img-thumbnail">
					<img src="seniors/senior2.jpg" height="200" width="100%">
				</div>
			</div>

			<div class="col-sm-3">
				<div class="img-thumbnail">
					<img src="seniors/senior4.jpg" height="200" width="100%">
				</div>
			</div>

			<div class="col-sm-3">
				<div class="img-thumbnail">
					<img src="seniors/senior9.jpg" height="200" width="100%">
				</div>
			</div>
		</div>
	</div>

	<footer id="team" class="container-fluid text-center">
		<a href="#mypage" title="To Top">
		    <span class="glyphicon glyphicon-chevron-up"></span>
		 </a>

		 <h1>THE TEAM</h1>

		 <div class="row slideanim">
		 	<div class="col-sm-4">
		 		<div class="card">
		 			<img src="team/benn.jpg" width="100%">
		 			<div class="team-name"><h3>Benn Rico D. Sungahid</h3></div>
		 			<div class="team-title"><h4>HIPSTER</h4></div>
		 			<div class="team-school"><h4>University of Cebu-Main Campus</h4></div>
		 		</div>
		 	</div>

		 	<div class="col-sm-4">
		 		<div class="card">
		 			<img src="team/concord.jpg" width="100%">
		 			<div class="team-name"><h3>Concord Jr. T. Badayos</h3></div>
		 			<div class="team-title"><h4>HUSTLER</h4></div>
		 			<div class="team-school"><h4>University of Cebu-Main Campus</h4></div>
		 		</div>
		 	</div>

		 	<div class="col-sm-4">
		 		<div class="card">
		 			<img src="team/victor.jpg" width="100%">
		 			<div class="team-name"><h3>Victor A. Alicaya Jr.</h3></div>
		 			<div class="team-title"><h4>HACKER</h4></div>
		 			<div class="team-school"><h4>University of Cebu-Main Campus</h4></div>
		 		</div>
		 	</div>
		 </div>
	</footer>

</body>
</html>