<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$notif_comment = "has posted a new service.";
	$service = "";
	$service_offer = "";
	$service_location = "";
	$message = "";

	$current_date = date('Y-m-d');
	$current_time = date('h:i A');

	if(isset($_POST['submit']))
	{
		$user_id = trim($_POST['user_id']);
		$service = trim($_POST['service']);
		$service_offer = trim($_POST['service_offer']);
		$service_date = trim($_POST['service_date']);
		$service_start = trim($_POST['service_start']);
		$service_end = trim($_POST['service_end']);
		$service_location = trim($_POST['service_location']);
		$posted_time = trim($_POST['posted_time']);

		$existing_date = find_date_service($service_date);
		if($existing_date){
			$message = "<div class='alert alert-danger'><b><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> Date Invalid. A service has been scheduled on the date that you have entered. Please try another date.</b></div>";
		}
		elseif($service_date < $current_date){
			$message = "<div class='alert alert-danger'><b><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> Date Invalid. You can not enter a date that is behind the current date.</b></div>";
		}
		else{
			add_notification($user_id, $notif_comment, $posted_time);
			add_services($user_id, $service, $service_offer, $service_date, $service_start, $service_end, $service_location, $posted_time);
			$message = "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> You have posted a service/s successfully!</div>";
			$service = "";
			$service_offer = "";
			$service_date = "";
			$service_start = "";
			$service_end = "";
			$service_location = "";
		}
	}

	$services = get_all_services();

	if(isset($_GET['service_id'])){
		$service_id = $_GET['service_id'];
		del_service($service_id);
		header('Location: services.php');
	}
?>
<div class="container">
	<?php
		if(count($users)>0){
			foreach($users as $row){
	?>
	<div class="thumbnail">
		<?php echo $message; ?>
		<form method="post">
			<input type="hidden" name="user_id" value="<?php echo htmlentities($row['user_id']); ?>">
			<input type="hidden" name="notif_comment">

			<div class="form-group">
				<label class="control-label">Service Title</label>
				<input type="text" name="service" class="form-control" id="showform" placeholder="Enter service title" value="<?php echo $service; ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Service/s Offer</label>
				<textarea name="service_offer" class="form-control" placeholder="Enter service/s" required><?php echo $service_offer; ?></textarea>
			</div>

			<div id="form">
				<div class="form-group">
					<label class="control-label">Date of Availability</label>
					<input type="date" name="service_date" class="form-control" required>
				</div>

				<div class="form-group">
					<label class="control-label">Time of Availability</label>
					<div class="row">
						<div class="col-sm-6">
							From <input type="time" name="service_start" class="form-control" required>
						</div>

						<div class="col-sm-6">
							To <input type="time" name="service_end" class="form-control" required>
						</div>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label">Service Location</label>
					<input type="text" name="service_location" class="form-control" placeholder="Enter location" value="<?php echo $service_location; ?>" required>
				</div>

				<input type="hidden" name="posted_time" value="<?php echo date('Y-m-d h:ia'); ?>">

				<div class="form-group">
					<input type="submit" name="submit" class="btn btn-primary" value="Post">
					<input type="reset" name="" class="btn btn-default" id="hideform" value="Cancel">
				</div>
			</div>
		</form>
	</div>
	<?php
		}
	}
	?>

	<?php
		if(count($services)>0){
			foreach($services as $row){
	?>
	<div class="content-container">
		<div class="content">
			<?php
				if(!empty($row['profilepicture'])){
			?>
			<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b><br /><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></span>
			<?php
			}
			else{
			?>
			<span><img src="images/img_avatar3.png" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b><br /><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></span>
			<?php } ?>
			<span><b><?php echo htmlentities($row['service']); ?></b></span>
			<span>Services Offered: <br /> <b><?php echo htmlentities($row['service_offer']); ?></b></span>

			<span>Service Date: <b><?php
				$date=date_create($row['service_date']);
				echo htmlentities(date_format($date, "F d, Y, l"));
				echo " from ";
				$stime=date_create($row['service_start']);
				echo htmlentities(date_format($stime, "h:i A"));
				echo " to ";
				$etime=date_create($row['service_end']);
				echo htmlentities(date_format($etime, "h:i A"));
				echo " to be held at ";
				echo htmlentities($row['service_location']); 
			?></b></span>

			<?php
				if($row['service_date'] < $current_date){
			?>
			<div style="color: red;">Service Done</div>
			<?php } ?>

		</div>

		<?php
		if($row['user_id'] == $_SESSION['user_id'] && $row['type'] == 'government'){
		?>
		<div style="border-top: 1px solid #ccc; padding-top: 5px;">
			<a href="edit-service.php?service_id=<?php echo htmlentities($row['service_id']); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a> | <a href="services.php?service_id=<?php echo htmlentities($row['service_id']); ?>" onclick="return confirm('Are you sure you want to delete this?')"><span class="glyphicon glyphicon-remove"></span> Delete</a> | <a href="service-acquire-list.php?service_id=<?php echo htmlentities($row['service_id']); ?>"><span class="glyphicon glyphicon-list-alt"></span> List of Acquirees</a>
		</div>
		<?php } ?>

	</div>
	<?php
		}
	}
	?>
</div>

<script>
	$(document).ready(function(){
		$("#form").hide();
		$("#showform").click(function(){
			$("#form").slideDown();
		});

		$("#hideform").click(function(){
			$("#form").slideUp();
		});
	});
</script>