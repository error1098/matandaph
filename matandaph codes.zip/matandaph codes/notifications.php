<?php
	include_once("header3.php");

	$notifications = get_all_notification();
	edit_notification();
?>
<div class="container">
	<div class="page-header">
		<h3>Notifications</h3>
	</div>
	<ul class="list-group">
		<?php
			if(count($notifications)>0){
				foreach($notifications as $row){
		?>
		<li class="list-group-item">
			<h5><span class="glyphicon glyphicon-info-sign" style="color: #668cff; margin-right: 10px;"></span>
			<b><?php echo htmlentities($row['organization']); ?></b> <?php echo htmlentities($row['notif_comment']); ?></h5>
			<p class="list-group-item-text" style="color: #ccc;">Posted on <?php 
				$date=date_create($row['posted_time']); 
				echo date_format($date, 'F d, Y h:ia'); 
			?></p>
		</li>
		<?php
			}
		}
		?>
	</ul>
</div>