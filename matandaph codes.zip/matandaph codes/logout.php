<?php
	include_once("matandaph.php");

	user_logout();
	header('Location: index.php');
	exit();
?>