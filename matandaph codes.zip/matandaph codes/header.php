<?php
	include_once("matandaph.php");

	error_reporting( ~E_NOTICE );

	date_default_timezone_set('Asia/Manila');

	$type = $_SESSION['type'];
	$status = $_SESSION['status'];

	$user_id = $_SESSION['user_id'];
	$users = get_users($user_id);

	$user = $_SESSION['username'];
	if(isset($_SESSION[$user]))
	{
		echo $user;
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome to MatandaPH</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="css/landingpage-design.css">
	<link rel="stylesheet" type="text/css" href="css/content-design.css">
	<script type="text/javascript" src="bootstrap/js/jquery.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
	<script type="text/javascript" src="css/jquery-3.1.1.min.js"></script>
</head>
<body>

	<nav class="navbar navbar-default navbar-static-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigationbar">
        			<span class="icon-bar"></span>
        			<span class="icon-bar"></span>
        			<span class="icon-bar"></span> 
      			</button>
				<b><a href="user-homepage.php" class="navbar-brand">MatandaPH</a></b>
			</div>
			<div class="collapse navbar-collapse" id="navigationbar">
				<?php if(user_islogin()){ ?>
				<ul class="nav navbar-nav">
					<li><a href="discounts.php">DISCOUNTS</a></li>
					<li><a href="events.php">EVENTS</a></li>
					<li><a href="jobs.php">JOBS</a></li>
					<li><a href="services.php">SERVICES</a></li>
					<li><a href="govprograms.php">GOVERNMENT PROGRAMS</a></li>
					<li><a href="health.php">HEALTH</a></li>
					<li><a href="seniorlaw.php">SENIOR'S LAW</a></li>
				</ul>
				
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<?php echo $user; ?> <span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<?php
							if(count($users)>0){
								foreach($users as $row){
							?>
							<li>
								<a href="user-profile.php?user_id=<?php echo htmlentities($row['user_id'])?>type=<?php echo htmlentities($row['type']); ?>"><span class="glyphicon glyphicon-user"></span> Profile</a>
							</li>
							<?php
								}
							}
							?>
							<li>
								<a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
							</li>
						</ul>
					</li>
				</ul>
			<?php } ?>
			</div>
		</div>
	</nav>

</body>
</html>