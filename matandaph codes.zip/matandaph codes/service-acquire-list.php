<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Locaition: login.php');
		exit();
	}

	$service_id = $_GET['service_id'];
	$acquirelist = service_acquire_list($service_id);
?>
<div class="container">
	<div class="thumbnail">
		<h3>List of Senior Citizens who registered the service.</h3>
		<table class="table table-bordered table-striped table-hover table-condensed table-responsive">
			<tr class="info">
				<td>Service</td>
				<td>Date and Time of Service</td>
				<td>Service Location</td>
				<td>Participat's Senior Citizen ID</td>
				<td>Name of Participant</td>
				<td>Age</td>
				<td>Address</td>
				<td>Date and Time of Registration</td>
			</tr>

			<?php
				if(count($acquirelist)>0){
					foreach($acquirelist as $row){
			?>
			<tr>
				<td>
					<?php echo htmlentities($row['service']); ?>
				</td>
				<td>
					<?php
						$date=date_create($row['service_date']);
						echo date_format($date, 'l, F d, Y');
						echo " from ";
						$stime=date_create($row['service_start']);
						echo date_format($stime, 'h:ia');
						echo " to ";
						$etime=date_create($row['service_end']);
						echo date_format($etime, 'h:ia');
					?>
				</td>
				<td>
					<?php echo htmlentities($row['service_location']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['seniorid']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['fname']." ".$row['mname']." ".$row['lname']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['age']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['sitio']." ".$row['baranggay'].", ".$row['city']); ?>
				</td>
				<td>
					<?php 
						$date=date_create($row['acquired_time']);
						echo date_format($date, 'l F d, Y h:ia');
					?>
				</td>
			</tr>
			<?php
				}
			}
			else{
			?>
			<tr>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
			</tr>
			<?php } ?>
		</table>
	</div>
</div>