<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$discounts = get_all_discounts();
	$events = get_all_events();
	$jobs = get_all_jobs();
	$services = get_all_services();
	$govprograms = get_all_programs();
	$healths = get_all_healths();
	$seniorlaw = get_all_senior_law();
?>
<div class="container">
	<div class="row">
		<div class="col-sm-5">
			<div class="thumbnail">
				<?php
					if(count($users)>0){
						foreach($users as $row){
				?>
				<div class="media">
					<div class="media-left">
					<?php
					if(!empty($row['profilepicture'])){
					?>
					<img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" width="150" height="150">
					<?php
					}
					else{
					?>
					<img src="images/img_avatar3.png" width="170" height="180">
					<?php } ?>
					<h5><a href="user-profile-edit.php?user_id=<?php echo htmlentities($row['user_id']) ?>type=<?php echo htmlentities($row['type']); ?>">Edit Profile</a></h5>
					</div>

					<div class="media-body">
						<h5 class="media-heading"><?php echo htmlentities($row['organization']); ?></h5>
						<h5 class="media-heading"><?php echo htmlentities($row['org_address']); ?></h5>
						<h5 class="media-heading"><?php echo htmlentities($row['org_num']); ?></h5>
						<h5 class="media-heading"><?php echo htmlentities($row['org_email']); ?></h5>
						<h5 class="media-heading"><a href="<?php echo htmlentities($row['org_website']); ?>"><?php echo htmlentities($row['org_website']); ?></a></h5>
						<h5 class="media-heading">
							<u><?php echo htmlentities($row['rep_name']); ?></u>
							<br />
							<i><?php echo htmlentities($row['rep_position']); ?></i>
						</h5>
					</div>
				</div>
				<?php
					}
				}
				?>
			</div>

			<div class="panel panel-primary">
				<div class="panel-heading">
					<label>Government Programs for Senior Citizens</label>
				</div>
	
				<?php
					if(count($govprograms)){
						foreach($govprograms as $row){
				?>
				<ul>
					<li><a href="#"><?php echo htmlentities($row['program_title']); ?></a></li>
				</ul>
				<?php
					}
				}
				?>
			</div>

			<div class="panel panel-primary">
				<div class="panel-heading">
					<p><b>DATE & TIME <span class="glyphicon glyphicon-hourglass"></span></b></p>
				</div>
				<div class="panel-body">
					<div class="text-center"><b><?php echo date('l, F d, Y'); ?></b> <span class="text-center" id="time"></span></div>
					<canvas id="canvas" width="200" height="200" style="background-color:#333; margin-left: 26%;"></canvas>
				</div>
			</div>
		</div>

		<div class="col-sm-7">
			<div class="thumbnail">
				<?php
					if(count($discounts)>0){
						foreach($discounts as $row){
				?>
				<div class="thumbnail">
					<div class="media">
						<div class="media-left">
							<?php
							if(!empty($row['profilepicture'])){
							?>
							<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"></span>
							<?php
							}
							else{
							?>
							<span><img src="images/img_avatar3.png" class="profile-pic"></span>
							<?php } ?>
						</div>

						<div class="media-body">
							<h4 class="media-heading"> <span><b><?php echo htmlentities($row['organization']); ?></b></span></h4>
							<p><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></p>
							<b><p class="media-content"><?php echo htmlentities($row['discount_content']); ?></p></b>
						</div>
					</div>
				</div>
				<?php
					}
				}
				?>

				<?php
					if(count($events)>0){
						foreach($events as $row){
				?>
				<div class="thumbnail">
					<div class="media">
						<div class="media-left">
							<?php
							if(!empty($row['profilepicture'])){
							?>
							<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"></span>
							<?php
							}
							else{
							?>
							<span><img src="images/img_avatar3.png" class="profile-pic"></span>
							<?php } ?>
						</div>

						<div class="media-body">
							<h4 class="media-heading"> <span><b><?php echo htmlentities($row['organization']); ?></b></span></h4>
							<p><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></p>
							<b><p class="media-content"><?php echo htmlentities($row['event']); ?></p>
							<p class="media-content"><?php echo htmlentities($row['event_description']);  echo " on ";
							$date=date_create($row['event_date']);
							echo date_format($date, "F d, Y, l");
							echo " from ";
							$stime=date_create($row['event_start']);
							echo date_format($stime, "h:i A");
							echo " to ";
							$etime=date_create($row['event_end']);
							echo date_format($etime, "h:i A"); 
							echo " at ";
							echo htmlentities($row['event_location']);
							?>
						</p></b>
					</div>
				</div>
			</div>
			<?php
				}
			}
			?>

			<?php
				if(count($jobs)>0){
					foreach($jobs as $row){
			?>
			<div class="thumbnail">
				<div class="media">
					<div class="media-left">
						<?php
						if(!empty($row['profilepicture'])){
						?>
						<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"></span>
						<?php
						}
						else{
						?>
						<span><img src="images/img_avatar3.png" class="profile-pic"></span>
						<?php } ?>
					</div>

					<div class="media-body">
						<h4 class="media-heading"> <span><b><?php echo htmlentities($row['organization']); ?></b></span></h4>
						<p><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></p>
						<b><p class="media-content"><?php echo htmlentities($row['company_name']) ?> is currently looking for <?php echo htmlentities($row['job_title']) ?></p>
						<p class="media-content">Job Descriptions/Qualifications:<br /><?php echo htmlentities($row['job_description']); ?></p>
						<p class="media-content">Job Location: <?php echo htmlentities($row['job_location']); ?></p></b>
						<span><b>You can visit our office located at <?php echo htmlentities($row['office_location']); ?> from <?php echo htmlentities($row['office_time']); ?> every <?php echo htmlentities($row['office_day']); ?></b></span>
					</div>
				</div>
			</div>
			<?php
				}
			}
			?>

			<?php
				if(count($services)>0){
					foreach($services as $row){
			?>
			<div class="thumbnail">
				<div class="media">
					<div class="media-left">
						<?php
						if(!empty($row['profilepicture'])){
						?>
						<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"></span>
						<?php
						}
						else{
						?>
						<span><img src="images/img_avatar3.png" class="profile-pic"></span>
						<?php } ?>
					</div>

					<div class="media-body">
						<h4 class="media-heading"> <span><b><?php echo htmlentities($row['organization']); ?></b></span></h4>
						<p><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></p>
						<b><p class="media-content">Service/s Offered:<br /><?php echo htmlentities($row['service_offer']); ?></p>
						<p class="media-content">Service/s Schedule: <?php
							$date=date_create($row['service_date']);
							echo htmlentities(date_format($date, "F d, Y, l"));
							echo " from ";
							$stime=date_create($row['service_start']);
							echo htmlentities(date_format($stime, "h:i A"));
							echo " to ";
							$etime=date_create($row['service_end']);
							echo htmlentities(date_format($etime, "h:i A"));
							echo " to be held at ";
							echo htmlentities($row['service_location']); 
						?></p></b>
					</div>
				</div>
			</div>
			<?php
				}
			}
			?>
			
			<?php
				if(count($healths)>0){
					foreach($healths as $row){
			?>
			<div class="thumbnail">
				<div class="media">
					<div class="media-left">
						<?php
						if(!empty($row['profilepicture'])){
						?>
						<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"></span>
						<?php
						}
						else{
						?>
						<span><img src="images/img_avatar3.png" class="profile-pic"></span>
						<?php } ?>
					</div>

					<div class="media-body">
						<h4 class="media-heading"> <span><b><?php echo htmlentities($row['organization']); ?></b></span></h4>
						<p><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></p>
						<p class="media-content"><b><?php echo htmlentities($row['health_content']); ?></b></p>
					</div>
				</div>
			</div>
			<?php
				}
			}
			?>

			<?php
				if(count($seniorlaw)>0){
					foreach($seniorlaw as $row){
			?>
			<div class="thumbnail">
				<div class="media">
					<div class="media-left">
						<?php
						if(!empty($row['profilepicture'])){
						?>
						<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"></span>
						<?php
						}
						else{
						?>
						<span><img src="images/img_avatar3.png" class="profile-pic"></span>
						<?php } ?>
					</div>

					<div class="media-body">
						<h4 class="media-heading"> <span><b><?php echo htmlentities($row['organization']); ?></b></span></h4>
						<p><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></p>
						<p class="media-content"><b><?php echo htmlentities($row['law_title']); ?></b></p>
						<p class="media-content"><b><?php echo htmlentities($row['law_content']); ?></b></p>
					</div>
				</div>
			</div>
			<?php
				}
			}
			?>
		</div>
	</div>
	</div>
</div>

<footer>
	<div class="container">
		<b>All Rights Reserve &copy; 2016-<?php echo date('Y'); ?></b>
	</div>
</footer>

<script>
	// $(document).ready(function(){
	// 	$("#drop").hide();
	// 	$("#toggle").click(function(){
	// 		$("#drop").slideDown(function(){
	// 			$("#toggle").hide();
	// 		});
	// 	});
	// });
	var canvas = document.getElementById("canvas");
	var ctx = canvas.getContext("2d");
	var radius = canvas.height / 2;
	ctx.translate(radius, radius);
	radius = radius * 0.90
	//drawClock();
	setInterval(drawClock, 1000);

	function drawClock() {
	    ctx.arc(0, 0, radius, 0 , 2*Math.PI);
	    ctx.fillStyle = "white";
	    ctx.fill();
	    drawFace(ctx, radius);
	    drawNumbers(ctx, radius);
	    drawTime(ctx, radius);
	}

	function drawFace(ctx, radius) {
	    var grad;

	    ctx.beginPath();
	    ctx.arc(0, 0, radius, 0, 2*Math.PI);
	    ctx.fillStyle = 'white';
	    ctx.fill();

	    grad = ctx.createRadialGradient(0,0,radius*0.95, 0,0,radius*1.05);
	    grad.addColorStop(0, '#333');
	    grad.addColorStop(0.5, 'white');
	    grad.addColorStop(1, '#333');
	    ctx.strokeStyle = grad;
	    ctx.lineWidth = radius*0.1;
	    ctx.stroke();

	    ctx.beginPath();
	    ctx.arc(0, 0, radius*0.1, 0, 2*Math.PI);
	    ctx.fillStyle = '#333';
	    ctx.fill();
	}

	function drawNumbers(ctx, radius) {
	    var ang;
	    var num;
	    ctx.font = radius*0.15 + "px arial";
	    ctx.textBaseline="middle";
	    ctx.textAlign="center";
	    for(num= 1; num < 13; num++){
	        ang = num * Math.PI / 6;
	        ctx.rotate(ang);
	        ctx.translate(0, -radius*0.85);
	        ctx.rotate(-ang);
	        ctx.fillText(num.toString(), 0, 0);
	        ctx.rotate(ang);
	        ctx.translate(0, radius*0.85);
	        ctx.rotate(-ang);
	    }
	}

	function drawTime(ctx, radius){
	    var now = new Date();
	    var hour = now.getHours();
	    var minute = now.getMinutes();
	    var second = now.getSeconds();
	    //hour
	    hour=hour%12;
	    hour=(hour*Math.PI/6)+(minute*Math.PI/(6*60))+(second*Math.PI/(360*60));
	    drawHand(ctx, hour, radius*0.5, radius*0.07);
	    //minute
	    minute=(minute*Math.PI/30)+(second*Math.PI/(30*60));
	    drawHand(ctx, minute, radius*0.8, radius*0.07);
	    // second
	    second=(second*Math.PI/30);
	    drawHand(ctx, second, radius*0.9, radius*0.02);
	}

	function drawHand(ctx, pos, length, width) {
	    ctx.beginPath();
	    ctx.lineWidth = width;
	    ctx.lineCap = "round";
	    ctx.moveTo(0,0);
	    ctx.rotate(pos);
	    ctx.lineTo(0, -length);
	    ctx.stroke();
	    ctx.rotate(-pos);
	}

	var x = setInterval(function() {

	    // var hr = new Date().getHours() % 2;
	    // var min = new Date().getMinutes() % 10;
	    // var sec = new Date().getSeconds();
	   
	    var time = new Date();
	    var today = time.toLocaleTimeString();
	    
	    // Output the result in an element with id="demo"
	    document.getElementById("time").innerHTML = "<b>" + today + "</b>";

	}, 1000);
</script>