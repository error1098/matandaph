<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	if(isset($_GET['user_id'])){
		$user_id = $_GET['user_id'];
		$edituser = get_user($user_id);
		extract($edituser);
	}

	$organization = "";
	$org_address = "";
	$org_num = "";
	$org_email = "";
	$org_website = "";
	// $rep_name = "";
	// $rep_position = "";
	$password = "";
	$message = "";

	if(isset($_POST['submit']))
	{
		$organization = trim($_POST['organization']);
		$org_address = trim($_POST['org_address']);
		$org_num = trim($_POST['org_num']);
		$org_email = trim($_POST['org_email']);
		$org_website = trim($_POST['org_website']);
		// $rep_name = trim($_POST['rep_name']);
		// $rep_position = trim($_POST['rep_position']);
		$password = trim($_POST['password']);

		$profilepicture = $_FILES['profilepicture']['name'];
		$tmp_dir = $_FILES['profilepicture']['tmp_name'];

		if($profilepicture){
			$upload_dir = 'profilepictures/';
			$imgext = strtolower(pathinfo($profilepicture, PATHINFO_EXTENSION));
			$valid_extensions = array('jpeg', 'jpg', 'png');
			$profilepic = rand(1000,10000).".".$imgext;

			if(in_array($imgext, $valid_extensions)){
				//unlink($upload_dir.$editprofilegov['picture']);
				move_uploaded_file($tmp_dir, $upload_dir.$profilepic);
			}
			else{
				$message = "<div class='alert alert-danger'>Sorry, but only JPEG, JPG or PNG files are allowed.</div>";
			}
		}
		else{
			$profilepic = $edituser['profilepicture'];
		}

		edit_user_profile($user_id, $organization, $org_address, $org_num, $org_email, $org_website, $profilepic, $password);
		?>
		<script>
			window.location.href="user-profile.php?user_id=<?php echo $user_id ?>type=<?php echo $type; ?>"
		</script>
		<?php
	}
?>
<div class="container">
	<?php
	if($type == 'government' && $status == 'active'){
	?>
	<div class="thumbnail">
		<div id="error"><?php echo $message; ?></div>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label class="control-label">Select Profile Picture</label>
				<input type="file" name="profilepicture" id="profilepicture" accept="image/*">
			</div>

			<div class="form-group">
				<label class="control-label">Agency Name</label>
				<input type="text" name="organization" class="form-control" value="<?php echo htmlentities($edituser['organization']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Agency Address</label>
				<input type="text" name="org_address" class="form-control" value="<?php echo htmlentities($edituser['org_address']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Agency Contact Number</label>
				<input type="text" name="org_num" class="form-control" value="<?php echo htmlentities($edituser['org_num']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Agency Email Address</label>(optional)
				<input type="email" name="org_email" class="form-control" value="<?php echo htmlentities($edituser['org_email']); ?>">
			</div>

			<div class="form-group">
				<label class="control-label">Agency Official Website</label>(optional)
				<input type="url" name="org_website" class="form-control" value="<?php echo htmlentities($edituser['org_website']); ?>">
			</div>

			<!-- <div class="form-group">
				<label class="control-label">Agency's Representative</label>
				<input type="text" name="rep_name" class="form-control" value="<?php echo htmlentities($edituser['rep_name']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Representative's Position</label>
				<input type="text" name="rep_position" class="form-control" value="<?php echo htmlentities($edituser['rep_position']); ?>" required>
			</div> -->

			<div class="form-group">
				<label class="control-label">Username</label>
				<input type="text" name="username" class="form-control" value="<?php echo htmlentities($edituser['username']); ?>" readonly>
			</div>

			<div class="form-group">
				<label class="control-label">Password</label>
				<input type="password" name="password" class="form-control" value="<?php echo htmlentities($edituser['password']); ?>" required>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Edit">
				<a href="user-profile.php?user_id=<?php echo htmlentities($edituser['user_id']) ?>type=<?php echo htmlentities($edituser['type']) ?>" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
	<?php
	}
	elseif($type == 'private' && $status == 'active'){
	?>
	<div class="thumbnail">
		<div id="error"><?php echo $message; ?></div>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label class="control-label">Select Profile Picture</label>
				<input type="file" name="profilepicture" id="profilepicture" accept="image/*">
			</div>

			<div class="form-group">
				<label class="control-label">Company Name</label>
				<input type="text" name="organization" class="form-control" value="<?php echo htmlentities($edituser['organization']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Company Address</label>
				<input type="text" name="org_address" class="form-control" value="<?php echo htmlentities($edituser['org_address']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Company's Contact Number</label>
				<input type="text" name="org_num" class="form-control" value="<?php echo htmlentities($edituser['org_num']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Company's Email Address</label>(optional)
				<input type="email" name="org_email" class="form-control" value="<?php echo htmlentities($edituser['org_email']); ?>">
			</div>

			<div class="form-group">
				<label class="control-label">Company's Official Website</label>(optional)
				<input type="url" name="org_website" class="form-control" value="<?php echo htmlentities($edituser['org_website']); ?>">
			</div>

			<!-- <div class="form-group">
				<label class="control-label">Company's Representative</label>
				<input type="text" name="rep_name" class="form-control" value="<?php echo htmlentities($edituser['rep_name']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Representative's Position</label>
				<input type="text" name="rep_position" class="form-control" value="<?php echo htmlentities($edituser['rep_position']); ?>" required>
			</div> -->

			<div class="form-group">
				<label class="control-label">Username</label>
				<input type="text" name="username" class="form-control" value="<?php echo htmlentities($edituser['username']); ?>" readonly>
			</div>

			<div class="form-group">
				<label class="control-label">Password</label>
				<input type="password" name="password" class="form-control" value="<?php echo htmlentities($edituser['password']); ?>" required>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Edit">
				<a href="user-profile.php?user_id=<?php echo htmlentities($edituser['user_id']) ?>type=<?php echo htmlentities($edituser['type']) ?>" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
	<?php
	}
	elseif($type == 'business' && $status == 'active'){
	?>
	<div class="thumbnail">
		<div id="error"><?php echo $message; ?></div>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label class="control-label">Select Profile Picture</label>
				<input type="file" name="profilepicture" id="profilepicture" accept="image/*">
			</div>

			<div class="form-group">
				<label class="control-label">Business Name</label>
				<input type="text" name="organization" class="form-control" value="<?php echo htmlentities($edituser['organization']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Business Address</label>
				<input type="text" name="org_address" class="form-control" value="<?php echo htmlentities($edituser['org_address']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Business's Contact Number</label>
				<input type="text" name="org_num" class="form-control" value="<?php echo htmlentities($edituser['org_num']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Business's Email Address</label>(optional)
				<input type="email" name="org_email" class="form-control" value="<?php echo htmlentities($edituser['org_email']); ?>">
			</div>

			<div class="form-group">
				<label class="control-label">Business's Official Website</label>(optional)
				<input type="url" name="org_website" class="form-control" value="<?php echo htmlentities($edituser['org_website']); ?>">
			</div>

			<!-- <div class="form-group">
				<label class="control-label">Business's Representative</label>
				<input type="text" name="rep_name" class="form-control" value="<?php echo htmlentities($edituser['rep_name']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Representative's Position</label>
				<input type="text" name="rep_position" class="form-control" value="<?php echo htmlentities($edituser['rep_position']); ?>" required>
			</div> -->

			<div class="form-group">
				<label class="control-label">Username</label>
				<input type="text" name="username" class="form-control" value="<?php echo htmlentities($edituser['username']); ?>" readonly>
			</div>

			<div class="form-group">
				<label class="control-label">Password</label>
				<input type="password" name="password" class="form-control" value="<?php echo htmlentities($edituser['password']); ?>" required>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Edit">
				<a href="user-profile.php?user_id=<?php echo htmlentities($edituser['user_id']) ?>type=<?php echo htmlentities($edituser['type']) ?>" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
	<?php
	}
	elseif($type == 'health' && $status == 'active'){
	?>
	<div class="thumbnail">
		<div id="error"><?php echo $message; ?></div>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label class="control-label">Select Profile Picture</label>
				<input type="file" name="profilepicture" id="profilepicture" accept="image/*">
			</div>

			<div class="form-group">
				<label class="control-label">Organization Name</label>
				<input type="text" name="organization" class="form-control" value="<?php echo htmlentities($edituser['organization']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Organization Address</label>
				<input type="text" name="org_address" class="form-control" value="<?php echo htmlentities($edituser['org_address']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Organization's Contact Number</label>
				<input type="text" name="org_num" class="form-control" value="<?php echo htmlentities($edituser['org_num']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Organization's Email Address</label>(optional)
				<input type="email" name="org_email" class="form-control" value="<?php echo htmlentities($edituser['org_email']); ?>">
			</div>

			<div class="form-group">
				<label class="control-label">Organization's Official Website</label>(optional)
				<input type="url" name="org_website" class="form-control" value="<?php echo htmlentities($edituser['org_website']); ?>">
			</div>

			<!-- <div class="form-group">
				<label class="control-label">Organization's Representative</label>
				<input type="text" name="rep_name" class="form-control" value="<?php echo htmlentities($edituser['rep_name']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Representative's Position</label>
				<input type="text" name="rep_position" class="form-control" value="<?php echo htmlentities($edituser['rep_position']); ?>" required>
			</div> -->

			<div class="form-group">
				<label class="control-label">Username</label>
				<input type="text" name="username" class="form-control" value="<?php echo htmlentities($edituser['username']); ?>" readonly>
			</div>

			<div class="form-group">
				<label class="control-label">Password</label>
				<input type="password" name="password" class="form-control" value="<?php echo htmlentities($edituser['password']); ?>" required>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Edit">
				<a href="user-profile.php?user_id=<?php echo htmlentities($edituser['user_id']) ?>type=<?php echo htmlentities($edituser['type']) ?>" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
	<?php
	}
	elseif($type == 'insurance' && $status == 'active'){
	?>
	<div class="thumbnail">
		<div id="error"><?php echo $message; ?></div>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label class="control-label">Select Profile Picture</label>
				<input type="file" name="profilepicture" id="profilepicture" accept="image/*">
			</div>

			<div class="form-group">
				<label class="control-label">Insurance Name</label>
				<input type="text" name="organization" class="form-control" value="<?php echo htmlentities($edituser['organization']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Insurance Address</label>
				<input type="text" name="org_address" class="form-control" value="<?php echo htmlentities($edituser['org_address']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Insurance's Contact Number</label>
				<input type="text" name="org_num" class="form-control" value="<?php echo htmlentities($edituser['org_num']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Insurance's Email Address</label>(optional)
				<input type="email" name="org_email" class="form-control" value="<?php echo htmlentities($edituser['org_email']); ?>">
			</div>

			<div class="form-group">
				<label class="control-label">Insurance's Official Website</label>(optional)
				<input type="url" name="org_website" class="form-control" value="<?php echo htmlentities($edituser['org_website']); ?>">
			</div>

			<!-- <div class="form-group">
				<label class="control-label">Insurance's Representative</label>
				<input type="text" name="rep_name" class="form-control" value="<?php echo htmlentities($edituser['rep_name']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Representative's Position</label>
				<input type="text" name="rep_position" class="form-control" value="<?php echo htmlentities($edituser['rep_position']); ?>" required>
			</div> -->

			<div class="form-group">
				<label class="control-label">Username</label>
				<input type="text" name="username" class="form-control" value="<?php echo htmlentities($edituser['username']); ?>" readonly>
			</div>

			<div class="form-group">
				<label class="control-label">Password</label>
				<input type="password" name="password" class="form-control" value="<?php echo htmlentities($edituser['password']); ?>" required>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Edit">
				<a href="user-profile.php?user_id=<?php echo htmlentities($edituser['user_id']) ?>type=<?php echo htmlentities($edituser['type']) ?>" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
	<?php } ?>
</div>