<!DOCTYPE html>
<html>
<head>
	<title>Registration Selection Page</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="css/registration-design.css">
	<script type="text/javascript" src="bootstrap/js/jquery.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
</head>
<body>

	<nav class="navbar navbar-default navbar-static-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigationbar">
        			<span class="icon-bar"></span>
        			<span class="icon-bar"></span>
        			<span class="icon-bar"></span> 
      			</button>
				<b><a href="index.php" class="navbar-brand">MatandaPH</a></b>
			</div>

			<ul class="nav navbar-nav navbar-right">
				<li><a href="login.php"><span class="glyphicon glyphicon-chevron-left"></span> back</a></li>
			</ul>
		</div>
	</nav>

	<div class="container">
		<div class="row">
			<div class="col-sm-6">
				<div class="thumbnail">
					<div class="container-fluid">
						<h4 class="text-center">Senior Citizen</h4>
						<img src="images/senior3.jpg" width="100%" height="500" class="img-rounded">
						<p id="picture-margin">
							<a href="senior-registration.php" class="btn btn-primary btn-block">Register as Senior Citizen</a>
						</p>
					</div>
				</div>
			</div>

			<div class="col-sm-6">
				<div class="thumbnail">
					<div class="container-fluid">
						<h4 class="text-center">Government</h4>
						<img src="images/img_avatar3.png" width="100%" height="500" class="img-rounded">
						<p id="picture-margin">
							<a href="government-registration.php" class="btn btn-primary btn-block">Register as Government</a>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-sm-6">
				<div class="thumbnail">
					<div class="container-fluid">
						<h4 class="text-center">Business Establishment</h4>
						<img src="images/img_avatar3.png" width="100%" height="500" class="img-rounded">
						<p id="picture-margin">
							<a href="business-registration.php" class="btn btn-primary btn-block">Register as Business Establishment</a>
						</p>
					</div>
				</div>
			</div>

			<div class="col-sm-6">
				<div class="thumbnail">
					<div class="container-fluid">
						<h4 class="text-center">Private Company</h4>
						<img src="images/img_avatar3.png" width="100%" height="500" class="img-rounded">
						<p id="picture-margin">
							<a href="private-registration.php" class="btn btn-primary btn-block">Register as Job Company</a>
						</p>
					</div>
				</div>
			</div>

			<!-- <div class="col-sm-4">
				<div class="thumbnail">
					<div class="container-fluid">
						<h4 class="text-center">Health Organization</h4>
						<img src="images/img_avatar3.png" width="100%" height="250" class="img-rounded">
						<p id="picture-margin">
							<a href="health-registration.php" class="btn btn-primary btn-block">Register as Health Organization</a>
						</p>
					</div>
				</div>
			</div>

			<div class="col-sm-4">
				<div class="thumbnail">
					<div class="container-fluid">
						<h4 class="text-center">Insurance Company</h4>
						<img src="images/img_avatar3.png" width="100%" height="250" class="img-rounded">
						<p id="picture-margin">
							<a href="insurance-registration.php" class="btn btn-primary btn-block">Register as Insurance Company</a>
						</p>
					</div>
				</div>
			</div> -->
		</div>
	</div>

</body>
</html>