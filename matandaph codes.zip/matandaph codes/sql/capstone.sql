-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2017 at 02:52 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `capstone`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `discounts`
--

CREATE TABLE `discounts` (
  `discount_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `discount_content` mediumtext NOT NULL,
  `posted_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `discounts`
--

INSERT INTO `discounts` (`discount_id`, `user_id`, `discount_content`, `posted_time`) VALUES
(6, 7, '20% discounts on medical and drug purchases, medical supplies and medical privileges', '2017-09-29 07:38pm'),
(9, 5, 'DISCOUNTS\r\n-20% discount on:\r\n-Medical-related privileges\r\n-Medicine and drug purchases\r\n-Medical supplies, accessories and equipment\r\n-Medical and dental services\r\n-Professional fees of attending physician\r\n-Professional fees of licensed health workers providing home health care services\r\nTransportation\r\n-Air and Sea\r\n-Land: LRT, MRT, PNR, buses, jeepneys, taxi and shuttle services\r\nHotels, restaurants, recreational facilities, places of leisure\r\n-Hotels, restaurants, theaters, cinemas, concert halls, circuses, leisure and amusement\r\nRecreation centers\r\n-Fees, charges and rental for sports facilities and equipment\r\nFuneral services\r\n-Funeral and burial expenses include casket or urn, embalming, cremation cost, and other services.\r\nUtility discount\r\n-Grant of a minimum of 5% discount relative to the monthly use of water and electricity, provided that the meter is registered under the name of the senior citizen residing therein and does not exceed 100 kWh and 30 mÂ³.\r\nEXEMPTIONS\r\n-Tax exemption\r\n-Exemption from payment of individual income tax of those who are considered to be minimum wage earners\r\n-Training fee exemption\r\n-Training fees for socio-economic programs conducted by private and government agencies subject to the guidelines issued by DTI, DOLE, DA, TESDA and DOST-TRC.\r\nFREEBIES\r\n-Free medical and dental services\r\n-Free vaccinations', '2017-10-02 09:43am'),
(10, 8, '20% senior citizen discounts and 12% value-added tax(VAT) exemption on domestic flights on both office and online ticket transactions and booking.\r\nTo obtain the discount after you book online, you just have to bring to the airport check-in counter a senior citizen'' ID in combination with a Philippine passport or any government-issued ID indication your birth date, such as a driver''s licence, voter''s ID, SSS/GSIS ID, PRC card or Postal ID.', '2017-10-02 01:42pm');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event` varchar(255) NOT NULL,
  `event_organizer` varchar(255) NOT NULL,
  `event_description` mediumtext NOT NULL,
  `event_location` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `event_start` varchar(255) NOT NULL,
  `event_end` varchar(255) NOT NULL,
  `posted_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `user_id`, `event`, `event_organizer`, `event_description`, `event_location`, `event_date`, `event_start`, `event_end`, `posted_time`) VALUES
(8, 5, 'Senior Citizen''s Giving of Cash Assistance', 'Office of the Senior Citizens Affair', 'Giving of 1,000 pesos cash assistance to all senior citizens in Cebu city', 'Barangay Basak San Nicolas, Don Vicente Rama Memorial School, Cebu City', '2017-10-02', '08:00', '17:00', '2017-09-29 08:39pm'),
(9, 5, 'Senior Citizen Halloween Party', 'Office of the Senior Citizens Affair', 'A Halloween party to all senior citizens in Cebu City', 'New Cebu Coliseum', '2017-11-02', '18:00', '20:00', '2017-09-29 08:47pm'),
(11, 5, 'Senior Citizen Halloween Party', 'Office of the Senior Citizens Affair', 'A Christmas Party to all Senior Citizens in Cebu City', 'New Cebu Coliseum', '2017-12-20', '16:00', '18:00', '2017-10-02 01:42pm');

-- --------------------------------------------------------

--
-- Table structure for table `event_join`
--

CREATE TABLE `event_join` (
  `join_id` int(11) NOT NULL,
  `senior_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `join_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_join`
--

INSERT INTO `event_join` (`join_id`, `senior_id`, `event_id`, `join_time`) VALUES
(2, 16, 9, '2017-09-30 02:47pm'),
(3, 18, 8, '2017-09-30 02:59pm');

-- --------------------------------------------------------

--
-- Table structure for table `govprograms`
--

CREATE TABLE `govprograms` (
  `program_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `program_title` varchar(255) NOT NULL,
  `program_description` mediumtext NOT NULL,
  `posted_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `govprograms`
--

INSERT INTO `govprograms` (`program_id`, `user_id`, `program_title`, `program_description`, `posted_time`) VALUES
(7, 6, 'Health Development Program', 'Identify the needs, trainings, and opportunities of senior citizens in the cities and municipalities;chan robles virtual law library\r\nInitiate, develop and implement productive activities and work schemes for senior citizens in order to provide income or otherwise supplement their earnings in the local community;\r\nPromote and maintain linkages with provincial government units and other instrumentalities of government and the city and municipal councils for the elderly and the Federation of Senior Citizens Association of the Philippines and other non-government organizations for the delivery of health care services, facilities, professional advice services, volunteer training and community self-help projects; and\r\nTo exercise such other functions which are necessary to carry out the purpose for which the centers are established.', '2017-09-29 07:16pm'),
(8, 11, 'Program for the Elderly, Disabled Persons and Special Groups', 'Promotion of Disability prevention and rehabilitation of the physically, mentally, and socially disabled persons.\r\nServices:\r\n-Information Discrimination on Disability Prevention (IDDP)\r\n-Assistance for Physical Restoration\r\n-Self/ Social Enhancement for Disabled/Elderly\r\n-Social/ Vocational Preparation for employment Services\r\n-Special Social Services for the Elderly\r\n-Special Social Services for the Mendicants\r\n-After Care and Follow-up Services', '2017-09-29 09:14pm'),
(9, 5, 'Cebu City Call Center Program', 'Focuses on the formulation of program of actions that will help enhance program related to BPO, serve as a liaison between the BPO companies and the City Government, assist BPO agents with their concerns, conduct activities and initiatives that will benefit both the City and the BPO industry, establish a training mechanism that would increase the chances of BPO applicants of being hired and give inputs, advises, suggestions as well as render opinion on project proposals & the implementation of the City Governmentâ€™s programs related to BPO.', '2017-09-29 09:36pm'),
(12, 5, 'Long Life Program', 'Improves quality of life for people in the remote barangays who no longer have to travel far to get their maintenance medicines, lowers public hospital costs by lessening the number of sick people, and provides a means of livelihood for the out of school youth the city hires to deliver the medicines.', '2017-10-02 11:14am'),
(13, 11, 'Social Pension Program', 'Indigent senior citizens shall be entitled to a monthly stipend amounting to Five hundred pesos (Php 500.00) to augment the daily subsistence and other medical needs of senior citizens.', '2017-10-02 01:46pm');

-- --------------------------------------------------------

--
-- Table structure for table `gov_admin`
--

CREATE TABLE `gov_admin` (
  `govadmin_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gov_admin`
--

INSERT INTO `gov_admin` (`govadmin_id`, `username`, `password`) VALUES
(1, 'admin', 'abcd1234');

-- --------------------------------------------------------

--
-- Table structure for table `healths`
--

CREATE TABLE `healths` (
  `health_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `health_content` mediumtext NOT NULL,
  `posted_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `healths`
--

INSERT INTO `healths` (`health_id`, `user_id`, `health_content`, `posted_time`) VALUES
(6, 6, 'Alzheimerâ€™s Disease is one of the biggest concerns many of us have as we get older. While you may have been told that all you can do is hope for the best and wait for a pharmaceutical cure, the truth is much more encouraging. Promising research shows that you can reduce your risk of Alzheimerâ€™s and other dementias through a combination of simple but effective lifestyle changes. By leading a brain-healthy lifestyle, you may be able to prevent the symptoms of Alzheimerâ€™s disease and slow down, or even reverse, the process of deterioration.\r\nWhat are the best ways to reduce the risk of Alzheimer''s?\r\nThe thought of developing Alzheimer''s disease as you get older can be a frightening prospect, especially if youâ€™ve witnessed a loved one affected by the disease. Researchers across the world are racing towards a cure, but as prevalence rates climb, their focus has broadened from treatment to prevention strategies. What theyâ€™ve discovered is that it may be possible to prevent or delay the symptoms of Alzheimerâ€™s disease and other dementias through a combination of healthy habits.\r\nBy identifying and controlling your personal risk factors, you can maximize your chances of lifelong brain health and take effective steps to preserve your cognitive abilities.\r\nThe 6 pillars for reducing your risk\r\nAlzheimer''s is a complex disease with multiple risk factors. Some, like your age and genetics, are outside your control. However, there are six pillars for a brain-healthy lifestyle that are within your control.\r\nThe more you strengthen each of the six pillars in your daily life, the longerâ€”and strongerâ€”your brain will stay working.\r\n\r\nPillar #1: Regular exercise\r\nAccording to the Alzheimerâ€™s Research & Prevention Foundation, regular physical exercise can reduce your risk of developing Alzheimerâ€™s disease by up to 50 percent. Whatâ€™s more, exercise can also slow further deterioration in those who have already started to develop cognitive problems. Exercise protects against Alzheimerâ€™s by stimulating the brainâ€™s ability to maintain old connections as well as make new ones.\r\nAim for at least 150 minutes of moderate intensity exercise each week. The ideal plan involves a combination of cardio exercise and strength training. Good activities for beginners include walking and swimming.\r\nBuild muscle to pump up your brain. Moderate levels of weight and resistance training not only increase muscle mass, they help you maintain brain health. For those over 65, adding 2-3 strength sessions to your weekly routine may cut your risk of Alzheimerâ€™s in half.\r\nInclude balance and coordination exercises. Head injuries from falls are an increasing risk as you age, which in turn increase your risk for Alzheimerâ€™s disease and dementia. Balance and coordination exercises can help you stay agile and avoid spills. Try yoga, Tai Chi, or exercises using balance balls.\r\nTips for starting and sticking with an exercise plan\r\nProtect your head\r\nHead trauma at any point in life may increase your risk of Alzheimerâ€™s disease. This includes repeated hits in sports activities such as football, soccer, and boxing, or one-time injuries from a bicycle, skating, or motorcycle accident. Protect your brain by wearing properly fitting sports helmets and trip-proofing your environment as you exercise. Avoid activities that compete for your attentionâ€”like talking on your cell while walking or cycling.\r\nIf youâ€™ve been inactive for a while, starting an exercise program can be intimidating. But remember: a little exercise is better than none. In fact, adding just modest amounts of physical activity to your weekly routine can have a profound effect on your health. Choose activities you enjoy and start smallâ€”a 10-minute walk a few times a day, for exampleâ€”and allow yourself to gradually build up your momentum and self-confidence. It takes about 28 days for a new routine to become habit, so do your best to stick with it for a month and soon your exercise routine will feel natural, even something you miss if you skip a session.\r\n\r\nPillar #2: Social engagement\r\nHuman beings are highly social creatures. We donâ€™t thrive in isolation, and neither do our brains. Staying socially engaged may even protect against Alzheimerâ€™s disease and dementia in later life, so make developing and maintaining a strong network of friends a priority.\r\nYou donâ€™t need to be a social butterfly or the life of the party, but you do need to regularly connect face-to-face with someone who cares about you and makes you feel heard. While many of us become more isolated as we get older, itâ€™s never too late to meet others and develop new friendships:\r\nâ€¢	Volunteer\r\nâ€¢	Join a club or social group\r\nâ€¢	Visit your local community center or senior center\r\nâ€¢	Take group classes (such as at the gym or a community college)\r\nâ€¢	Reach out over the phone or email\r\nâ€¢	Connect to others via social networks such as Facebook\r\nâ€¢	Get to know your neighbors\r\nâ€¢	Make a weekly date with friends\r\nâ€¢	Get out (go to the movies, the park, museums, and other public places)\r\n\r\nPillar #3: Healthy diet\r\nIn Alzheimerâ€™s disease, inflammation and insulin resistance injure neurons and inhibit communication between brain cells. Alzheimerâ€™s is sometimes described as â€œdiabetes of the brain,â€ and a growing body of research suggests a strong link between metabolic disorders and the signal processing systems. By adjusting your eating habits, however, you can help reduce inflammation and protect your brain.\r\nHealthy eating tips\r\nCut down on sugar. Sugary foods and refined carbs such as white flour, white rice, and pasta can lead to dramatic spikes in blood sugar which inflame your brain. Watch out for hidden sugar in all kinds of packaged foods from cereals and bread to pasta sauce and low or no-fat products.\r\nEnjoy a Mediterranean diet. Several epidemiological studies show that eating a Mediterranean diet dramatically reduces the risk of cognitive imapairment and Alzheimer''s disease. That means plenty of vegetables, beans, whole grains, fish and olive oilâ€”and limited processed food.\r\nAvoid trans fats.These fats can cause inflammation and produce free radicalsâ€”both of which are hard on the brain. Reduce your consumption by avoiding fast food, fried and packaged foods, and anything that contains â€œpartially hydrogenated oils,â€ even if it claims to be trans fat-free.\r\nGet plenty of omega-3 fats. Evidence suggests that the DHA found in these healthy fats may help prevent Alzheimer''s disease and dementia by reducing beta-amyloid plaques. Food sources include cold-water fish such as salmon, tuna, trout, mackerel, seaweed, and sardines. You can also supplement with fish oil.\r\nStock up on fruit and vegetables. When it comes to fruits and vegetables, the more the better. Eat up across the color spectrum to maximize protective antioxidants and vitamins, including green leafy vegetables, berries, and cruciferous vegetables such as broccoli.\r\nEnjoy daily cups of tea. Regular consumption of great tea may enhance memmory and mental alertness and slow brain aging. White and oolong teas are also particularly brain healthy. Drinking 2-4 cups daily has proven benefits. Although not as powerful as tea, coffee also confers brain benefits.\r\nCook at home often. By cooking at home, you can ensure that you''re eating fresh, wholesome meals that are high in brain-healthy nutrients and low in sugar, salt, unhealthy fat, and additives.\r\nSupplements that may help prevent dementia\r\nFolic acid, vitamin B12, vitamin D, magnesium, and fish oil may help to preserve brain health. Studies of vitamin E, ginkgo biloba, coenzyme Q10, and turmeric have yielded less conclusive results, but may also be beneficial in preventing or delaying Alzheimerâ€™s and dementia symptoms.\r\nAlways talk to your doctor about possible medication interactions.\r\n\r\nPillar #4: Mental stimulation\r\nThose who continue learning new things throughout life and challenging their brains are less likely to develop Alzheimerâ€™s disease and dementia. In essence, you need to â€œuse it or lose it.â€ In the groundbreaking NIH ACTIVE study, older adults who received as few as 10 sessions of mental training not only improved their cognitive functioning in daily activities in the months after the training, but continued to show long-lasting improvements 10 years later.\r\nActivities involving multiple tasks or requiring communication, interaction, and organization offer the greatest protection. Set aside time each day to stimulate your brain:\r\nLearn something new. Study a foreign language, practice a musical instrument, read the newspaper or a good book, or take up a new hobby. The greater the novelty and challenge, the greater the benefit.\r\nPractice memorization. Start with something short, progressing to something a little more involved, such as the 50 U.S. state capitals. Create rhymes and patterns to strengthen your memory connections.\r\nEnjoy strategy games, puzzles, and riddles. Brain teasers and strategy games provide a great mental workout and build your capacity to form and retain cognitive associations. Do a crossword puzzle, play board games, cards, or word and number games such as Scrabble or Sudoku.\r\nPractice the 5 Wâ€™s. Observe and report like a crime detective. Keep a â€œWho, What, Where, When, and Whyâ€ list of your daily experiences. Capturing visual details keeps your neurons firing.\r\nFollow the road less traveled. Take a new route, eat with your non-dominant hand, rearrange your computer file system. Vary your habits regularly to create new brain pathways.\r\n\r\nPillar #5: Quality sleep\r\nItâ€™s common for people with Alzheimerâ€™s disease to suffer from insomnia and other sleep problems. But new research suggests that disrupted sleep isnâ€™t just a symptom of Alzheimerâ€™s, but a possible risk factor. An increasing number of studies have linked poor sleep to higher levels of beta-amyloid, a sticky brain-clogging protein that in turn further interferes with sleepâ€”especially with the deep sleep necessary for memory formation. Other studies emphasize the importance of uninterrupted sleep for flushing out brain toxins.\r\nIf nightly sleep deprivation is slowing your thinking and affecting your mood, you may be at greater risk of developing symptoms of Alzheimerâ€™s disease. The vast majority of adults need at least 8 hours of sleep per night.\r\nSleep tips\r\nGet screened for sleep apnea. If you''ve received complaints about your snoring, you may want to get tested for sleep apnea, a potentially dangerous condition where breathing is disrupted during sleep. Treatment can make a huge difference in both your health and sleep quality.\r\nEstablish a regular sleep schedule. Going to bed and getting up at the same time reinforces your natural circadian rhythms. Your brain''s clock responds to regularity.\r\nBe smart about napping. While taking a nap can be a great way to recharge, especially for older adults, it can make insomnia worse. If insomnia is a problem for you, consider eliminating napping. If you must nap, do it in the early afternoon, and limit it to thirty minutes.\r\nSet the mood. Reserve your bed for sleep and sex, and ban television and computers from the bedroom (both are stimulating and may lead to difficulties falling asleep).\r\nCreate a relaxing bedtime ritual. Take a hot bath, do some light stretches, write in your journal, or dim the lights. As it becomes habit, your nightly ritual will send a powerful signal to your brain that it''s time for deep restorative sleep.\r\nQuiet your inner chatter. When stress, anxiety, or negative internal dialogues keep you awake, get out of bed. Try reading or relaxing in another room for twenty minutes then hop back in.\r\n\r\nPillar #6: Stress management\r\nChronic or persistent stress can take a heavy toll on the brain, leading to shrinkage in a key memory area, hampering nerve cell growth, and increasing the risk of Alzheimerâ€™s disease and dementia. Yet simple stress management tools can minimize its harmful effects.\r\nGet your stress levels in check with these proven techniques\r\nBreathe! Quiet your stress response with deep, abdominal breathing. Restorative breathing is powerful, simple, and free!\r\nSchedule daily relaxation activities. Keeping stress under control requires regular effort. Make relaxation a priority, whether itâ€™s a walk in the park, playtime with your dog, yoga, or a soothing bath.\r\nNourish inner peace. Regular meditation, prayer, reflection, and religious practice may immunize you against the damaging effects of stress.\r\nMake fun a priority. All work and no play is not good for your stress levels or your brain. Make time for leisure activities that bring you joy, whether it be stargazing, playing the piano, or working on your bike.\r\nKeep your sense of humor. This includes the ability to laugh at yourself. The act of laughing helps your body fight stress.\r\nOther tips to reduce the risk of Alzheimer''s\r\nJust as whatâ€™s good for the body is also good for the brain, so too is the converse: whatâ€™s bad for the body is bad for the brain.\r\nStop smoking. Smoking is one of the most preventable risk factors for Alzheimerâ€™s disease. One study found that smokers over the age of 65 have a nearly 80% higher risk of Alzheimerâ€™s than those who have never smoked. When you stop smoking, the brain benefits from improved circulation almost immediately.\r\nControl blood pressure and cholesterol levels. Both high blood pressure and high total cholesterol are associated with an increased risk of Alzheimerâ€™s disease and vascular dementia. Improving those numbers are good for your brain as well as your heart.\r\nWatch your weight. Extra pounds are a risk factor for Alzheimerâ€™s disease and other types of dementia. A major study found that people who were overweight in midlife were twice as likely to develop Alzheimerâ€™s down the line, and those who were obese had three times the risk. Losing weight can go a long way to protecting your brain.\r\nDrink only in moderation. While there appear to be brain benefits in consuming red wine in moderation, heavy alcohol consumption can dramatically raise the risk of Alzheimerâ€™s and accelerate brain aging.', '2017-10-02 01:47pm');

-- --------------------------------------------------------

--
-- Table structure for table `insurances`
--

CREATE TABLE `insurances` (
  `insurance_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `insurance_content` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `insurances`
--

INSERT INTO `insurances` (`insurance_id`, `user_id`, `insurance_content`) VALUES
(1, 1, 'Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `job_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `job_description` mediumtext NOT NULL,
  `job_location` varchar(255) NOT NULL,
  `office_location` varchar(255) NOT NULL,
  `office_time` varchar(255) NOT NULL,
  `office_day` varchar(255) NOT NULL,
  `posted_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`job_id`, `user_id`, `company_name`, `job_title`, `job_description`, `job_location`, `office_location`, `office_time`, `office_day`, `posted_time`) VALUES
(4, 10, 'Azpired, Inc.', 'Call Center Agents', 'Urgent Hiring: One Day Process Only\r\n200 CUSTOMER SERVICE REPRESENTATIVE(CSR)\r\n200 TECHNICAL SUPPORT REPRESENTATIVE(TSR)\r\nQUALIFICATION:\r\n-At least 18 and above\r\n-At least High School Graduate\r\nPLEAS BRING YOUR UPDATED RESUME', 'Cebu Business Park', '16th Floor, Cebu IT Tower 2, Cebu Business Park', '24 hours (24/7)', 'Monday-Sunday', '2017-09-29 08:27pm'),
(5, 9, 'Eperformax', 'Call Center Agents', 'URGENT HIRING\r\n100 CUSTOMER SERVICE REPRESENTATIVE(CSR)\r\nQUALIFICATIONS\r\n-At least 18 years old and above\r\n-At least high school graduate\r\n-Good communication skills', 'JY Square IT Center 1 Salinas Drive 3/F, Lahug, Cebu City', 'JY Square IT Center 1 Salinas Drive 3/F, Lahug, Cebu City', '9:00am-6:00pm', 'Monday-Saturday', '2017-09-29 08:33pm'),
(6, 12, 'City Traffic Management Office', 'Traffic Enforcers', 'Qualifications\r\n- At least 30 years old and above\r\n- At least physically healthy', 'N. Bacalso Ave.', 'N. Bacalso St. Cebu City', '8:00am-8:00pm', 'Monday-Friday', '2017-09-30 08:18am'),
(8, 5, 'Office of the Senior Citizens Affair', 'Street Sweeper', 'Qualifications\r\n- At least 30 years old and above\r\n- At least physically healthy', 'Plaza Independencia', '5th Floor Cebu City Hall, Magallanes St. Cebu Cit', '8:00am-8:00pm', 'Monday-Friday', '2017-10-02 01:43pm');

-- --------------------------------------------------------

--
-- Table structure for table `job_apply`
--

CREATE TABLE `job_apply` (
  `apply_id` int(11) NOT NULL,
  `senior_id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `applied_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_apply`
--

INSERT INTO `job_apply` (`apply_id`, `senior_id`, `job_id`, `applied_time`) VALUES
(2, 18, 6, '2017-09-30 02:59pm'),
(3, 16, 6, '2017-10-01 03:45pm');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `notif_comment` varchar(255) NOT NULL,
  `posted_time` varchar(255) NOT NULL,
  `notif_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `user_id`, `notif_comment`, `posted_time`, `notif_status`) VALUES
(9, 8, 'has posted a new discount.', '2017-10-02 01:42pm', 1),
(10, 5, 'has posted a new event.', '2017-10-02 01:42pm', 1),
(11, 5, 'has posted a new job opening.', '2017-10-02 01:43pm', 1),
(12, 11, 'has posted a new service.', '2017-10-02 01:45pm', 1),
(13, 11, 'has posted a new program.', '2017-10-02 01:46pm', 1),
(14, 6, 'has posted a new health article.', '2017-10-02 01:47pm', 1),
(15, 5, 'has posted a new law.', '2017-10-02 01:47pm', 1),
(16, 5, 'has updated a post on discounts.', '2017-10-02 04:11pm', 1),
(17, 5, 'has updated a post on discounts.', '2017-10-02 04:11pm', 1),
(18, 5, 'has updated a post on events.', '2017-10-02 04:16pm', 1),
(19, 10, 'has updated a post on jobs.', '2017-10-02 04:20pm', 1),
(20, 11, 'has updated a post on services.', '2017-10-02 04:29pm', 1),
(21, 6, 'has updated a post on government programs.', '2017-10-02 04:32pm', 1),
(22, 6, 'has updated a post on health.', '2017-10-02 04:36pm', 1),
(23, 5, 'has updated a post on senior''s law.', '2017-10-02 04:39pm', 1),
(24, 5, 'has posted a new discount.', '2017-10-03 03:02pm', 1),
(25, 6, 'has updated a post on health.', '2017-10-04 09:24am', 1),
(26, 6, 'has updated a post on health.', '2017-10-04 09:24am', 1),
(27, 5, 'has updated a post on senior''s law.', '2017-10-04 09:38am', 1),
(28, 5, 'has updated a post on discounts.', '2017-10-06 10:05am', 1);

-- --------------------------------------------------------

--
-- Table structure for table `seniorcitizens`
--

CREATE TABLE `seniorcitizens` (
  `seniors_id` int(11) NOT NULL,
  `senior_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `date_of_birth` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `date_id_issued` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seniorcitizens`
--

INSERT INTO `seniorcitizens` (`seniors_id`, `senior_id`, `name`, `address`, `date_of_birth`, `gender`, `date_id_issued`) VALUES
(1, 73306, 'Marcelina P. Vocales', 'Lawis Alaska Mambaling, Cebu City', 'October 6, 1952', 'Female', 'Febuary 2, 2013'),
(2, 62687, 'Felimon N. Conol', '150-Alaska, Puntod-Mambaling, Cebu City', 'November 18, 1951', 'Male', 'January 9, 2012'),
(3, 17274, 'Librada B. Repesa', 'Sitio Viking, Barangay Mambaling', 'January 1, 1937', 'Female', 'December 15, 2016'),
(4, 99642, 'Rogelio L. Cabrere', '526-Alaska Viking, Mabaming', 'October 1, 1954', 'Male', 'Febuary 12, 2015'),
(5, 91608, 'Angelita L. Alfornon', 'Alaska, Mambaling', 'November 7, 1954', 'Female', 'March 07, 2016');

-- --------------------------------------------------------

--
-- Table structure for table `senior_accounts`
--

CREATE TABLE `senior_accounts` (
  `senior_id` int(11) NOT NULL,
  `seniorid` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `mname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `bdate` date NOT NULL,
  `bplace` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `baranggay` varchar(255) NOT NULL,
  `sitio` varchar(255) NOT NULL,
  `medrecord` varchar(255) NOT NULL,
  `workexp` mediumtext NOT NULL,
  `contnum` varchar(255) NOT NULL,
  `seniorprofile` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `senior_accounts`
--

INSERT INTO `senior_accounts` (`senior_id`, `seniorid`, `fname`, `mname`, `lname`, `gender`, `bdate`, `bplace`, `age`, `region`, `province`, `city`, `baranggay`, `sitio`, `medrecord`, `workexp`, `contnum`, `seniorprofile`, `username`, `password`, `type`, `status`) VALUES
(9, 62687, 'Felimon', 'N.', 'Conol', 'Male', '1951-11-18', 'Alaska Mambaling, Cebu City', '65', 'Region VII', 'CEBU', 'Cebu City', 'Puntod-Mambaling', '158-Alaska', '21148339_1661390027265957_1061852466_n.jpg', 'Driver', '455-5577', '8877.jpg', 'felimon', 'abcd1234', 'senior', '1'),
(10, 15412, 'Juan', 'Dela', 'Cruz', 'Male', '1915-10-03', 'Tisa Labangon, Cebu City', '102', 'Region VII', 'CEBU', 'Cebu City', 'Labangon', 'Tisa', '4809.jpg', 'Panday', '488-5588', '4755.png', 'juan', 'abcd1234', 'senior', '1'),
(11, 13207618, 'Jhems', 'Soreno', 'Espanol', 'Male', '1996-10-09', 'Maternity Hospital', '20', 'Region VII', 'CEBU', 'Cebu City', 'West Poblacion', 'Kolera', '21076481_1681333748574709_201994908_n.png', 'Janitor', '87000', '', 'jhemsespanol', '123', 'senior', '1');

-- --------------------------------------------------------

--
-- Table structure for table `senior_law`
--

CREATE TABLE `senior_law` (
  `law_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `law_title` varchar(255) NOT NULL,
  `law_content` mediumtext NOT NULL,
  `posted_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `senior_law`
--

INSERT INTO `senior_law` (`law_id`, `user_id`, `law_title`, `law_content`, `posted_time`) VALUES
(4, 5, 'Republic Act No. 7432 otherwise known as Expanded Senior Citizens Act of 2010', 'Section 1. Title. â€“ This Act Shall be known as the â€œExpanded Senior Citizens Act of 2010.â€\r\nSec. 2. Section 1 of Republic Act No. 7432, as amended by Republic Act No. 9257, otherwise known as the â€œExpanded Senior Citizens Act of 2003â€, is hereby further amended to read as follows:\r\nâ€œSECTION 1. Declaration of Policies and Objectives. â€“ As provided in the Constitution of the Republic of the Philippines, it is the declared policy of the State to promote a just and dynamic social order that will ensure the prosperity and independence of the nation and free the people from poverty through policies that provide adequate social services, promote full employment, a rising standard of living and an improved quality of life. In the Declaration of Principles and State Policies in Article II, Sections 10 and 11, it is further declared that the State shall provide social justice in all phases of national development and that the State values the dignity of every human person and guarantees full respect for human rights.\r\nâ€œArticle XIII, Section 11 of the Constitution provides that the State shall adopt an integrated and comprehensive approach to health development which shall endeavor to make essential goods, health and other social services available to all the people at affordable cost. There shall be priority for the needs of the underprivileged, sick, elderly, disabled, women and children. Article XV, Section 4 of the Constitution Further declares that it is the duty of the family to take care of its elderly members while the State may design programs of social security for them.\r\nâ€œConsistent with these constitutional principles, this Act shall serve the following objectives:\r\nâ€œ(a) To recognize the rights of senior citizens to take their proper place in society and make it a concern of the family, community, and government;\r\nâ€œ(b) To give full support to the improvement of the total well-being of the elderly and their full participation in society, considering that senior citizens are integral part of Philippine society;\r\nâ€œ(c) To motivate and encourage the senior citizens to contribute to nation building;\r\nâ€œ(d) To encourage their families and the communities they live with to reaffirm the valued Filipino tradition of caring for the senior citizens;\r\nâ€œ(e) To provide a comprehensive health care and rehabilitation system for disabled senior citizens to foster their capacity to attain a more meaningful and productive ageing; and\r\nâ€œ(f) To recognize the important role of the private sector in the improvement of the welfare of senior citizens and to actively seek their partnership.\r\nâ€œIn accordance with these objectives, this Act shall:\r\nâ€œ(1) establish mechanisms whereby the contributions of the senior citizens are maximized;\r\nâ€œ(2) adopt measures whereby our senior citizens are assisted and appreciated by the community as a whole;\r\nâ€œ(3) establish a program beneficial to the senior citizens, their families and the rest of the community they serve: and\r\nâ€œ(4) establish community-based health and rehabilitation programs for senior citizens in every political unit of society.â€\r\nSec. 3. Section 2 of Republic Act No. 7432, as amended by Republic Act No. 9257, otherwise known as the Expanded Senior Citizens Act of 2003â€³, is hereby further amended to read as follows:\r\nSEC. 2. Definition of terms. â€“ For purposes of this Act, these terms are defined as follows:\r\nâ€œ(a) Senior citizen or elderly refers to any resident citizen of the Philippines at least sixty (60) years old;\r\nâ€œ(b) Geriatrics refer to the branch of medical science devoted to the study of the biological and physical changes and the diseases of old age;\r\nâ€œ(c) Lodging establishment refers to a building, edifice, structure, apartment or house including tourist inn, apartelle, motorist hotel, and pension house engaged in catering, leasing or providing facilities to transients, tourists or travelers;\r\nâ€œ(d) Medical Services refer to hospital services, professional services of physicians and other health care professionals and diagnostics and laboratory tests that the necessary for the diagnosis or treatment of an illness or injury;\r\nâ€œ(e) Dental services to oral examination, cleaning, permanent and temporary filling, extractions and gum treatments, restoration, replacement or repositioning of teeth, or alteration of the alveolar or periodontium process of the maxilla and the mandible that are necessary for the diagnosis or treatment of an illness or injury;\r\nâ€œ(f) Nearest surviving relative refers to the legal spouse who survives the deceased senior citizen: Provided, That where no spouse survives the decedent, this shall be limited to relatives in the following order of degree of kinship: children, parents, siblings, grandparents, grandchildren, uncles and aunts;\r\nâ€œ(g) Home health care service refers to health or supportive care provided to the senior citizen patient at home by licensed health care professionals to include, but not limited to, physicians, nurses, midwives, physical therapist and caregivers; and\r\nâ€œ(h) Indigent senior citizen, refers to any elderly who is frail, sickly or with disability, and without pension or permanent source of income, compensation or financial assistance from his/her relatives to support his/her basic needs, as determined by the Department of Social Welfare and development (DSWD) in consultation with the National Coordinating and Monitoring Board.â€\r\nSec. 4 Section 4 of Republic Act No. 7432, as amended by Republic Act No. 9257, otherwise known as the â€œExpanded Senior Citizens Act of 2003â€, is hereby further amended to read as follows:\r\nâ€œSEC. 4. Privileges for the Senior Citizens. â€“\r\nThe senior citizens shall be entitled to the following:\r\nâ€œ(a) the grant of twenty percent (20%) discount and exemption from the value -added tax (VAT), if applicable, on the sale of the following goods and services from all establishments, for the exclusive use and enjoyment or availment of the senior citizen\r\nâ€œ(1) on the purchase of medicines, including the purchase of influenza and pnuemococcal vaccines, and such other essential medical supplies, accessories and equipment to be determined by the Department of Health (DOH).\r\nâ€œThe DOH shall establish guidelines and mechanism of compulsory rebates in the sharing of burden of discounts among retailers, manufacturers and distributors, taking into consideration their respective margins;\r\nâ€œ(2) on the professional fees of attending physician/s in all private hospitals, medical facilities, outpatient clinics and home health care services;\r\nâ€œ(3) on the professional fees of licensed professional health providing home health care services as endorsed by private hospitals or employed through home health care employment agencies;\r\nâ€œ(4) on medical and dental services, diagnostic and laboratory fees in all private hospitals, medical facilities, outpatient clinics, and home health care services, in accordance with the rules and regulations to be issued by the DOH, in coordination with the Philippine Health Insurance Corporation (PhilHealth);\r\nâ€œ(5) in actual fare for land transportation travel in public utility buses (PUBs), public utility jeepneys (PUJs), taxis, Asian utility vehicles (AUVs), shuttle services and public railways, including Light Rail Transit (LRT), Mass Rail Transit (MRT), and Philippine National Railways (PNR);\r\nâ€œ(6) in actual transportation fare for domestic air transport services and sea shipping vessels and the like, based on the actual fare and advanced booking;\r\nâ€œ(7) on the utilization of services in hotels and similar lodging establishments, restaurants and recreation centers;\r\nâ€œ(8) on admission fees charged by theaters, cinema houses and concert halls, circuses, leisure and amusement; and\r\nâ€œ(9) on funeral and burial services for the death of senior citizens;\r\nâ€œ(b) exemption from the payment of individual income taxes of senior citizens who are considered to be minimum wage earners in accordance with Republic Act No. 9504;\r\nâ€œ(c) the grant of a minimum of five percent (5%) discount relative to the monthly utilization of water and electricity supplied by the public utilities: Provided, That the individual meters for the foregoing utilities are registered in the name of the senior citizen residing therein: Provided, further, That the monthly consumption does not exceed one hundred kilowatt hours (100 kWh) of electricity and thirty cubic meters (30 m3) of water: Provided, furthermore, That the privilege is granted per household regardless of the number of senior citizens residing therein;\r\nâ€œ(d) exemption from training fees for socioeconomic programs;\r\nâ€œ(e) free medical and dental services, diagnostic and laboratory fees such as, but not limited to, x-rays, computerized tomography scans and blood tests, in all government facilities, subject to the guidelines to be issued by the DOH in coordination with the PhilHealth;\r\nâ€œ(f) the DOH shall administer free vaccination against the influenza virus and pneumococcal disease for indigent senior citizen patients;\r\nâ€œ(g) educational assistance to senior citizens to pursue pot secondary, tertiary, post tertiary, vocational and technical education, as well as short-term courses for retooling in both public and private schools through provision of scholarships, grants, financial aids, subsides and other incentives to qualified senior citizens, including support for books, learning materials, and uniform allowances, to the extent feasible: Provided, That senior citizens shall meet minimum admission requirements;\r\nâ€œ(h) to the extent practicable and feasible, the continuance of the same benefits and privileges given by the Government Service Insurance System (GSIS), the Social Security System (SSS) and the PAG-IBIG, as the case may be, as are enjoyed by those in actual service;\r\nâ€œ(i) retirement benefits of retirees from both the government and the private sector shall be regularly reviewed to ensure their continuing responsiveness and sustainability, and to the extent practicable and feasible, shall be upgraded to be at par with the current scale enjoyed by those in actual service;\r\nâ€œ(j) to the extent possible, the government may grant special discounts in special programs for senior citizens on purchase of basic commodities, subject to the guidelines to be issued for the purpose by the Department of Trade and Industry (DTI) and the Department of Agriculture (DA);\r\nâ€œ(k) provision of express lanes for senior citizens in all commercial and government establishments; in the absence thereof, priority shall be given to them; and\r\nâ€œ(l) death benefit assistance of a minimum of Two thousand pesos (Php2, 000.00) shall be given to the nearest surviving relative of a deceased senior citizen which amount shall be subject to adjustments due to inflation in accordance with the guidelines to be issued by the DSWD.cralaw\r\nâ€œIn the availment of the privileges mentioned above, the senior citizen, or his/her duly authorized representative, may submit as proof of his/her entitled thereto any of the following:\r\nâ€œ(1) an identification card issued by the Office of the Senior Citizen Affairs (OSCA) of the place where the senior citizen resides: Provided, That the identification card issued by the particular OSCA shall be honored nationwide;\r\nâ€œ(2) the passport of the senior citizen concerned; and\r\nâ€œ(3) other documents that establish that the senior citizen is a citizen of the Republic and is at least sixty (60) years of age as further provided in the implementing rules and regulations.\r\nâ€œIn the purchase of goods and services which are on promotional discount, the senior citizen can avail of the promotional discount or the discount provided herein, whichever is higher.cralaw\r\nâ€œThe establishment may claim the discounts granted under subsections (a) and (c) of this section as tax deduction based on the cost of the goods sold or services rendered: Provided, That the cost of the discount shall be allowed as deduction from gross income for the same taxable year that the discount is granted: Provided, further, That the total amount of the claimed tax deduction net of VAT, if applicable, shall be included in their gross sales receipts for tax purposes and shall be subject to proper documentation and to the provisions of the National Internal Revenue Code (NICR), as amended.â€\r\nSec. 5. Section 5 of the same Act, as amended, is hereby further amended to read as follows:\r\nâ€œSEC. 5. Government Assistance. â€“ The government shall provide the following:\r\nâ€œ(a) Employment\r\nâ€œSenior citizens who have the capacity and desire to work, or be re-employed, shall be provided information and matching services to enable them to be productive members of society. Terms of employment shall conform with the provisions of the Labor Code, as amended, and other laws, rules and regulations.\r\nâ€œPrivate entities that will employ senior citizens as employees, upon the effectivity of this Act, shall be entitled to an additional deduction from their gross income, equivalent to fifteen percent (15%) of the total amount paid as salaries and wages to senior citizens, subject to the provision of Section 34 of the NIRC, as amended: Provided, however, That such employment shall continue for a period of at least six (6) months: Provided, further, That the annual income of the senior citizen does not exceed the latest poverty threshold as determined by the National Statistical Coordination Board (NSCB) of the National Economic and Development Authority (NEDA) for that year.\r\nâ€œThe Department of Labor and Employment (DOLE), in coordination with other government agencies such as, but not limited to, the Technology and Livelihood Resource Center (TLRC) and the Department of Trade and Industry (DTI), shall assess, design and implement training programs that will provide skills and welfare or livelihood support for senior citizens.\r\nâ€œ(b) Education\r\nâ€œThe Department of Education (DepED), the Technical Education and Skills Development Authority (TESDA) and the Commission on Higher Education (CHED), in consultation with nongovernmental organizations (NGOs) and peopleâ€™s organizations (POs) for senior citizens, shall institute programs that will ensure access to formal and nonformal education.\r\nâ€œ(c) Health\r\nâ€œThe DOH, in coordination with local government units (LGUs), NGOs and POs for senior citizens, shall institute a national health program and shall provide an integrated health service for senior citizens. It shall train community-based health workers among senior citizens and health personnel to specialize in the geriatric care and health problems of senior citizens.\r\nâ€œThe national health program for senior citizens shall, among others, be harmonized with the National Prevention of Blindness Program of the DOH.\r\nâ€œThroughout the country, there shall be established a â€œsenior citizensâ€™ wardâ€ in every government hospital. This geriatric ward shall be for the exclusive use of senior citizens who are in need of hospital confinement by reason of their health conditions. However, when urgency of public necessity purposes so require, such geriatric ward may be used for emergency purposes, after which, such â€œsenior citizensâ€™ wardâ€ shall be reverted to its nature as geriatric ward.\r\nâ€œ(d) Social Services\r\nâ€œAt least fifty percent (50%) discount shall be granted on the consumption of electricity, water, and telephone by the senior citizens center and residential care/group homes that are government-run or non-stock, non-profit domestic corporation organized and operated primarily for the purpose of promoting the well-being of abandoned, neglected, unattached, or homeless senior citizens, subject to the guidelines formulated by the DSWD.\r\nâ€œ(1) â€œself and social enhancement servicesâ€ which provide senior citizens opportunities for socializing, organizing, creative expression, and self-improvement;\r\nâ€œ(2) â€œafter care and follow-up servicesâ€ for citizens who are discharged from the homes or institutions for the aged, especially those who have problems of reintegration with family and community, wherein both the senior citizens and their families are provided with counseling;\r\nâ€œ(3) â€œneighborhood support servicesâ€ wherein the community or family members provide caregiving services to their frail, sick, or bedridden senior citizens; and\r\nâ€œ(4) â€œsubstitute family care â€ in the form of residential care or group homes for the abandoned, neglected, unattached or homeless senior citizens and those incapable of self-care.\r\nâ€œ(e) Housing\r\nâ€œThe national government shall include in its national shelter program the special housing needs of senior citizens, such as establishment of housing units for the elderly.\r\nâ€œ(f) Access to Public Transport\r\nâ€œThe Department of Transportation and Communications (DOTC) shall develop a program to assist senior citizens to fully gain access to public transport facilities.\r\nâ€œ(g) Incentive for Foster Care\r\nâ€œThe government shall provide incentives to individuals or nongovernmental institution caring for or establishing homes, residential communities or retirement villages solely for, senior citizens, as follows:\r\nâ€œ(1) realty tax holiday for the first five (5) years starting from the first year of operation; and\r\nâ€œ(2) priority in the construction or maintenance of provincial or municipal roads leading to the aforesaid home, residential community or retirement village.\r\nâ€œ(h) Additional Government Assistance\r\nâ€œ(1) Social Pension\r\nâ€œIndigent senior citizens shall be entitled to a monthly stipend amounting to Five hundred pesos (Php500.00) to augment the daily subsistence and other medical needs of senior citizens, subject to a review every two (2) years by Congress, in consultation with the DSWD.\r\nâ€œ(2) Mandatory PhilHealth Coverage\r\nâ€œAll indigent senior citizens shall be covered by the national health insurance program of PhilHealth. The LGUs where the indigent senior citizens resides shall allocate the necessary funds to ensure the enrollment of their indigent senior citizens in accordance with the pertinent laws and regulations.\r\nâ€œ(3) Social Safety Nets\r\nâ€œSocial safety assistance intended to cushion the effects of economics shocks, disasters and calamities shall be available for senior citizens. The social safety assistance which shall include, but not limited to, food, medicines, and financial assistance for domicile repair, shall be sourced from the disaster/calamity funds of LGUs where the senior citizens reside, subject to the guidelimes to be issued by the DSWD.â€\r\nSec. 6. Section 6 of the same Act, as amended, is heeby further amended to read as follows:\r\nSEC. 6. The Office for Senior Citizens Affairs (OSCA). â€“ There shall be established in all cities and municipalities an OSCA to be headed by a senior citizen who shall be appointed by the mayor for a term of three (3) years without reappointment but without prejudice to an extension if exigency so requires. Said appointee shall be chosen from a list of three (3) nominees as recommended by a general assembly of senior citizens organizations in the city or municipality.\r\nâ€œThe head of the OSCA shall be appointed to serve the interest of senior citizens and shall not be removed or replaced except for reasons of death permanent disability or ineffective performance of his duties to the detriment of fellow senior citizens.\r\nâ€œThe head of the OSCA shall be entitled to receive an honorarium of an amount at least equivalent to Salary Grade 10 to be approved by the LGU concerned.\r\nâ€œThe head of the OSCA shall be assisted by the City Social Welfare and Development officer or by the Municipal Social Welfare and Development Officer, in coordination with the Social Welfare and Development Office.\r\nâ€œThe Office of the Mayor shall exercise supervision over the OSCA relative to their plans, activities and programs for senior citizens. The OSCA shall work together and establish linkages with accredited NGOs Pos and the barangays in their respective areas.\r\nâ€œThe OSCA shall have the following functions:\r\nâ€œ(a) To plan, implement and monitor yearly work programs in pursuance of the objectives of this Act;\r\nâ€œ(b) To draw up a list of available and required services which can be provided by the senior citizens;\r\nâ€œ(c) To maintain and regularly update on a quarterly basis the list of senior citizens and to issue national individual identification cards, free of charge, which shall be valid anywhere in the country;\r\nâ€œ(d) To serve as a general information and liason center for senior citizens;\r\nâ€œ(e) To monitor compliance of the provisions of this Act particularly the grant of special discounts and privileges to senior citizens;\r\nâ€œ(f) To report to the mayor, any individual, establishments, business entity, institutions or agency found violating any provision of this Act; and\r\nâ€œ(g) To assist the senior citizens in filing complaints or charges against any individual, establishments, business entity, institution, or agency refusing to comply with the privileges under this Act before the Department of Justice (DOJ), the Provincial Prosecutorâ€™s Office, the regional or the municipal trial court, the municipal trial court in cities, or the municipal circuit trial court.â€\r\nSec. 7. Section 10 of the same Act, as amended, is hereby further amended to read as follows:\r\nâ€œSEC. 10. Penalties. â€“ Any person who refuses to honor the senior citizen card issued by this the government or violates any provision of this Act shall suffer the following penalties:\r\nâ€œ(a) For the first violation, imprisonment of not less than two (2) years but not more than six (6) years and a fine of not less than Fifty thousand pesos (Php50,000.00) but not exceeding One hundred thousand pesos (Php100,000.00);\r\nâ€œ(b) For any subsequent violation, imprisonment of not less than two (2) years but not more than six (6) years and a fine of not less than One Hundred thousand pesos (Php100,000.00) but not exceeding Two hundred thousand pesos (Php200,000.00); and\r\nâ€œ(c) Any person who abuses the privileges granted herein shall be punished with imprisonment of not less than six (6) months and a fine of not less than Fifty thousand pesos (Php50,000.00) but not more than One hundred thousand pesos (Php100,000.00).\r\nâ€œIf the offender is a corporation, partnership, organization or any similar entity, the officials thereof directly involved such as the president, general manager, managing partner, or such other officer charged with the management of the business affairs shall be liable therefor.\r\nâ€œIf the offender is an alien or a foreigner, he/she shall be deported immediately after service of sentence.\r\nâ€œUpon filing of an appropriate complaint, and after due notice and hearing, the proper authorities may also cause the cancellation or revocation of the business permit, permit to operate, franchise and other similar privileges granted to any person, establishment or business entity that fails to abide by the provisions of this Act.â€\r\nSec. 8. Section 11 of the same Act, as amended, is hereby further amended to read as follows:\r\nâ€œSEC. 11. Monitoring and Coordinating Mechanism. â€“ A National Coordinating and Monitoring Board shall be established which shall be composed of the following:\r\nâ€œ(a) Chairperson â€“ the Secretary of the DSWD or an authorized representative;\r\nâ€œ(b) Vice Chairperson â€“ the Secretary of the Department of the Interior and Local Government (DILG) or an authorized representative; and\r\nâ€œ(c) Members:\r\nâ€œ(1) the Secretary of the DOJ or an authorized representative;\r\nâ€œ(2) the Secretary of the DOH or an authorized representative;\r\nâ€œ(3) the Secretary of the DTI or an authorized representative; and\r\n(4) representatives from five (5) NGOs for senior citizens which are duly accredited by the DSWD and have service primarily for senior citizens. Representatives of NGOs shall serve a period of tree (3) years.\r\nâ€œThe Board may call on other government agencies, NGOs and Pos to serve as resource persons as the need arises. Resource person have no right to vote in the National Coordinating and Monitoring Board.â€\r\nSec. 9. Implementing Rules and Regulations. â€“ Within sixty (60) days from theeffectivity of this Act, the Secretary of the DSWD shall formulate and adopt amendments to the existing rules and regulations implementing Republic Act No. 7432, as amended by Republic Act No. 9257, to carry out the objectives of this Act, in consultation with the Department of Finance, the Department of Tourism, the Housing and Urban Development Coordinating Council (HUDCC), the DOLE, the DOJ, the DILG, the DTI, the DOH, the DOTC, the NEDA, the DepED, the TESDA, the CHED, and five (5) NGOs or POs for the senior citizens duly accredited by the DSWD. The guidelines pursuant to Section 4(a)(i) shall be established by the DOH within sixty (60) days upon the effectivity of this Act.\r\nSec. 10. Appropriations. â€“ The Necessary appropriations for the operation and maintenance of the OSCA shall be appropriated and approved by the LGUs concerned. For national government agencies, the requirements to implement the provisions of this Act shall be included in their respective budgets: Provided, That the funds to be used for the national health program and for the vaccination of senior citizens in the first year of the DOH and thereafter, as a line item under the under the DOH budget in the subsequent General Appropriations Act (GAA): Provided, further, That the monthly social pension for indigent senior citizens in the first year of implementation shall be added to the regular appropriations of the DSWD budget in the subsequent GAA.\r\nSec. 11. Repealing Clause. â€“ All law, executive orders, rules and regulations or any part hereof inconsistent herewith are deemed repealed or modified accordingly.\r\nSec. 12. Separability Clause. â€“ If any part or provision of this Act shall be declared unconstitutional and invalid, such 18 declaration shall not invalidate other parts thereof which shall remain in full force and effect.\r\nSec. 13. Effectivity. â€“ This Act shall take effect fifteen (15) days its complete publication n the Official Gazette or in at least two (2) newspapers of general circulation, whichever comes earlier.', '2017-10-02 01:47pm');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `service` varchar(255) NOT NULL,
  `service_offer` mediumtext NOT NULL,
  `service_date` date NOT NULL,
  `service_start` time NOT NULL,
  `service_end` time NOT NULL,
  `service_location` varchar(255) NOT NULL,
  `posted_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `user_id`, `service`, `service_offer`, `service_date`, `service_start`, `service_end`, `service_location`, `posted_time`) VALUES
(12, 5, 'Free Medical Services', 'Free Medical Services to all Senior Citizens in Cebu City', '2017-10-05', '10:00:00', '14:00:00', 'New Cebu Coliseum', '2017-10-02 11:10am'),
(13, 11, 'Assistance for Physical Restoration', 'Assisting Elderly and Disabled Persons on how to restore physical health', '2017-10-10', '10:00:00', '14:00:00', 'New Cebu Coliseum', '2017-10-02 01:45pm');

-- --------------------------------------------------------

--
-- Table structure for table `services_acquired`
--

CREATE TABLE `services_acquired` (
  `acquire_id` int(11) NOT NULL,
  `senior_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `acquired_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_accounts`
--

CREATE TABLE `user_accounts` (
  `user_id` int(11) NOT NULL,
  `organization` varchar(255) NOT NULL,
  `org_address` varchar(255) NOT NULL,
  `org_num` varchar(255) NOT NULL,
  `org_email` varchar(255) NOT NULL,
  `org_website` varchar(255) NOT NULL,
  `profilepicture` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_accounts`
--

INSERT INTO `user_accounts` (`user_id`, `organization`, `org_address`, `org_num`, `org_email`, `org_website`, `profilepicture`, `username`, `password`, `type`, `status`) VALUES
(5, 'Office of the Senior Citizens Affair', '5th Floor Cebu City Hall, Magallanes St., Cebu City', '422-8086', '', '', '2939.png', 'osca', 'abcd1234', 'government', 'active'),
(6, 'Department of Health', 'Osmena Blvd, Cebu City', '488-8877', '', 'https://www.doh.gov.ph', '5675.jpg', 'doh', 'abcd1234', 'government', 'active'),
(7, 'Rose Pharmacy Inc,', 'P. del Rosario Street corner Junquera St. Cebu City', '(032) 230-5000', 'info@rosepharmacy.com', 'http://www.rosepharmacy.com', '3824.jpg', 'rosepharmacy', 'abcd1234', 'business', 'active'),
(8, 'Cebu Pacific Airline', 'Lapu-Lapu City', '(02) 702-0888', 'guestservices@flyceb.com', 'https://www.cebupacificair.com', '1600.jpg', 'cebupacific', 'abcd1234', 'business', 'active'),
(9, 'Eperformax', 'JY Square IT Center 1 Salinas Drive 3/F, Lahug, Cebu City', '(032) 490-2288', '', 'http://www.eperformax.com', '1548.jpg', 'eperformax', 'abcd1234', 'private', 'active'),
(10, 'Azpired, Inc.', '16th Floor, Cebu IT Tower 2, Cebu Business Park, Cebu City', '(032) 412-2374', 'hotjobs@azpired.com', 'https://www.azpired.com', '9474.jpg', 'azpired', 'abcd1234', 'private', 'active'),
(11, 'Department of Social Welfare and Development', 'M.J. Cuenco Avenue Corner General Maxilom Avenue Extension, Barangay Carreta, Cebu Ctiy', '(032) 232-9505', 'fo7@dswd.gov.ph', 'http://www.fo7.dswd.gov.ph', '1255.jpg', 'dswd', 'abcd1234', 'government', 'active'),
(12, 'City Traffic Management Office', 'N. Bacalso St., Cebu City', '(032) 256-2745', '', '', '5182.jpg', 'citom', 'abcd1234', 'government', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `discounts`
--
ALTER TABLE `discounts`
  ADD PRIMARY KEY (`discount_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `event_join`
--
ALTER TABLE `event_join`
  ADD PRIMARY KEY (`join_id`);

--
-- Indexes for table `govprograms`
--
ALTER TABLE `govprograms`
  ADD PRIMARY KEY (`program_id`);

--
-- Indexes for table `gov_admin`
--
ALTER TABLE `gov_admin`
  ADD PRIMARY KEY (`govadmin_id`);

--
-- Indexes for table `healths`
--
ALTER TABLE `healths`
  ADD PRIMARY KEY (`health_id`);

--
-- Indexes for table `insurances`
--
ALTER TABLE `insurances`
  ADD PRIMARY KEY (`insurance_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `job_apply`
--
ALTER TABLE `job_apply`
  ADD PRIMARY KEY (`apply_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `seniorcitizens`
--
ALTER TABLE `seniorcitizens`
  ADD PRIMARY KEY (`seniors_id`);

--
-- Indexes for table `senior_accounts`
--
ALTER TABLE `senior_accounts`
  ADD PRIMARY KEY (`senior_id`);

--
-- Indexes for table `senior_law`
--
ALTER TABLE `senior_law`
  ADD PRIMARY KEY (`law_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `services_acquired`
--
ALTER TABLE `services_acquired`
  ADD PRIMARY KEY (`acquire_id`);

--
-- Indexes for table `user_accounts`
--
ALTER TABLE `user_accounts`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `discounts`
--
ALTER TABLE `discounts`
  MODIFY `discount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `event_join`
--
ALTER TABLE `event_join`
  MODIFY `join_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `govprograms`
--
ALTER TABLE `govprograms`
  MODIFY `program_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `gov_admin`
--
ALTER TABLE `gov_admin`
  MODIFY `govadmin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `healths`
--
ALTER TABLE `healths`
  MODIFY `health_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `insurances`
--
ALTER TABLE `insurances`
  MODIFY `insurance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `job_apply`
--
ALTER TABLE `job_apply`
  MODIFY `apply_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `seniorcitizens`
--
ALTER TABLE `seniorcitizens`
  MODIFY `seniors_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `senior_accounts`
--
ALTER TABLE `senior_accounts`
  MODIFY `senior_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `senior_law`
--
ALTER TABLE `senior_law`
  MODIFY `law_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `services_acquired`
--
ALTER TABLE `services_acquired`
  MODIFY `acquire_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_accounts`
--
ALTER TABLE `user_accounts`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
