<?php
	include_once("header3.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$event_id = $_GET['event_id'];
	$eventjoin = get_event_join($event_id);

	$message = "";
	if(isset($_POST['submit']))
	{
		$senior_id = $_POST['senior_id'];
		$event_id = $_POST['event_id'];
		$join_time = $_POST['join_time'];

		$existing_join = find_event_join($senior_id, $event_id);

		if($existing_join){
			$message = "<div class='alert alert-danger'>You are already registered to this event.</div>";
		}
		else{
			add_join_event($senior_id, $event_id, $join_time);
			$message = "<div class='alert alert-info'>You have registered successfully</div>";
		}
	}

?>
<div class="container">
	<?php echo $message; ?>
	<div class="thumbnail">
	<form method="post">
			<input type="hidden" name="event_id" value="<?php echo htmlentities($eventjoin['event_id']); ?>">

			<div class="media">
				<div class="media-left">
					<?php
					if(!empty($eventjoin['profilepicture'])){
					?>
					<span><img src="profilepictures/<?php echo htmlentities($eventjoin['profilepicture']); ?>" class="profile-pic"></span>
					<?php
					}
					else{
					?>
					<span><img src="images/img_avatar3.png" class="profile-pic"></span>
					<?php } ?>
				</div>

				<div class="media-body">
					<h4 class="media-heading"> <span><b><?php echo htmlentities($eventjoin['organization']); ?></b></span></h4>
					<p class="media-content"><?php echo htmlentities($eventjoin['event']); ?></p>
					<p class="media-content"><?php echo htmlentities($eventjoin['event_description']);  echo " on ";
						$date=date_create($eventjoin['event_date']);
						echo date_format($date, "F d, Y, l");
						echo " from ";
						$stime=date_create($eventjoin['event_start']);
						echo date_format($stime, "h:i A");
						echo " to ";
						$etime=date_create($eventjoin['event_end']);
						echo date_format($etime, "h:i A"); 
						echo " at ";
						echo htmlentities($eventjoin['event_location']);
						?>
					</p>
				</div>
			</div>
		</div>

		<div class="thumbnail">
			<input type="hidden" name="senior_id" value="<?php echo htmlentities($row['senior_id']); ?>">
			
			<div class="thumbnail">
				<div class="form-group">
					<label class="control-label">Senior Citizen's ID Number</label>
					<input type="text" name="seniorid" class="form-control" value="<?php echo htmlentities($row['seniorid']); ?>" readonly>
				</div>
			</div>

			<div class="row">
				<div class="col-sm-6">
					<div class="thumbnail">
						<div class="form-group">
							<label class="control-label">First Name</label>
							<input type="text" name="fname" class="form-control" value="<?php echo htmlentities($row['fname']); ?>" readonly>
						</div>

						<div class="form-group">
							<label class="control-label">Middle Name</label>
							<input type="text" name="mname" class="form-control" value="<?php echo htmlentities($row['mname']); ?>" placeholder="Enter middle name (optional)" readonly>
						</div>

						<div class="form-group">
							<label class="control-label">Last Name</label>
							<input type="text" name="lname" class="form-control" value="<?php echo htmlentities($row['lname']); ?>" readonly>
						</div>
					</div>
				</div>

				<div class="col-sm-6">
					<div class="thumbnail">
						<div class="form-group">
							<label class="control-label">Gender</label>
							<input type="text" name="gender" class="form-control" value="<?php echo htmlentities($row['gender']); ?>" readonly>
						</div>

						<div class="form-group">
							<label class="control-label">Date of Birth</label>
							<input type="text" class="form-control" value="<?php $date=date_create($row['bdate']);
								echo date_format($date, "F d, Y"); ?>" readonly>
						</div>

						<div class="form-group">
							<label class="control-label">Birth Place</label>
							<input type="text" name="bplace" class="form-control" value="<?php echo htmlentities($row['bplace']); ?>" readonly>
						</div>
					</div>
				</div>
			</div>

			<div class="thumbnail">
				<div class="form-group">
					<label class="control-label">Region</label>
					<input type="text" name="region" class="form-control" value="<?php echo htmlentities($row['region']); ?>" readonly>
				</div>

				<div class="form-group">
					<label class="control-label">Province</label>
					<input type="text" name="province" class="form-control" value="<?php echo htmlentities($row['province']); ?>" readonly>
				</div>

				<div class="form-group">
					<label class="control-label">City/Municipality</label>
					<input type="text" name="city" class="form-control" value="<?php echo htmlentities($row['city']); ?>" readonly>
				</div>

				<div class="form-group">
					<label class="control-label">Baranggay</label>
					<input type="text" name="baranggay" class="form-control" value="<?php echo htmlentities($row['baranggay']); ?>" readonly>
				</div>

				<div class="form-group">
					<label class="control-label">Sitio/Baranggay</label>
					<input type="text" name="sitio" class="form-control" value="<?php echo htmlentities($row['sitio']); ?>" readonly>
				</div>
			</div>


			<div class="form-group">
				<label class="control-label">Medical Record</label>
				<img src="seniormedrecord/<?php echo htmlentities($row['medrecord']); ?>" width="100%" height="100%">
			</div>

			<input type="hidden" name="join_time" value="<?php echo date('Y-m-d h:ia'); ?>">

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Register">
				<a href="senior-events.php" class="btn btn-default">Cancel</a>
			</div>
	</form>

	</div>
</div>