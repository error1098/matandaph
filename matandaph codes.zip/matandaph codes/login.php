<?php
	include_once("matandaph.php");

	error_reporting( ~E_NOTICE );

	if(user_islogin()){
		if($_SESSION['type'] == 'government' || $_SESSION['type'] == 'business' || $_SESSION['type'] == 'private'){
			header('Location: user-homepage.php');
			exit();
		}
		elseif($_SESSION['type'] == 'senior'){
			header('Location: senior-homepage.php');
			exit();
		}
	}
	
	$message = "";
	$username = "";
	$password = "";
	if(isset($_POST['submit']))
	{
		$username = trim($_POST['username']);
		$password = trim($_POST['password']);

		if(user_login($username, $password)){
			// echo "<div style='margin-left: 600px; margin-right: 600px; margin-top: 300px;'>
			// 		<img src='btn-ajax-loader.gif' height='50' width=50> 
			// 	</div>";
			header('Location: user-homepage.php');
			exit();
		}
		elseif(admin_login($username, $password)){
			// echo "<div style='margin-left: 600px; margin-right: 6400px; margin-top: 300px;'>
			// 		<img src='btn-ajax-loader.gif' height='50' width=50> 
			// 	</div>";
			header('Location: user-homepage.php');
			exit();
		}
		elseif(govadmin_login($username, $password)){
			// echo "<div style='margin-left: 600px; margin-right: 600px; margin-top: 300px;'>
			// 		<img src='btn-ajax-loader.gif' height='50' width=50> 
			// 	</div>";
			header('Location: admin-page.php');
			exit();
		}
		elseif(senior_login($username, $password)){
			// echo "<div style='margin-left: 600px; margin-right: 600px; margin-top: 300px;'>
			// 		<img src='btn-ajax-loader.gif' height='50' width=50> 
			// 	</div>";
			header('Location: senior-homepage.php');
			exit();
		}
		else
		{
			$message = "<div class='alert alert-danger'><span class='glyphicon glyphicon-info-sign'></span> Username or Password is incorrect!</div>";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>MatandaPH | Log In</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="css/login-design.css">
	<script type="text/javascript" src="bootstrap/js/jquery.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
	<script type="text/javascript" src="css/jquery-3.1.1.min.js"></script>
</head>
<body>

	<div class="signin-form">
		<div class="container">
			<form class="form-design" id="myform" method="post" onsubmit="return validateform()">

				<b><h2 class="form-header text-center">Login to <b style="font-family: 'Lucida Handwriting'; color: #668cff !important;">MatandaPH</b></h2></b>
				<hr />

				<input type="hidden" name="status">
				
				<div id="error"><?php echo $message; ?></div>

				<div class="form-group">
					<h4 class="control-label"><span class="glyphicon glyphicon-user"></span>Username</h4>
					<input type="text" name="username" class="form-control" placeholder="Enter Username" id="username" oninput="return validate()" value="<?php echo $username; ?>">
				</div>

				<div class="form-group">
					<h4 class="control-label"><span class="glyphicon glyphicon-lock"></span>Password</h4>
					<input type="password" name="password" class="form-control" placeholder="Enter Password" id="password" oninput="return validate()">
				</div>

				<div class="form-group">
					<input type="submit" name="submit" class="btn btn-primary btn-block" value="LOG IN" id="btn-login">
				</div>

				<hr />

				<div style="text-align: center;">
					<a href="registration-select.php?Select_User?"><span class="glyphicon glyphicon-user"></span> Create Account</a> | <a href="#"><span class="glyphicon glyphicon-question-sign"></span> Forgot Password?</a>
				</div>

				<hr />

				<a href="index.php" class="btn btn-default btn-block">Go to <b style="font-family: 'Lucida Handwriting'; color: #668cff !important;">MatandaPH</b></a>
			</form>
		</div>
	</div>

<script type="text/javascript">
	
	function validateform(){
		var user = document.forms["myform"]["username"].value;
		var pass = document.forms["myform"]["password"].value;

		if(user == "" && pass == ""){
			document.getElementById("username").style.borderColor = "red";
			document.getElementById("password").style.borderColor = "red";
			document.getElementById("error").innerHTML = "<div class='alert alert-danger'><span class='glyphicon glyphicon-info-sign'></span> Please provide your Username and Passsword.</div";
			document.getElementById("username").focus();
			return false;
		}
		else if(user == ""){
			document.getElementById("username").style.borderColor = "red";
			document.getElementById("error").innerHTML = "<div class='alert alert-danger'><span class='glyphicon glyphicon-info-sign'></span> Please provide your Username.</div";
			document.getElementById("username").focus();
			return false;


		}
		else if(pass == ""){
			document.getElementById("password").style.borderColor = "red";
			document.getElementById("error").innerHTML = "<div class='alert alert-danger'><span class='glyphicon glyphicon-info-sign'></span> Please provide your Passsword.</div";
			document.getElementById("password").focus();
			return false;
		}
	}

	function validate(){
		var user = document.forms["myform"]["username"].value;
		var pass = document.forms["myform"]["password"].value;

		if(user != ""){
			document.getElementById("username").style.borderColor = "#9999cc";
		}
		
		if(pass != ""){
			document.getElementById("password").style.borderColor = "#9999cc";
		}
	}
</script>

</body>
</html>1