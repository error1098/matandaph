<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	if(isset($_GET['program_id'])){
		$program_id = $_GET['program_id'];
		$editprogram = get_program($program_id);
	}

	$notif_comment = "has updated a post on government programs.";
	$posted_time = date('Y-m-d h:ia');

	if(isset($_POST['submit'])){
		$program_title = trim($_POST['program_title']);
		$program_description = trim($_POST['program_description']);

		add_notification($user_id, $notif_comment, $posted_time);
		edit_program($program_id, $program_title, $program_description);
		header('Location: govprograms.php');

	}

?>
<div class="container">
	<div class="thumbnail">
		<form method="post">
			<input type="text" name="user_id" value="<?php echo htmlentities($editprogram['user_id']); ?>">
			<input type="hidden" name="notif_comment">

			<div class="form-group">
				<label class="control-label">Program Title</label>
				<input type="text" name="program_title" class="form-control" value="<?php echo htmlentities($editprogram['program_title']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Title Description</label>
				<textarea class="form-control" name="program_description" required><?php echo htmlentities($editprogram['program_description']); ?></textarea>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Edit">
				<a href="govprograms.php" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
</div>