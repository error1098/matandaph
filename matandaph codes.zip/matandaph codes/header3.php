<?php
	include_once("matandaph.php");

	date_default_timezone_set('Asia/Manila');

	$type = $_SESSION['type'];
	$status = $_SESSION['status'];
	
	$senior_id = $_SESSION['senior_id'];
	$seniors = get_user_senior($senior_id);

	$fname = $_SESSION['fname'];
	if(isset($_SESSION[$fname])){
		echo $fname;
	}

	$notify = get_notification();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome to MatadanPH</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="css/user-page-design.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<script type="text/javascript" src="bootstrap/js/jquery.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
	<script type="text/javascript" src="css/jquery-3.1.1.min.js"></script>
</head>
<body>

	<nav class="navbar navbar-static-top">
		<div class="container">
			<div class="navbar-header">
				<b><a href="senior-homepage.php" class="navbar-brand">MatandaPH</a></b>
			</div>
			<?php
				if($status == "1"){
			?>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="senior-discounts.php">DISCOUNTS</a></li>
				<li><a href="senior-events.php">EVENTS</a></li>
				<li><a href="senior-jobs.php">JOBS</a></li>
				<li><a href="senior-services.php">SERVICES</a></li>
				<li><a href="senior-programs.php">GOVERNMENT PROGRAMS</a></li>
				<li><a href="senior-health.php">HEALTH</a></li>
				<li><a href="senior-law.php">SENIOR'S LAW</a></li>
				<li>
					<a href="notifications.php"><span class="glyphicon glyphicon-globe"></span><span class="badge" style="background-color: red;"><?php echo count($notify);?></span>
					</a>
				</li>
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<?php echo $fname; ?> <span class="caret"></span>
					</a>
					<ul class="dropdown-menu">
						<?php
							if(count($seniors)>0){
								foreach($seniors as $row){
						?>
						<li>
							<a href="senior-profile.php?senior_id=<?php echo htmlentities($row['senior_id']); ?>type=<?php echo htmlentities($row['type']); ?>"><span class="glyphicon glyphicon-user"></span> Profile</a>
						</li>
						<?php
							}
						}
						?>
						<li>
							<a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
						</li>
					</ul>
				</li>
			</ul>
			<?php } ?>
		</div>
	</nav>

</body>
</html>