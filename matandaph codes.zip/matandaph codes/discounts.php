<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$notif_comment = "has posted a new discount.";
	$discount_content = "";
	$message = "";

	if(isset($_POST['submit']))
	{
		$user_id = trim($_POST['user_id']);
		$discount_content = trim($_POST['discount_content']);
		$posted_time = trim($_POST['posted_time']);

		add_notification($user_id, $notif_comment, $posted_time);
		add_discount($user_id, $discount_content, $posted_time);
		$message = "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> You have posted a discount/s successfully!</div>";
		$discount_content = "";
	}

	$discounts = get_all_discounts();

	if(isset($_GET['discount_id'])){
		$discount_id = $_GET['discount_id'];
		del_discount($discount_id);
		header('Location: discounts.php');
	}
?>
<div class="container">
	<?php
	if(count($users)>0){
		foreach($users as $row){
			if($row['type'] == 'government' && $row['status'] == 'active' || $row['type'] == 'business' && $row['status'] == 'active'){
	?>
	<div class="thumbnail">
		<?php echo $message; ?>
		<form method="post">
			<input type="hidden" name="user_id" value="<?php echo htmlentities($row['user_id']); ?>">
			<input type="hidden" name="notif_comment">
			
			<div class="form-group">
				<label class="control-label">Post Discount</label>
				<textarea name="discount_content" class="form-control" placeholder="Enter discount" required><?php echo $discount_content; ?></textarea>
			</div>

			<input type="hidden" name="posted_time" value="<?php echo date('Y-m-d h:ia'); ?>">

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Post">
				<input type="reset" name="" class="btn btn-default" value="Cancel">
			</div>
		</form>
	</div>
	<?php
			}
		}
	}
	?>

	<?php
		if(count($discounts)>0){
			foreach($discounts as $row){
	?>
	<div class="content-container">
		<div class="content">
			<?php
				if(!empty($row['profilepicture'])){
			?>
			<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b><br /><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></span>
			<?php
			}
			else{
			?>
			<span><img src="images/img_avatar3.png" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b><br /><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></span>
			<?php } ?>
			<span><b><?php echo htmlentities($row['discount_content']); ?></b></span>
		</div>

		<?php
		if($row['user_id'] == $_SESSION['user_id'] && $row['type'] == 'government'){
		?>
		<div style="border-top: 1px solid #ccc; padding-top: 5px; margin-top: 15px;">
			<a href="edit-discount.php?discount_id=<?php echo htmlentities($row['discount_id']); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a> | <a href="discounts.php?discount_id=<?php echo htmlentities($row['discount_id']); ?>" onclick="return confirm('Are you sure you want to delete this?')"><span class="glyphicon glyphicon-remove"></span> Delete</a>
		</div>	
		<?php
		}
		elseif($row['user_id'] == $_SESSION['user_id'] && $row['type'] == 'business'){
		?>
		<div style="border-top: 1px solid #ccc; padding-top: 5px; margin-top: 15px;">
			<a href="edit-discount.php?discount_id=<?php echo htmlentities($row['discount_id']); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a> | <a href="discounts.php?discount_id=<?php echo htmlentities($row['discount_id']); ?>" onclick="return confirm('Are you sure you want to delete this?')"><span class="glyphicon glyphicon-remove"></span> Delete</a>
		</div>
		<?php } ?>

	</div>
	<?php
		}
	}
	?>
</div>