<?php
	include_once("matandaph.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$user = $_SESSION['username'];
	if(isset($_SESSION[$user])){
		echo $user;
	}

	$seniors = get_all_seniors();

	$seniorproof = get_all_seniors_gov();

	if(isset($_GET['senior_id'])){
		$senior_id = $_GET['senior_id'];
		edit_senior_status($senior_id, "1");
		header('Location: admin-page.php');
	}

	$search_results = array();
	$keyword = "";
	if(isset($_POST['keyword'])){
		$keyword = trim($_POST['keyword']);
		$search_results = senior_search($keyword, $keyword);
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="css/registration.css">
	<script type="text/javascript" src="bootstrap/js/jquery.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
</head>
<body>

	<nav class="navbar navbar-default navbar-static-top">
		<div class="container">
			<div class="navbar-header">
				<b><a href="admin-page.php" class="navbar-brand">MatandaPH</a></b>
			</div>

			<ul class="nav navbar-nav navbar-right">
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<?php echo ucfirst($user); ?> <span class="caret"></span>
					</a>

					<ul class="dropdown-menu">
						<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>

	<div class="container">
		<div class="thumbnail">
			<form method="post">
				<div class="form-group">
					<label>Search:</label> 
					<input type="text" name="keyword" class="form-control" placeholder="Search for Senior Citizen's ID No.">
				</div>

				<div class="form-group">
					<input type="submit" name="submit" class="btn btn-primary">
				</div>
			</form>

			<div class="table-responsive">
				<?php
					foreach($search_results as $row){
				?>
				<table class="table table-striped table-bordered table-condensed">
					<tr>
						<td>
							Senior Citizen's ID
						</td>
						<td>
							Name
						</td>
						<td>
							Date of Birth
						</td>
						<td>
							Gender
						</td>
						<td>
							Address
						</td>
					</tr>

					<tr>
						<td>
							<?php echo htmlentities($row['senior_id']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['name']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['address']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['date_of_birth']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['gender']); ?>
						</td>
					</tr>
				</table>
				<?php } ?>
			</div>
		</div>

		<div class="thumbnail">
			<label>Senior Accounts</label>
			<div class="table-responsive">
				<table class="table table-striped table-bordered table-condensed">
					<tr class="info">
						<td>
							Senior Citizen's ID
						</td>
						<td>
							Name
						</td>
						<td>
							Date of Birth
						</td>
						<td>
							Place of Birth
						</td>
						<td>
							Gender
						</td>
						<td>
							Address
						</td>
						<td>
							Status
						</td>
						<td>
							Query
						</td>
					</tr>

					<?php
						if(count($seniors)>0){
							foreach($seniors as $row){
					?>
					<tr>
						<td>
							<?php echo htmlentities($row['seniorid']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['fname']." ".$row['mname']." ".$row['lname']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['bmonth']." ".$row['bdate'].", ".$row['byear']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['bplace']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['gender']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['sitio'].", ".$row['baranggay'].", ".$row['city'].", ".$row['province']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['status']); ?>
						</td>
						<?php
							if($row['status'] == "0"){
						?>
						<td>
							<a href="admin-page.php?senior_id=<?php echo htmlentities($row['senior_id']); ?>" class="btn btn-primary btn-sm">Approve</a>
						</td>
						<?php
						}
						elseif($row['status'] == "1"){
						?>
						<td>
							<label>Approved</label>
						</td>
						<?php } ?>
					</tr>
					<?php
						}
					}
					else{
					?>
					<td>
						<tr>
							Databse Empty
						</tr>
						<tr>
							Databse Empty
						</tr>
						<tr>
							Databse Empty
						</tr>
						<tr>
							Databse Empty
						</tr>
						<tr>
							Databse Empty
						</tr>
						<tr>
							Databse Empty
						</tr>
						<tr>
							Databse Empty
						</tr>
						<tr>
							No Query Available
						</tr>
					</td>
					<?php } ?>
				</table>
			</div>
		</div>
	</div>

</body>
</html>