<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$health_content = "";
	$message = "";

	if(isset($_POST['submit']))
	{
		$user_id = trim($_POST['user_id']);
		$health_content = trim($_POST['health_content']);

		add_health($user_id, $health_content);
		$message = "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> You have posted an article/s successfully!</div>";
		$health_content = "";
	}

	$healths = get_all_healths();

	if(isset($_GET['health_id'])){
		$health_id = $_GET['health_id'];
		del_health($health_id);
		header('Location: health.php');
	}

?>
<div class="container">
	<?php
		if(count($users)>0){
			foreach($users as $row){
				if($row['type'] == 'government' && $row['status'] == 'active' || $row['type'] == 'health' && $row['status'] == 'active'){
	?>
	<div class="thumbnail">
		<?php echo $message; ?>
		<form method="post">
			<div class="form-group">
				<input type="hidden" name="user_id" value="<?php echo htmlentities($row['user_id']); ?>">
				<label class="control-label">Post article about health</label>
				<textarea name="health_content" class="form-control" placeholder="Enter article" required></textarea>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Post">
				<input type="reset" name="" class="btn btn-default" value="Cancel">
			</div>
		</form>
	</div>
	<?php
			}
		}
	}
	?>

	<?php
		if(count($healths)>0){
			foreach($healths as $row){
	?>
	<div class="content-container">
		<div class="content">
			<?php
				if(!empty($row['profilepicture'])){
			?>
			<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b></span>
			<?php
			}
			else{
			?>
			<span><img src="images/img_avatar3.png" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b></span>
			<?php } ?>
			<span><b><?php echo htmlentities($row['health_content']); ?></b></span>
		</div>

		<?php
		if($row['user_id'] == $_SESSION['user_id'] && $row['type'] == 'government'){
		?>
		<div class="query">
			<a href="edit-health.php?health_id=<?php echo htmlentities($row['health_id']); ?>">Edit</a> | <a href="health.php?health_id=<?php echo htmlentities($row['health_id']) ?>" onclick="return confirm('Are you sure you want to delete this?')">Delete</a>
		</div>
		<?php
		}
		elseif($row['user_id'] == $_SESSION['user_id'] && $row['type'] == 'health'){
		?>
		<div class="query">
			<a href="edit-health.php?health_id=<?php echo htmlentities($row['health_id']); ?>">Edit</a> | <a href="health.php?health_id=<?php echo htmlentities($row['health_id']) ?>" onclick="return confirm('Are you sure you want to delete this?')">Delete</a>
		</div>
		<?php } ?>

	</div>
	<?php
		}
	}
	?>
</div>