<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$insurance_content = "";
	$message = "";

	if(isset($_POST['submit']))
	{
		$user_id = trim($_POST['user_id']);
		$insurance_content = trim($_POST['insurance_content']);

		add_insurance($user_id, $insurance_content);
		$message = "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> You have posted an insurance/s update successfully!</div>";
		$insurance_content = "";
	}

	$insurances = get_all_insurances();

	if(isset($_GET['insurance_id'])){
		$insurance_id = $_GET['insurance_id'];
		del_insurance($insurance_id);
		header('Location: insurances.php');
	}
?>
<div class="container">
	<?php
		if(count($users)>0){
			foreach($users as $row){
				if($row['type'] == 'insurance' && $row['status'] == 'active' || $row['type'] == 'government' && $row['status'] == 'active'){
	?>
	<div class="thumbnail">
		<?php echo $message; ?>
		<form method="post">
			<input type="hidden" name="user_id" value="<?php echo htmlentities($row['user_id']); ?>">
			<div class="form-group">
				<label class="control-label">Post Insurance</label>
				<textarea name="insurance_content" class="form-control" placeholder="Enter insurance" required><?php echo $insurance_content; ?></textarea>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Post">
				<input type="reset" name="" class="btn btn-default" value="Cancel">
			</div>
		</form>
	</div>
	<?php
			}
		}
	}
	?>

	<?php
		if(count($insurances)>0){
			foreach($insurances as $row){
	?>
	<div class="content-container">
		<div class="content">
			<?php
				if(!empty($row['profilepicture'])){
			?>
			<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b></span>
			<?php
			}
			else{
			?>
			<span><img src="images/img_avatar3.png" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b></span>
			<?php } ?>
			<span><b><?php echo htmlentities($row['insurance_content']); ?></b></span>
		</div>

		<?php
		if($row['user_id'] == $_SESSION['user_id'] && $row['type'] == 'government'){
		?>
		<div class="query">
			<a href="edit-insurance.php?insurance_id=<?php echo htmlentities($row['insurance_id']); ?>">Edit</a> | <a href="insurances.php?insurance_id=<?php echo htmlentities($row['insurance_id']) ?>" onclick="return confirm('Are you sure you want to delete this?')">Delete</a>
		</div>
		<?php
		}
		elseif($row['user_id'] == $_SESSION['user_id'] && $row['type'] == 'insurance'){
		?>
		<div class="query">
			<a href="edit-insurance.php?insurance_id=<?php echo htmlentities($row['insurance_id']); ?>">Edit</a> | <a href="insurances.php?insurance_id=<?php echo htmlentities($row['insurance_id']) ?>" onclick="return confirm('Are you sure you want to delete this?')">Delete</a>
		</div>
		<?php } ?>
	</div>
	<?php
		}
	}
	?>
</div>