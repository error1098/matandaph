<?php
	$date = date('Y-m-d');
	$cdate = date_create($date);
	$tdate = date_format($cdate, "F d, Y");

	$bdate = date_create('1951-11-12');
	$birthday = date_format($bdate, "F d, Y");

	$age = $tdate - $birthday;
	echo $age;
?>