<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	if(isset($_GET['health_id'])){
		$health_id = $_GET['health_id'];
		$edithealth = get_health($health_id);
	}

	$health_content = "";

	if(isset($_POST['submit']))
	{
		$health_content = trim($_POST['health_content']);
		edit_health($health_id, $health_content);
		header('Location: health.php');
	}
?>
<div class="container">
	<div class="thumbnail">
		<form method="post">
			<div class="form-group">
				<label class="control-label">Post article about health</label>
				<textarea name="health_content" class="form-control" required><?php echo htmlentities($edithealth['health_content']); ?></textarea>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Edit">
				<a href="health.php" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
</div>