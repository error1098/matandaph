<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	if(isset($_GET['insurance_id'])){
		$insurance_id = $_GET['insurance_id'];
		$editinsurance = get_insurance($insurance_id);
	}

	$insurance_content = "";

	if(isset($_POST['submit']))
	{
		$insurance_content = trim($_POST['insurance_content']);
		edit_insurance($insurance_id, $insurance_content);
		header('Location: insurances.php');
	}

?>
<div class="container">
	<div class="thumbnail">
		<form method="post">
			<div class="form-group">
				<label class="control-label">Post Insurance</label>
				<textarea name="insurance_content" class="form-control" required><?php echo htmlentities($editinsurance['insurance_content']); ?></textarea>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Edit">
				<a href="insurances.php" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
</div>