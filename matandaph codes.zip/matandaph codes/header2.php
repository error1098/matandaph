<?php
	include_once("matandaph.php");

	date_default_timezone_set('Asia/Manila');

	if(user_islogin()){
		header('Location: user-homepage.php');
		exit();
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome to MatandaPH</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="css/homepage-design.css">
	<link rel="stylesheet" type="text/css" href="css/content-design.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<script type="text/javascript" src="bootstrap/js/jquery.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
</head>
<body>

	<nav class="navbar navbar-fixed-top">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigationbar">
        			<span class="icon-bar"></span>
        			<span class="icon-bar"></span>
        			<span class="icon-bar"></span> 
      			</button>
				<b><a href="index.php" class="navbar-brand">MatandaPH</a></b>
			</div>
			<div class="collapse navbar-collapse" id="navigationbar">
				<ul class="nav navbar-nav">
					<li><a href="#">ABOUT</a></li>
					<li><a href="#">USER CLASSIFICATION</a></li>
					<li><a href="#">INFORMATION SERVICE</a></li>
					<li><a href="#">PORTFOLIO</a></li>
					<li><a href="#">THE TEAM</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li>
						<a href="login.php"><span class="glyphicon glyphicon-log-in"></span> LOG IN</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

</body>
</html>