<?php
	include_once("header3.php");

	error_reporting( ~E_NOTICE );

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	if(isset($_GET['senior_id'])){
		$senior_id = $_GET['senior_id'];
		$editsenior = get_senior($senior_id);
		extract($editsenior);
	}

	$fname = "";
	$mname = "";
	$lname = "";
	$gender = "";
	$bplace = "";
	$region = ""; 
	$province = "";
	$city = "";
	$baranggay = ""; 
	$sitio = "";
	$contnum = "";
	$password = "";

	if(isset($_POST['submit']))
	{
		$senior_id = trim($_POST['senior_id']);
		$fname = trim($_POST['fname']);
		$mname = trim($_POST['mname']);
		$lname = trim($_POST['lname']);
		$gender = trim($_POST['gender']);
		$bdate = trim($_POST['bdate']);
		$bplace = trim($_POST['bplace']);
		$age = trim($_POST['age']);
		$region = trim($_POST['region']);
		$province = trim($_POST['province']);
		$city = trim($_POST['city']);
		$baranggay = trim($_POST['baranggay']);
		$sitio = trim($_POST['sitio']);
		$workexp = trim($_POST['workexp']);
		$contnum = trim($_POST['contnum']);
		$password = trim($_POST['password']);

		$seniorprofile = $_FILES['seniorprofile']['name'];
		$tmp_dir = $_FILES['seniorprofile']['tmp_name'];

		$medrecord = $_FILES['medrecord']['name'];
		$tmpdir = $_FILES['medrecord']['tmp_name'];

		if($seniorprofile){
			$upload_dir = "seniorprofilepic/";
			$img_ext = strtolower(pathinfo($seniorprofile, PATHINFO_EXTENSION));
			$valid_extenstions = array('jpeg', 'jpg', 'png');
			$seniorpic = rand(1000,10000).".".$img_ext;

			if(in_array($img_ext, $valid_extenstions)){
				move_uploaded_file($tmp_dir, $upload_dir.$seniorpic);
			}
			else{
				$message = "<div class='alert alert-danger'><b><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> Sorry only JPEG, JPG and PNG files are allowed.</b></div>";
			}
		}
		else{
			$seniorpic = $editsenior['seniorprofile'];
		}

		if($medrecord){
			$uploaddir = "seniormedrecord/";
			$imgext = strtolower(pathinfo($medrecord, PATHINFO_EXTENSION));
			$validextensions = array('jpg', 'jpeg', 'png');
			$medpic = rand(1000,10000).".".$imgext;

			if(in_array($imgext, $validextensions)){
				move_uploaded_file($tmpdir, $uploaddir.$medpic);
			}
			else{
				$message = "<div class='alert alert-danger'><b><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> Sorry only JPEG, JPG and PNG files are allowed.</b></div>";
			}

		}
		else{
			$medpic = $editsenior['medrecord'];
		}

		$current_date = date('Y-m-d');
		$cdate = date_create($current_date);
		$date_today = date_format($cdate, "F d");
		$birthday = date_create($bdate);
		$birthdate = date_format($birthday, "F d");
		if($birthdate == $date_today){
			$yearage = $current_date - $bdate;
			$age = $yearage;
		}
		else{
			$yearage = $current_date - $bdate;
			$age = $yearage - 1;
		}
		edit_senior($senior_id, $fname, $mname, $lname, $gender, $bdate, $bplace, $age, $region, $province, $city, $baranggay, $sitio, $medpic, $workexp, $contnum, $seniorpic, $password);
		?>
		<script>
			window.location.href="senior-profile.php?senior_id=<?php echo $senior_id; ?>type=<?php echo $type ?>";
		</script>
		<?php

	}

?>
<div class="container">
		<form method="post" enctype="multipart/form-data">
			<input type="hidden" name="senior_id" value="<?php echo htmlentities($editsenior['senior_id']); ?>">
			
			<div class="thumbnail">
				<div class="form-group">
					<?php
						if(empty($editsenior['seniorprofile'])){
					?>
					<span><img src="seniorprofilepic/senior3.jpg" class="media-object" width="100" height="100"></span>
					<?php
					}
					else{
					?>
					<span><img src="seniorprofilepic/<?php echo htmlentities($editsenior['seniorprofile']); ?>" width="100" height="100"></span>
					<?php } ?>
					<input type="file" name="seniorprofile" id="seniorprofile" accept="image/*">
				</div>
			</div>

			<div class="thumbnail">
				<div class="form-group">
					<label class="control-label">Senior Citizen's ID Number</label>
					<input type="text" name="seniorid" class="form-control" value="<?php echo htmlentities($editsenior['seniorid']); ?>" readonly>
				</div>
			</div>

			<div class="row">
				<div class="col-sm-6">
					<div class="thumbnail">
						<div class="form-group">
							<label class="control-label">First Name</label>
							<input type="text" name="fname" class="form-control" value="<?php echo htmlentities($editsenior['fname']); ?>" placeholder="First letter of the first name should be capital. Example: Juan" required>
						</div>

						<div class="form-group">
							<label class="control-label">Middle Name</label>
							<input type="text" name="mname" class="form-control" value="<?php echo htmlentities($editsenior['mname']); ?>" placeholder="First letter of the middle name should be capital. Example: Dela. (optional)">
						</div>

						<div class="form-group">
							<label class="control-label">Last Name</label>
							<input type="text" name="lname" class="form-control" value="<?php echo htmlentities($editsenior['lname']); ?>" placeholder="First letter of the last name should be capital. Example: Cruz" required>
						</div>
					</div>
				</div>

				<div class="col-sm-6">
					<div class="thumbnail">
						<div class="form-group">
							<label class="control-label">Gender</label>
							<select class="form-control" name="gender" required>
								<option>---Select Gender---</option>
								<option value="<?php echo 'Male'; ?>" <?php if($editsenior['gender'] == "Male"){ echo "selected"; } ?> >Male</option>
								<option value="<?php echo 'Female'; ?>" <?php if($editsenior['gender'] == "Female"){ echo "selected"; } ?> >Female</option>
							</select>
						</div>

						<div class="form-group">
							<label class="control-label">Date of Birth</label>
							<span style="color: #ccc;"><br>Legend: mm(BUWAN(01-12))/dd(PETSA(01-31))/yyyy(TUIG) sa imong adlawng natawhan</span>
							<input type="date" name="bdate" class="form-control" value="<?php
								$date=date_create($editsenior['bdate']);
								echo htmlentities(date_format($date, 'Y-m-d'));
							?>">
						</div>

						<!-- <label class="control-label">Date of Birth</label>
						<div class="row">
							<div class="col-sm-4">
								<div class="form-group">
									<select name="bmonth" class="form-control">
										<option>--Select Month--</option>
										<option value="January" <?php if($editsenior['bmonth'] == "January"){ echo "selected"; } ?> >January</option>
										<option value="Febuary" <?php if($editsenior['bmonth'] == "Febuary"){ echo "selected"; } ?> >Febuary</option>
										<option value="March" <?php if($editsenior['bmonth'] == "March"){ echo "selected"; } ?> >March</option>
										<option value="April" <?php if($editsenior['bmonth'] == "April"){ echo "selected"; } ?> >April</option>
										<option value="May" <?php if($editsenior['bmonth'] == "May"){ echo "selected"; } ?> >May</option>
										<option value="June" <?php if($editsenior['bmonth'] == "June"){ echo "selected"; } ?> >June</option>
										<option value="July" <?php if($editsenior['bmonth'] == "July"){ echo "selected"; } ?> >July</option>
										<option value="August" <?php if($editsenior['bmonth'] == "August"){ echo "selected"; } ?> >August</option>
										<option value="September" <?php if($editsenior['bmonth'] == "September"){ echo "selected"; } ?> >September</option>
										<option value="October" <?php if($editsenior['bmonth'] == "October"){ echo "selected"; } ?> >October</option>
										<option value="November" <?php if($editsenior['bmonth'] == "November"){ echo "selected"; } ?> >November</option>
										<option value="December" <?php if($editsenior['bmonth'] == "December"){ echo "selected"; } ?> >December</option>
									</select>
								</div>
							</div>

							<div class="col-sm-4">
								<div class="form-group">
									<select name="bdate" class="form-control">
										<option>--Select Date--</option>
										<?php for($i=1;$i<=31;$i++){ ?>
										<option value="<?php echo $i; ?>" <?php if($editsenior['bdate'] == $i){ echo "selected"; } ?> ><?php echo $i; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>

							<div class="col-sm-4">
								<div class="form-group">
									<select name="byear" class="form-control">
										<option>--Select Year--</option>
										<?php for($i=1890;$i<=1957;$i++){ ?>
										<option value="<?php echo $i; ?>" <?php if($editsenior['byear'] == $i){ echo "selected"; } ?> ><?php echo $i; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
						</div> -->

						<div class="form-group">
							<label class="control-label">Birth Place</label>
							<input type="text" name="bplace" class="form-control" value="<?php echo htmlentities($editsenior['bplace']); ?>" placeholder="Birth place should be complete. Example: Alaska Mambaling, Cebu City" required>
						</div>
					</div>
				</div>
			</div>

			<input type="hidden" name="age">

			<div class="thumbnail">
				<div class="form-group">
					<label class="control-label">Region</label>
					<select class="form-control" name="region" required>
						<option>---Select Region---</option>
						<option value="<?php echo htmlentities($editsenior['region']); ?>" <?php if($editsenior['region'] == "Region VII"){ echo "selected"; } ?> ><?php echo htmlentities($editsenior['region']); ?></option>
					</select>
				</div>

				<div class="form-group">
					<label class="control-label">Province</label>
					<select class="form-control" name="province" required>
						<option>---Select Province---</option>
						<option value="<?php echo htmlentities($editsenior['province']); ?>" <?php if($editsenior['province'] == "CEBU"){ echo "selected"; } ?> ><?php echo htmlentities($editsenior['province']); ?></option>
					</select>
				</div>

				<div class="form-group">
					<label class="control-label">City/Municipality</label>
					<select class="form-control" name="city" required>
						<option>---Select City/Municipality---</option>
						<option value="<?php echo htmlentities($editsenior['city']); ?>" <?php if($editsenior['city'] == "Cebu City"){ echo "selected"; } ?> ><?php echo htmlentities($editsenior['city']); ?></option>
					</select>
				</div>

				<div class="form-group">
					<label class="control-label">Baranggay</label>
					<input type="text" name="baranggay" class="form-control" value="<?php echo htmlentities($editsenior['baranggay']); ?>" placeholder="Enter baranggay. Example: Mambaling" required>
				</div>

				<div class="form-group">
					<label class="control-label">Sitio/Baranggay</label>
					<input type="text" name="sitio" class="form-control" value="<?php echo htmlentities($editsenior['sitio']); ?>" placeholder="Enter sitio/barrio. Example: Alaska" required>
				</div>
			</div>

			<div class="row">
				<div class="col-sm-6">
					<div class="thumbnail">
						<div class="form-group">
							<label class="control-label">Working Skill/s</label>
							<textarea class="form-control" name="workexp" placeholder="Please enter your working skills. You can write all your skills in this format.                                                                                  Example: Masonry, Carpentry, Painter, etc." required><?php echo htmlentities($editsenior['workexp']); ?></textarea>
						</div>
					</div>
				</div>

				<div class="col-sm-6">
					<div class="thumbnail">
						<div class="form-group">
							<label class="control-label">Medical Record/s</label>
							<label>Note: Please upload a picture of your current medical record. You can take a picture of it as long as it is clear and that medical record belongs to you.</label>
							<input type="file" name="medrecord" id="medrecord" accept="image/*">
						</div>
					</div>
				</div>
			</div>

			<div class="thumbnail">
				<div class="form-group">
					<label class="control-label">Phone/Telephone Number</label>
					<input type="text" name="contnum" class="form-control" value="<?php echo htmlentities($editsenior['contnum']); ?>" placeholder="You can use your own contact number or you can use other people's contact number that you know." required>
				</div>
			</div>

			<div class="thumbnail">
				<div class="form-group">
					<label class="control-label">Username</label>
					<input type="text" name="username" class="form-control" value="<?php echo htmlentities($editsenior['username']); ?>" placeholder="Usernamne" readonly>
				</div>

				<div class="form-group">
					<label class="control-label">Password</label>
					<input type="password" name="password" class="form-control" value="<?php echo htmlentities($editsenior['password']); ?>" placeholder="Password" required>
				</div>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Edit">
				<a href="senior-profile.php?senior_id=<?php echo htmlentities($row['senior_id']) ?>?type=<?php echo htmlentities($row['type']); ?>" class="btn btn-default">Cancel</a>
			</div>
		</form>
</div>