<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$notif_comment = "has posted a new event.";
	$event = "";
	$event_description = "";
	$event_location = "";
	$message = "";

	$current_date = date('Y-m-d');
	$current_time = date('h:i A');

	if(isset($_POST['submit']))
	{
		$user_id = trim($_POST['user_id']);
		$event = trim($_POST['event']);
		$event_organizer = trim($_POST['event_organizer']);
		$event_description = trim($_POST['event_description']);
		$event_location = trim($_POST['event_location']);
		$event_date = trim($_POST['event_date']);
		$event_start = trim($_POST['event_start']);
		$event_end = trim($_POST['event_end']);
		$posted_time = trim($_POST['posted_time']);

		$existing_date = find_date_event($event_date);
		if($existing_date){
			$message = "<div class='alert alert-danger'><b><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> Date Invalid. An event has been scheduled on the same date that you have entered. Please try another date.</b></div>";
		}
		elseif($event_date < $current_date){
			$message = "<div class='alert alert-danger'><b><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> Date Invalid. You can not enter a date that is behind the current date.</b></div>";
		}
		else{
			add_notification($user_id, $notif_comment, $posted_time);
			add_events($user_id, $event, $event_organizer, $event_description, $event_location, $event_date, $event_start, $event_end, $posted_time);
			$message = "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> You have posted an event/s successfully!</div>";
			$event = "";
			$event_description = "";
			$event_location = "";
			$event_date = "";
			$event_start = "";
			$event_end = "";
		}
	}

	$events = get_all_events();

	if(isset($_GET['event_id'])){
		$event_id = $_GET['event_id'];
		del_event($event_id);
		header('Location: events.php');
	}
?>
<div class="container">
	<?php
		if(count($users)>0){
			foreach($users as $row){
				if($row['type'] == 'government' && $row['status'] == 'active'){
	?>
	<div class="thumbnail">
		<?php echo $message; ?>
		<form method="post" enctype="multipart/form-data">
			<input type="hidden" name="user_id" value="<?php echo htmlentities($row['user_id']); ?>">
			<input type="hidden" name="notif_comment">

			<div class="form-group">
				<label class="control-label">Event/Activity Title</label>
				<input type="text" name="event" class="form-control" id="showform" placeholder="Enter event/activity" value="<?php echo $event; ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Event Organizer</label>
				<input type="text" name="event_organizer" class="form-control" value="<?php echo htmlentities($row['organization']); ?>" required>
			</div>

			<div id="form">
				<div class="form-group">
					<label class="control-label">Event Details</label>
					<textarea name="event_description" class="form-control" placeholder="Enter details" required><?php echo $event_description; ?></textarea>
				</div>

				<div class="form-group">
					<label class="control-label">Event Location</label>
					<input type="text" name="event_location" class="form-control" placeholder="Enter location" value="<?php echo $event_location; ?>" required>
				</div>

				<div class="form-group">
					<label class="control-label">Date of Event</label>
					<input type="date" name="event_date" class="form-control" id="showtime" required>
				</div>

				<div id="time">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-6">
								<label class="control-label">Time of Start of Event</label>
								<input type="time" name="event_start" class="form-control" required>
							</div>

							<div class="col-sm-6">
								<label class="control-label">Time of End of Event</label>
								<input type="time" name="event_end" class="form-control" required>
							</div>
						</div>
					</div>
				</div>

				<input type="hidden" name="posted_time" value="<?php echo date('Y-m-d h:ia'); ?>">

				<div class="form-group">
					<input type="submit" name="submit" class="btn btn-primary" value="Post">
					<input type="reset" name="" class="btn btn-default" id="hideform" value="Cancel">
				</div>
			</div>
		</form>
	</div>
	<?php
			}
		}
	}
	?>

	<?php
		if(count($events)>0){
			foreach($events as $row){
	?>
	<div class="content-container">
		<div class="content">
			<?php
				if(!empty($row['profilepicture'])){
			?>
			<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b><br /><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></span>
			<?php
			}
			else{
			?>
			<span><img src="images/img_avatar3.png" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b><br /><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></span>
			<?php } ?>

			<b><p><?php echo htmlentities($row['event']); ?></p>
			<span><?php echo htmlentities($row['event_description']);  echo " on ";
				$date=date_create($row['event_date']);
				echo date_format($date, "F d, Y, l");
				echo " from ";
				$stime=date_create($row['event_start']);
				echo date_format($stime, "h:i A");
				echo " to ";
				$etime=date_create($row['event_end']);
				echo date_format($etime, "h:i A"); 
				echo " at ";
				echo htmlentities($row['event_location']);
			?>
			</span></b>

			<?php
			if($row['event_date'] > $current_date){
			?>
				<div style="color: green;">Upcoming Event</div>
			<?php
			}
			elseif($row['event_date'] == $current_date){
			?>
				<div style="color: blue;">Today's Event</div>
			<?php
			}
			elseif($row['event_date'] < $current_date){
			?>
				<div style="color: red;">Yesterday's Event.</div>
			<?php } ?>
		</div>

			
		<?php
		if($row['user_id'] == $_SESSION['user_id'] && $row['type'] == 'government'){
		?>
		<div style="border-top: 1px solid #ccc; padding-top: 5px;">
			<a href="edit-event.php?event_id=<?php echo htmlentities($row['event_id']); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a> | <a href="events.php?event_id=<?php echo htmlentities($row['event_id']); ?>" onclick="return confirm('Are you sure you want to delete this?')"><span class="glyphicon glyphicon-remove"></span> Delete</a> | <a href="event-join-list.php?event_id=<?php echo htmlentities($row['event_id']); ?>"><span class="glyphicon glyphicon-list-alt"></span> List of Participants</a>
		</div>
		<?php } ?>

	</div>
	<?php
		}
	}
	?>
</div>

<script>
	$(document).ready(function(){
		$("#form").hide();
		$("#showform").click(function(){
			$("#form").slideDown();
		});

		$("#hideform").click(function(){
			$("#form").slideUp();
		});

		$("#time").hide();
		$("#showtime").click(function(){
			$("#time").slideToggle();
		});

	});
</script>