<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	if(isset($_GET['job_id'])){
		$job_id = $_GET['job_id'];
		$editjob = get_job($job_id);
	}

	$notif_comment = "has updated a post on jobs.";
	$posted_time = date('Y-m-d h:ia');

	if(isset($_POST['submit']))
	{
		$company_name = trim($_POST['company_name']);
		$job_title = trim($_POST['job_title']);
		$job_description = trim($_POST['job_description']);
		$job_location = trim($_POST['job_location']);
		$office_location = trim($_POST['office_location']);
		$office_time = trim($_POST['office_time']);
		$office_day = trim($_POST['office_day']);

		add_notification($user_id, $notif_comment, $posted_time);
		edit_job($job_id, $company_name, $job_title, $job_description, $job_location, $office_location, $office_time, $office_day);
		header('Location: jobs.php');
	}
?>
<div class="container">
	<div class="thumbnail">
		<form method="post">
			<input type="hidden" name="user_id" value="<?php echo htmlentities($editjob['user_id']); ?>">
			<input type="hidden" name="notif_comment">

			<div class="form-group">
				<label class="control-label">Employer</label>
				<input type="text" name="company_name" class="form-control" value="<?php echo htmlentities($editjob['company_name']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Job Title</label>
				<input type="text" name="job_title" class="form-control" value="<?php echo htmlentities($editjob['job_title']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Job Description/Qualification</label>
				<textarea name="job_description" class="form-control" required><?php echo htmlentities($editjob['job_description']); ?></textarea>
			</div>

			<div class="form-group">
				<label class="control-label">Job Location</label>
				<input type="text" name="job_location" class="form-control" value="<?php echo htmlentities($editjob['job_location']); ?>" required>

				<div class="form-group">
					<label class="control-label">Office Location</label>
					<input type="text" name="office_location" class="form-control" value="<?php echo htmlentities($editjob['office_location']); ?>" required>
				</div>

				<div class="form-group">
					<label class="control-label">Office Availability</label>
					<input type="text" name="office_time" class="form-control" value="<?php echo htmlentities($editjob['office_time']); ?>" required>
				</div>

				<div class="form-group">
					<label class="control-label">Day of Office Availability</label>
					<input type="text" name="office_day" class="form-control" value="<?php echo htmlentities($editjob['office_day']); ?>" required>
				</div>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Edit">
				<a href="jobs.php" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
</div>