<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$notif_comment = "has posted a new law.";
	$law_title = "";
	$law_content = "";

	$message = "";
	if(isset($_POST['submit']))
	{
		$user_id = trim($_POST['user_id']);
		$law_title = trim($_POST['law_title']);
		$law_content = trim($_POST['law_content']);
		$posted_time = trim($_POST['posted_time']);

		add_notification($user_id, $notif_comment, $notif_link, $posted_time);
		add_senior_law($user_id, $law_title, $law_content, $posted_time);
		$message = "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> You have posted the law successfully!</div>";
		$law_title = "";
		$law_content = "";
	}

	$seniorlaw = get_all_senior_law();

	if(isset($_GET['law_id'])){
		$law_id = $_GET['law_id'];
		del_senior_law($law_id);
		header('Location: seniorlaw.php');
	}

?>
<div class="container">
	<?php
		if(count($users)){
			foreach($users as $row){
	?>
	<div class="thumbnail">
		<?php echo $message; ?>
		<form method="post">
			<input type="hidden" name="user_id" value="<?php echo htmlentities($row['user_id']); ?>">
			<input type="hidden" name="notif_comment">

			<div class="form-group">
				<label class="control-label">Law Title</label>
				<input type="text" name="law_title" class="form-control" placeholder="Post title" value="<?php echo $law_title; ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Law Content</label>
				<textarea name="law_content" class="form-control" placeholder="Post law" required><?php echo $law_content; ?></textarea>
			</div>

			<input type="hidden" name="posted_time" value="<?php echo date('Y-m-d h:ia'); ?>">

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Post">
				<input type="reset" name="" class="btn btn-default" value="Cancel">
			</div>
		</form>
	</div>
	<?php
		}
	}
	?>

	<?php
		if(count($seniorlaw)>0){
			foreach($seniorlaw as $row){
	?>
	<div class="content-container">
		<div class="content">
			<?php
			if(!empty($row['profilepicture'])){
			?>
			<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b><br /><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></span>
			<?php
			}
			else{
			?>
			<span><img src="images/img_avatar3.png" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b><br /><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></span>
			<?php } ?>
			<span><b><?php echo htmlentities($row['law_title']); ?></b></span>
			<span><b><?php echo htmlentities($row['law_content']); ?></b></span>
		</div>

		<?php
		if($row['user_id'] == $_SESSION['user_id'] && $row['type'] == 'government'){
		?>
		<div style="border-top: 1px solid #ccc; padding-top: 5px; margin-top: 15px;">
			<a href="edit-law.php?law_id=<?php echo htmlentities($row['law_id']); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a> | <a href="seniorlaw.php?law_id=<?php echo htmlentities($row['law_id']) ?>" onclick="return confirm('Are you sure you want to delete this?')"><span class="glyphicon glyphicon-remove"></span> Delete</a>
		</div>
		<?php } ?>

	</div>
	<?php
		}
	}
	?>
</div>