<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$job_id = $_GET['job_id'];
	$applylist = job_application_list($job_id)
?>
<div class="container">
	<div class="thumbnail">
		<h3>List of applicants who applied the job.</h3>
		<table class="table table-bordered table-striped table-hover table-condensed table-responsive">
			<tr class="info">
				<td>Job Title</td>
				<td>Employer</td>
				<td>Job Location</td>
				<td>Applicant's Senior Citizen ID</td>
				<td>Applicant's Name</td>
				<td>Applicant's Date of Birth</td>
				<td>Applicant's Age</td>
				<td>Applicant's Gender</td>
				<td>Applicant's Address</td>
				<td>Applicant's Working Skills</td>
				<td>Applicant's Contact Number</td>
				<td>Applicant's Picture</td>
			</tr>

			<?php
				if(count($applylist)>0){
					foreach($applylist as $row){
			?>
			<tr>
				<td>
					<?php echo htmlentities($row['job_title']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['company_name']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['job_location']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['seniorid']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['fname']." ".$row['mname']." ".$row['lname']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['bmonth']." ".$row['bdate'].", ".$row['byear']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['age']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['gender']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['sitio']." ".$row['baranggay'].", ".$row['city']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['workexp']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['contnum']); ?>
				</td>
				<td>
					<img src="seniorprofilepic/<?php echo htmlentities($row['seniorprofile']); ?>" width="60" height="60">
				</td>
			</tr>
			<?php
				}
			}
			?>
		</table>
	</div>
</div>