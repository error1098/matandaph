<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$notif_comment = "has posted a new job opening.";
	$message = "";

	if(isset($_POST['submit']))
	{
		$user_id = trim($_POST['user_id']);
		$company_name = trim($_POST['company_name']);
		$job_title = trim($_POST['job_title']);
		$job_description = trim($_POST['job_description']);
		$job_location = trim($_POST['job_location']);
		$office_location = trim($_POST['office_location']);
		$office_time = trim($_POST['office_time']);
		$office_day = trim($_POST['office_day']);
		$posted_time = trim($_POST['posted_time']);

		add_notification($user_id, $notif_comment, $posted_time);
		add_jobs($user_id, $company_name, $job_title, $job_description, $job_location, $office_location, $office_time, $office_day, $posted_time);
		$message = "<div class='alert alert-info'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> You have posted a job/s successfully!</div>";
		$company_name = "";
		$job_title = "";
		$job_description = "";
		$job_location = "";
	}

	$jobs = get_all_jobs();

	if(isset($_GET['job_id'])){
		$job_id = $_GET['job_id'];
		del_job($job_id);
		header('Location: jobs.php');
	}

?>
<div class="container">
	<?php
		if(count($users)>0){
			foreach($users as $row){
				if($row['type'] == 'government' || $row['type'] == 'private' && $row['status'] == 'active'){
	?>
	<div class="thumbnail">
		<?php echo $message; ?>
		<form method="post">
			<input type="hidden" name="user_id" value="<?php echo htmlentities($row['user_id']); ?>">
			<input type="hidden" name="notif_comment">

			<div class="form-group">
				<label class="control-label">Employer</label>
				<input type="text" name="company_name" class="form-control" value="<?php echo htmlentities($row['organization']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Job Title</label>
				<input type="text" name="job_title" class="form-control" placeholder="Enter job title" id="jobtitle" required>
			</div>

			<div id="showform">
				<div class="form-group">
					<label class="control-label">Job Description/Qualification</label>
					<textarea name="job_description" class="form-control" placeholder="Enter job description/qualification" required></textarea>
				</div>

				<div class="form-group">
					<label class="control-label">Job Location</label>
					<input type="text" name="job_location" class="form-control" placeholder="Enter location" required>
				</div>

				<div class="form-group">
					<label class="control-label">Office Location</label>
					<input type="text" name="office_location" class="form-control" placeholder="Please indicate your office's location" required>
				</div>

				<div class="form-group">
					<label class="control-label">Office Availability</label>
					<input type="text" name="office_time" class="form-control" placeholder="Please indicate the time of when your office is available. Example: 07:00am to 5:00pm" required>
				</div>

				<!-- <div class="form-group">
					<label class="control-label">Day of Office Availability</label>
					<input type="text" name="office_day" class="form-control" placeholder="Please indicate the day your office is available. Example: Monday to Friday" required>
				</div> -->

				<div class="form-group">
					<label class="control-label">Day of Office Availability</label>
					<select name="office_day" class="form-control">
						<option>Monday-Friday</option>
						<option>Monday-Saturday</option>
						<option>Monday-Sunday</option>
					</select>
				</div>

				<input type="hidden" name="posted_time" value="<?php echo date('Y-m-d h:ia'); ?>">

				<div class="form-group">
					<input type="submit" name="submit" class="btn btn-primary" value="Post">
					<input type="reset" name="" class="btn btn-default" value="Cancel" id="cancel">
				</div>
			</div>
		</form>
	</div>
	<?php
			}
		}
	}
	?>

	<?php
		if(count($jobs)>0){
			foreach($jobs as $row){
	?>
	<div class="content-container">
		<div class="content">
			<?php
				if(!empty($row['profilepicture'])){
			?>
			<span><img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b><br /><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></span>
			<?php
			}
			else{
			?>
			<span><img src="images/img_avatar3.png" class="profile-pic"> <b class="posted-by"><?php echo htmlentities($row['organization']); ?></b><br /><span style="color: #ccc;">Posted on <?php $date=date_create($row['posted_time']); echo date_format($date, 'F d, Y h:ia'); ?></span></span>
			<?php } ?>
			<p><b><?php echo htmlentities($row['company_name']); ?></b> is currently looking for <b><?php echo htmlentities($row['job_title']); ?></b></p>
			<p>Job Description/Qualification
			<span><b><?php echo htmlentities($row['job_description']); ?></b></p>
			<p>Job Location: <b><?php echo htmlentities($row['job_location']); ?></p></b></span>
			<span><b>Our office located at <?php echo htmlentities($row['office_location']); ?> every <?php echo htmlentities($row['office_time']); ?> from <?php echo htmlentities($row['office_day']); ?></b></span>
		</div>

		<?php
		if($row['user_id'] == $_SESSION['user_id'] && $row['type'] == 'government'){
		?>
		<div style="border-top: 1px solid #ccc; padding-top: 5px; margin-top: 15px;">
			<a href="edit-job.php?job_id=<?php echo htmlentities($row['job_id']); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a> | <a href="jobs.php?job_id=<?php echo htmlentities($row['job_id']) ?>" onclick="return confirm('Are you sure you want to delete this?')"><span class="glyphicon glyphicon-remove"></span> Delete</a> | <a href="job-application-list.php?job_id=<?php echo htmlentities($row['job_id']); ?>"><span class="glyphicon glyphicon-list-alt"></span> List of Applicants</a>
		</div>
		<?php
		}
		elseif($row['user_id'] == $_SESSION['user_id'] && $row['type'] == 'private'){
		?>
		<div style="border-top: 1px solid #ccc; padding-top: 5px; margin-top: 15px;">
			<a href="edit-job.php?job_id=<?php echo htmlentities($row['job_id']); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a> | <a href="jobs.php?job_id=<?php echo htmlentities($row['job_id']) ?>" onclick="return confirm('Are you sure you want to delete this?')"><span class="glyphicon glyphicon-remove"></span> Delete</a> | <a href="job-application-list.php?job_id=<?php echo htmlentities($row['job_id']); ?>"><span class="glyphicon glyphicon-list-alt"></span> List of Applicants</a>
		</div>
		<?php } ?>
	</div>
	<?php
		}
	}
	?>
</div>


<script>
	$(document).ready(function(){
		$("#showform").hide();
		$("#jobtitle").click(function(){
			$("#showform").slideDown();
		});

		$("#cancel").click(function(){
			$("#showform").slideUp();
		});
	});
</script>