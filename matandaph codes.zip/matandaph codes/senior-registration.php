<?php
	include_once("matandaph.php");

	error_reporting( ~E_NOTICE );

	$seniorid = "";
	$fname = "";
	$mname = "";
	$lname = "";
	$gender = "";
	$bplace = "";
	$region = ""; 
	$province = "";
	$city = "";
	$baranggay = ""; 
	$sitio = "";
	$workexp = "";
	$contnum = "";
	$username = "";
	$password = "";
	$type = "";
	$status = "";

	$message = "";
	if(isset($_POST['submit']))
	{
		$seniorid = trim($_POST['seniorid']);
		$fname = trim($_POST['fname']);
		$mname = trim($_POST['mname']);
		$lname = trim($_POST['lname']);
		$gender = trim($_POST['gender']);
		$bdate = trim($_POST['bdate']);
		$bplace = trim($_POST['bplace']);
		$age = trim($_POST['age']);
		$region = trim($_POST['region']);
		$province = trim($_POST['province']);
		$city = trim($_POST['city']);
		$baranggay = trim($_POST['baranggay']);
		$sitio = trim($_POST['sitio']);
		$workexp = trim($_POST['workexp']);
		$contnum = trim($_POST['contnum']);
		$username = trim($_POST['username']);
		$password = trim($_POST['password']);
		$type = trim($_POST['type']);
		$status = trim($_POST['status']);

		$medrecord = $_FILES['medrecord']['name'];
		$tmp_dir = $_FILES['medrecord']['tmp_name'];

		$upload_dir = "seniormedrecord/";
		$imgext = strtolower(pathinfo($medrecord, PATHINFO_EXTENSION));
		$valid_extensions = array('jpg', 'jpeg', 'png');
		$medpic = rand(1000,10000).".".$imgext;

		if(in_array($imgext, $valid_extensions)){
			move_uploaded_file($tmp_dir, $upload_dir.$medpic);
		}
		else{
			$message = "<div class='alert alert-danger'><b><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> Sorry only JPEG, JPG and PNG files are allowed.</b></div>";
		}

		$existing_seniorid = find_senior_id($seniorid);
		if($existing_seniorid){
			$message = "<div class='alert alert-danger'>Senior Citizen's ID already exist.</div>";
		}
		else{
			$current_date = date('Y-m-d');
			$cdate = date_create($current_date);
			$date_today = date_format($cdate, "F d");
			$birthday = date_create($bdate);
			$birthdate = date_format($birthday, "F d");
			if($birthdate == $date_today){
				$yearage = $current_date - $bdate;
				$age = $yearage;
			}
			else{
				$yearage = $current_date - $bdate;
				$age = $yearage - 1;
			}

			add_senior($seniorid, $fname, $mname, $lname, $gender, $bdate, $bplace, $age, $region, $province, $city, $baranggay, $sitio, $medrecord, $workexp, $contnum, $username, $password, "senior", "0");


			$message = "<div class='alert alert-info'>You have successfully registered.</div>";

			$seniorid = "";
			$fname = "";
			$mname = "";
			$lname = "";
			$gender = "";
			$bplace = "";
			$region = ""; 
			$province = "";
			$city = "";
			$baranggay = ""; 
			$sitio = "";
			$medrecord = "";
			$workexp = "";
			$username = "";
			$password = "";
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Senior Citizen's Registration Form</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="css/registration.css">
	<script type="text/javascript" src="bootstrap/js/jquery.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
</head>
<body>

	<nav class="navbar navbar-default navbar-static-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigationbar">
        			<span class="icon-bar"></span>
        			<span class="icon-bar"></span>
        			<span class="icon-bar"></span> 
      			</button>
				<b><a href="index.php" class="navbar-brand">MatandaPH</a></b>
			</div>

			<ul class="nav navbar-nav navbar-right">
				<li><a href="login.php"><span class="glyphicon glyphicon-chevron-left"></span> back</a></li>
			</ul>
		</div>
	</nav>

	<div class="container">
		<form method="post" enctype="multipart/form-data">
			<?php echo $message; ?>
			<div class="thumbnail">
				<div class="form-group">
					<label class="control-label">Senior Citizen's ID Number</label>
					<input type="text" name="seniorid" class="form-control" value="<?php echo $seniorid; ?>" placeholder="Enter senior citizen Id number" required>
				</div>
			</div>

			<div class="row">

				<div class="col-sm-6">
					<div class="thumbnail">
						<div class="form-group">
							<label class="control-label">First Name</label>
							<input type="text" name="fname" class="form-control" value="<?php echo $fname; ?>" placeholder="First letter of the first name should be capital. Example: Juan" required>
						</div>

						<div class="form-group">
							<label class="control-label">Middle Name/Initial</label>
							<input type="text" name="mname" class="form-control" value="<?php echo $mname ?>" placeholder="First letter of the middle name/initial should be capital. Example: Dela or D. (optional)">
						</div>

						<div class="form-group">
							<label class="control-label">Last Name</label>
							<input type="text" name="lname" class="form-control" value="<?php echo $lname; ?>" placeholder="First letter of the last name should be capital. Example: Cruz" required>
						</div>
					</div>
				</div>

				<div class="col-sm-6">
					<div class="thumbnail">
						<div class="form-group">
							<label class="control-label">Gender</label>
							<select class="form-control" name="gender" required>
								<option>---Select Gender---</option>
								<option>Male</option>
								<option>Female</option>
							</select>
						</div>

						<div class="form-group">
							<label class="control-label">Date of Birth</label>
							<span style="color: #ccc;"><br>Legend: mm(BUWAN(01-12))/dd(PETSA(01-31))/yyyy(TUIG) sa imong adlawng natawhan</span>
							<input type="date" name="bdate" class="form-control">
						</div>

						<!-- <label class="control-label">Date of Birth</label>
						<div class="row">
							<div class="col-sm-4">
								<div class="form-group">
									<select name="bmonth" class="form-control">
										<option>--Select Month--</option>
										<option>January</option>
										<option>Febuary</option>
										<option>March</option>
										<option>April</option>
										<option>May</option>
										<option>June</option>
										<option>July</option>
										<option>August</option>
										<option>September</option>
										<option>October</option>
										<option>November</option>
										<option>December</option>
									</select>
								</div>
							</div>

							<div class="col-sm-4">
								<div class="form-group">
									<select name="bdate" class="form-control">
										<option>--Select Date--</option>
										<?php for($i=1;$i<=31;$i++){ ?>
										<option><?php echo $i; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>

							<div class="col-sm-4">
								<div class="form-group">
									<select name="byear" class="form-control">
										<option>--Select Year--</option>
										<?php for($i=1890;$i<=1957;$i++){ ?>
										<option><?php echo $i; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
						</div> -->

						<div class="form-group">
							<label class="control-label">Birth Place</label>
							<input type="text" name="bplace" class="form-control" value="<?php echo $bplace; ?>" placeholder="Birth place should be complete. Example: Alaska Mambaling, Cebu City" required>
						</div>
					</div>
				</div>
			</div>

			<input type="hidden" name="age">

			<div class="thumbnail">
				<div class="form-group">
					<label class="control-label">Region</label>
					<select class="form-control" name="region" required>
						<option>---Select Region---</option>
						<option>Region VII</option>
					</select>
				</div>

				<div class="form-group">
					<label class="control-label">Province</label>
					<select class="form-control" name="province" required>
						<option>---Select Province---</option>
						<option>CEBU</option>
					</select>
				</div>

				<div class="form-group">
					<label class="control-label">City/Municipality</label>
					<select class="form-control" name="city" required>
						<option>---Select City/Municipality---</option>
						<option>Cebu City</option>
					</select>
				</div>

				<div class="form-group">
					<label class="control-label">Baranggay</label>
					<input type="text" name="baranggay" class="form-control" value="<?php echo $baranggay; ?>" placeholder="Enter baranggay. Example: Mambaling" required>
				</div>

				<div class="form-group">
					<label class="control-label">Sitio/Baranggay</label>
					<input type="text" name="sitio" class="form-control" value="<?php echo $sitio; ?>" placeholder="Enter sitio/barrio. Example: Alaska" required>
				</div>
			</div>

			<div class="row">
				<div class="col-sm-6">
					<div class="thumbnail">
						<div class="form-group">
							<label class="control-label">Working Skill/s</label>
							<textarea class="form-control" name="workexp" placeholder="Please enter your working skills. You can write all your skills in this format.                                                                                  Example: 																									Masonry																										Carpentry 																										Painter																											Programmer 																										 etc.." required><?php echo $workexp; ?></textarea>
						</div>
					</div>
				</div>

				<div class="col-sm-6">
					<div class="thumbnail">
						<div class="form-group">
							<label class="control-label">Medical Record/s</label>
							<label>Note: Please upload a picture of your current medical record. You can take a picture of it as long as it is clear and that medical record belongs to you.</label>
							<input type="file" name="medrecord" id="medrecord" accept="image/*" required>
						</div>
					</div>
				</div>
			</div>

			<div class="thumbnail">
				<div class="form-group">
					<label class="control-label">Phone/Telephone Number</label>
					<input type="text" name="contnum" class="form-control" placeholder="You can use your own contact number or you can use other people's contact number that you know." required>
				</div>
			</div>

			<div class="thumbnail">
				<div class="form-group">
					<label class="control-label">Username</label>
					<input type="text" name="username" class="form-control" value="<?php echo $username; ?>" placeholder="Usernamne" required>
				</div>

				<div class="form-group">
					<label class="control-label">Password</label>
					<input type="password" name="password" class="form-control" value="<?php echo $password; ?>" placeholder="Password" required>
				</div>
			</div>

			<input type="hidden" name="type">
			<input type="hidden" name="status">

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Register">
				<input type="reset" name="" class="btn btn-default" value="Cancel">
			</div>
		</form>
	</div>

</body>
</html>