<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
	}

	if(isset($_GET['service_id'])){
		$service_id = $_GET['service_id'];
		$editservice = get_service($service_id);
	}

	$service = "";
	$service_offer = "";
	$service_date = "";
	$service_start = "";
	$service_end = "";
	$service_location = "";
	$message = "";

	$current_date = date('Y-m-d');
	//$current_time = date('h:i A');

	$notif_comment = "has updated a post on services.";
	$posted_time = date('Y-m-d h:ia');

	if(isset($_POST['submit']))
	{
		$service = trim($_POST['service']);
		$service_offer = trim($_POST['service_offer']);
		$service_date = trim($_POST['service_date']);
		$service_start = trim($_POST['service_start']);
		$service_end = trim($_POST['service_end']);
		$service_location = trim($_POST['service_location']);


		if($service_date < $current_date){
			$message = "<div class='alert alert-danger'><b><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> Date Invalid. You can not enter a date that is behind the current date.</b></div>";
		}
		else{
			add_notification($user_id, $notif_comment, $posted_time);
			edit_service($service_id, $service, $service_offer, $service_date, $service_start, $service_end, $service_location);
			header('Location: services.php');
		}
	}
?>
<div class="container">
	<div class="thumbnail">
		<?php echo $message; ?>
		<form method="post">
			<input type="hidden" name="user_id" value="<?php echo htmlentities($editservice['user_id']); ?>">
			<input type="hidden" name="notif_comment">

			<div class="form-group">
				<label class="control-label">Service Title</label>
				<input type="text" name="service" class="form-control" id="showform" placeholder="Enter service title" value="<?php echo htmlentities($editservice['service']); ?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Service/s Offer</label>
				<textarea name="service_offer" class="form-control" id="showform" placeholder="Enter service/s" required><?php echo htmlentities($editservice['service_offer']); ?></textarea>
			</div>

			<div class="form-group">
				<label class="control-label">Date of Availability</label>
				<input type="date" name="service_date" class="form-control" value="<?php
					$date=date_create($editservice['service_date']);
					echo htmlentities(date_format($date, 'Y-m-d'));
				?>" required>
			</div>

			<div class="form-group">
				<label class="control-label">Time of Availability</label>
				<div class="row">
					<div class="col-sm-6">
						From <input type="time" name="service_start" class="form-control" value="<?php 
							$stime=date_create($editservice['service_start']);
							echo htmlentities(date_format($stime, 'H:i'));
						?>" required>
					</div>

					<div class="col-sm-6">
						To <input type="time" name="service_end" class="form-control" value="<?php
							$etime=date_create($editservice['service_end']);
							echo htmlentities(date_format($etime, 'H:i'));
						?>" required>
					</div>
				</div>
			</div>

			<div class="form-group">
				<label class="control-label">Service Location</label>
				<input type="text" name="service_location" class="form-control" placeholder="Enter location" value="<?php echo htmlentities($editservice['service_location']); ?>" required>
			</div>

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Post">
				<a href="services.php" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
</div>