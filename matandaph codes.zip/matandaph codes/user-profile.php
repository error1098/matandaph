<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$seniorproof = get_all_seniors_gov();

	$seniors = get_all_seniors();

	if(isset($_GET['senior_id'])){
		$senior_id = $_GET['senior_id'];
		edit_senior_status($senior_id, "1");
		?>
		<script>
			window.location.href="user-profile.php?user_id=<?php echo $user_id ?>?type=<?php echo $type; ?>";
		</script>
		<?php
	}

	$search_results = array();
	$keyword = "";
	if(isset($_POST['keyword'])){
		$keyword = trim($_POST['keyword']);
		$search_results = senior_search($keyword, $keyword);
	}
?>
<div class="container">
	<?php
		if(count($users)>0){
			foreach($users as $row){
	?>
	<div class="media">
		<div class="media-left media-top">
			<?php
			if(!empty($row['profilepicture'])){
			?>
			<img src="profilepictures/<?php echo htmlentities($row['profilepicture']); ?>" class="media-object" width="180" height="180">
			<?php
			}
			else{
			?>
			<img src="images/img_avatar3.png" class="media-object" width="170" height="180">
			<?php } ?>
			<h5><a href="user-profile-edit.php?user_id=<?php echo htmlentities($row['user_id']) ?>type=<?php echo htmlentities($row['type']); ?>">Edit Profile</a></h5>
		</div>

		<div class="media-body">
			<h1 class="media-heading">
				<?php echo htmlentities($row['organization']); ?>
			</h1>

			<h4 class="media-heading">
				<?php echo htmlentities($row['org_address']); ?>
			</h4>

			<h4 class="media-heading">
				<?php echo htmlentities($row['org_num']); ?>
			</h4>

			<h4 class="media-heading">
				<?php echo htmlentities($row['org_email']); ?>
			</h4>

			<h4 class="media-heading">
				<a href="<?php echo htmlentities($row['org_website']); ?>"><?php echo htmlentities($row['org_website']); ?></a>
			</h4>
		</div>
	</div>

	<hr>

	<?php
		if($row['organization'] == "Office of the Senior Citizens Affair"){
	?>
	
	<div class="row">
		<div class="col-sm-6">
			<div class="thumbnail">
				<h2>List of Registered Senior Citizens</h2>
				<div class="table-responsive">
					<table class="table table-striped table-bordered table-condensed">
						<tr class="info">
							<td>Senior Citizen's ID</td>
							<td>Name</td>
							<td>Date of Birth</td>
							<td>Place of Birth</td>
							<td>Gender</td>
							<td>Address</td>
							<td>Status</td>
							<td>Query</td>
						</tr>

						<?php
							if(count($seniors)>0){
								foreach($seniors as $row){
						?>
						<tr>
							<td><?php echo htmlentities($row['seniorid']); ?></td>
							<td><?php echo htmlentities($row['fname']." ".$row['mname']." ".$row['lname']); ?></td>
							<td><?php 
								$date=date_create($row['bdate']);
								echo date_format($date, "F d, Y");; ?></td>
							<td><?php echo htmlentities($row['bplace']); ?></td>
							<td><?php echo htmlentities($row['gender']); ?></td>
							<td><?php echo htmlentities($row['sitio'].", ".$row['baranggay'].", ".$row['city'].", ".$row['province']); ?></td>
							<td><?php echo htmlentities($row['status']); ?></td>
							<?php
								if($row['status'] == "0"){
							?>
							<td>
								<a href="osca-edit-senior-profile.php?senior_id=<?php echo htmlentities($row['senior_id']); ?>">Edit</a> | <a href="user-profile.php?senior_id=<?php echo htmlentities($row['senior_id']); ?>">Approve</a>
							</td>
							<?php
							}
							elseif($row['status'] == "1"){
							?>
							<td>
								<a href="osca-edit-senior-profile.php?senior_id=<?php echo htmlentities($row['senior_id']); ?>">Edit</a> | <label>Approved</label>
							</td>
							<?php } ?>
						</tr>
						<?php
							}
						}
						else{
						?>
						<td>
							<tr>Databse Empty</tr>
							<tr>Databse Empty</tr>
							<tr>Databse Empty</tr>
							<tr>Databse Empty</tr>
							<tr>Databse Empty</tr>
							<tr>Databse Empty</tr>
							<tr>Databse Empty</tr>
							<tr>No Query Available</tr>
						</td>
						<?php } ?>
					</table>
					<div>
						<h4>Total: <b><?php echo count($seniors); ?></b></h4>
					</div>
				</div>
			</div>
		</div>

		<div class="col-sm-6">
			<div class="thumbnail">
				<form method="post">
					<br>
					<div class="form-group">
						<label class="control-label">Search a Senior</label>
						<input type="text" name="keyword" class="form-control" placeholder="Search by senior citizen ID, or by name, or by age" value="<?php echo $keyword; ?>">
					</div>

					<div class="form-group">
						<button type="submit" name="submit" class="btn btn-primary" style="border-radius: 0px;">
							<i class="glyphicon glyphicon-search"></i> Search
						</button>
					</div>
				</form>

				<div class="table-responsive">
					<?php
						foreach($search_results as $row){
					?>
					<table class="table table-striped table-bordered table-condensed">
						<tr class="info">
							<td>Senior Citizen's ID</td>
							<td>Name</td>
							<td>Date of Birth</td>
							<td>Gender</td>
							<td>Age</td>
							<td>Address</td>
						</tr>

						<tr>
							<td><?php echo htmlentities($row['seniorid']); ?></td>
							<td><?php echo htmlentities($row['fname']." ".$row['mname']." ".$row['lname']); ?></td>
							<td><?php 
								$date=date_create($row['bdate']);
								echo date_format($date, "F d, Y");; ?></td>
							<td><?php echo htmlentities($row['gender']); ?></td>
							<td><?php echo htmlentities($row['age']); ?></td>
							<td><?php echo htmlentities($row['sitio'].", ".$row['baranggay'].", ".$row['city'].", ".$row['province']); ?></td>
						</tr>
					</table>
					<?php } ?>
					<div>
						<h4>Total: <b><?php echo count($search_results); ?></b></h4>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php } ?>

	<?php
		}
	}
	?>
</div>