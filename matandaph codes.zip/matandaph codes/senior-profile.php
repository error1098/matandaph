<?php
	include_once("header3.php");

	error_reporting( ~E_NOTICE );

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$senior_id = $_SESSION['senior_id'];
	$senior_join = senior_join_event($senior_id);
	$senior_acquire = senior_acquire_service($senior_id);
	$senior_apply = senior_apply_job($senior_id);

?>
<div class="container">
	<?php
		if(count($seniors)>0){
			foreach($seniors as $row){
	?>
	<div class="container">
		<?php
			$current_date = date('Y-m-d');
			$cdate = date_create($current_date);
			$date_today = date_format($cdate, "F d");
			$birthday = date_create($row['bdate']);
			$birthdate = date_format($birthday, "F d");
			if($birthdate == $date_today){
				$senior_id = $row['senior_id'];
				$birthdate = $row['bdate'];
				$age = $current_date - $birthdate;
				update_age($senior_id, $age);
		?>
		<div class="alert alert-info">
			<h5><b><span class="glyphicon glyphicon-gift"></span> TODAY IS YOUR BIRTHDAY! HAPPY BIRTHDAY TO YOU</b></h5>
		</div>
		<?php 
		}
		elseif($birthdate <= $date_today){
			$senior_id = $row['senior_id'];
			$birthdate = $row['bdate'];
			$age = $current_date - $birthdate;
			update_age($senior_id, $age);
		}
		?>

		<?php
			if($row['age'] >= 100){
		?>
		<div class="alert alert-info">
			<h5><b>IT'S YOUR CENTENIAL YEAR! BECAUSE OF THAT, YOU WILL RECEIVE A 100,000 PESO CASH FROM THE CEBU CITY GOVERNMENT AS PART OF THEIR PROGRAM ON GIVING 100,000 PESO CASH ON SENIOR CITIZENS WHO WILL REACH THEIR CENTENIAL YEARS.</b></h5>
		</div>
		<?php } ?>

		<div class="media">
			<div class="media-left media-top">
				<?php
					if(!empty($row['seniorprofile'])){
				?>
				<span><img src="seniorprofilepic/<?php echo htmlentities($row['seniorprofile']); ?>" class="media-object" width="200" height="200"></span>
				<?php
				}
				else{
				?>
				<span><img src="images/senior3.jpg" class="media-object" width="250" height="250"></span>
				<?php } ?>
			</div>

			<div class="media-body">
				<h1 class="media-heading">
					<b><?php echo htmlentities($row['fname']." ".$row['mname']." ".$row['lname']); ?></b>
				</h1>

				<h4><a href="senior-edit-profile.php?senior_id=<?php echo htmlentities($row['senior_id']); ?>type=<?php echo htmlentities($row['type']); ?>"><span class="glyphicon glyphicon-edit"></span> Edit Profile</a></h4>
			</div>
		</div>

		<hr />

		<ul class="nav nav-tabs nav-justified">
			<li class="active"><a href="#info" data-toggle="tab">SENIOR's ADDITIONAL INFORMATION</a></li>
			<li><a href="#join" data-toggle="tab">EVENTS JOINED</a></li>
			<li><a href="#apply" data-toggle="tab">JOBS APPLIED</a></li>
			<li><a href="#acquire" data-toggle="tab">SERVICES ACQUIRED</a></li>
		</ul>

		<div class="tab-content">
			<div id="info" class="tab-pane fade in active">
				<div>
					<div class="title">SENIOR CITIZEN ID</div>
					<div class="row">
						<div class="col-sm-6">
							<label class="info-text">Senior Citizen's ID Number</label>
						</div>

						<div class="col-sm-6">
							<div class="data-text"><?php echo htmlentities($row['seniorid']); ?></div>
						</div>
					</div>
				</div>

				<div>
					<div class="title">ADDRESS</div>
					<div class="row">
						<div class="col-sm-6">
							<label class="info-text">Region</label>
						</div>

						<div class="col-sm-6">
							<div class="data-text"><?php echo htmlentities($row['region']); ?></div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-6">
							<label class="info-text">Province</label>
						</div>

						<div class="col-sm-6">
							<div class="data-text"><?php echo htmlentities($row['province']); ?></div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-6">
							<label class="info-text">Current City</label>
						</div>

						<div class="col-sm-6">
							<div class="data-text"><?php echo htmlentities($row['city']); ?></div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-6">
							<label class="info-text">Current Place</label>
						</div>

						<div class="col-sm-6">
							<div class="data-text"><?php echo htmlentities($row['sitio'].", ".$row['baranggay']); ?></div>
						</div>
					</div>
				</div>

				<div>
					<div class="title">CONTACT INFO</div>
					<div class="row">
						<div class="col-sm-6">
							<label class="info-text">Mobile/Telephone Number</label>
						</div>

						<div class="col-sm-6">
							<div class="data-text"><?php echo htmlentities($row['contnum']); ?></div>
						</div>
					</div>
				</div>

				<div>
					<div class="title">BASIC INFO</div>
					<div class="row">
						<div class="col-sm-6">
							<label class="info-text">Birthday</label>
						</div>

						<div class="col-sm-6">
							<div class="data-text"><?php
							$date=date_create($row['bdate']);
							echo date_format($date, "F d, Y");
							?></div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-6">
							<label class="info-text">Age</label>
						</div>

						<div class="col-sm-6">
							<div class="data-text"><?php echo htmlentities($row['age']); ?></div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-6">
							<label class="info-text">Gender</label>
						</div>

						<div class="col-sm-6">
							<div class="data-text"><?php echo htmlentities($row['gender']); ?></div>
						</div>
					</div>
				</div>

				<div>
					<div class="title">PROFESSIONAL SKILLS</div>
					<div style="font-weight: bold; font-size: 20px; white-space: pre-line; text-align: justify-all;"><?php echo htmlentities($row['workexp']); ?></div>
				</div>

				<div>
					<div class="title">MEDICAL RECORD</div>
					<label class="info-text">Current Medical Record</label>
					<p>
						<img src="seniormedrecord/<?php echo htmlentities($row['medrecord']) ?>" width="100%">
					</p>
				</div>
			</div>

			<div id="join" class="tab-pane fade">
				<br>
				<table class="table table-bordered table-striped table-hover table-condensed table-responsive">
					<tr class="info">
						<td><b>Event</b></td>
						<td><b>Event Organizer</b></td>
						<td><b>Event Location</b></td>
						<td><b>Event Date & Time</b></td>
						<td><b>Date Registed</b></td>
					</tr>

					<?php
						if(count($senior_join)>0){
							foreach($senior_join as $row){
					?>
					<tr>
						<td>
							<?php echo htmlentities($row['event']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['event_organizer']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['event_location']); ?>
						</td>
						<td>
							<?php 
								$date=date_create($row['event_date']);
								echo date_format($date, 'l, F d, Y');
								echo " from ";
								$stime=date_create($row['event_start']);
								echo date_format($stime, 'h:ia');
								echo " to ";
								$etime=date_create($row['event_end']);
								echo date_format($etime, 'h:ia');
							 ?>
						</td>
						<td>
							<?php 
								$date=date_create($row['join_time']);
								echo date_format($date, 'l F d, Y h:ia');
							?>
						</td>
					</tr>
					<?php
						}
					}
					else{
					?>
					<br>
					<div class="alert alert-danger"><h1>YOU HAVEN'T JOIN ANY EVENTS YET.</h1></div>
					<?php } ?>
				</table>
			</div>

			<div id="apply" class="tab-pane fade">
				<br>
				<table class="table table-bordered table-striped table-hover table-condensed table-responsive">
					<tr class="info">
						<td><b>Company/Employer</b></td>
						<td><b>Job Title</b></td>
						<td><b>Job Description</b></td>
						<td><b>Job Location</b></td>
						<td><b>Date Applied</b></td>
					</tr>

					<?php
						if(count($senior_apply)>0){
							foreach($senior_apply as $row){
					?>
					<tr>
						<td>
							<?php echo htmlentities($row['company_name']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['job_title']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['job_description']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['job_location']); ?>
						</td>
						<td>
							<?php
								$date=date_create($row['applied_time']);
								echo date_format($date, 'l F d, Y h:ia');
							?>
						</td>
					</tr>
					<?php
						}
					}
					else{
					?>
					<br>
					<div class="alert alert-danger"><h1>YOU HAVEN'T APPLIED TO ANY JOBS YET.</h1></div>
					<?php } ?>
				</table>
			</div>

			<div id="acquire" class="tab-pane fade">
				<br>
				<table class="table table-bordered table-striped table-hover table-condensed table-responsive">
					<tr class="info">
						<td><b>Service</b></td>
						<td><b>Service/s Offer</b></td>
						<td><b>Service Date & Time</b></td>
						<td><b>Service Location</b></td>
						<td><b>Date Acquired</b></td>
					</tr>
					
					<?php
						if(count($senior_acquire)>0){
							foreach($senior_acquire as $row){
					?>
					<tr>
						<td>
							<?php echo htmlentities($row['service']); ?>
						</td>
						<td>
							<?php echo htmlentities($row['service_offer']); ?>
						</td>
						<td>
							<?php 
								$date=date_create($row['service_date']);
								echo date_format($date, 'l, F d, Y');
								echo " from ";
								$stime=date_create($row['service_start']);
								echo date_format($stime, 'h:ia');
								echo " to ";
								$etime=date_create($row['service_end']);
								echo date_format($etime, 'h:ia');
							 ?>
						</td>
						<td>
							<?php echo htmlentities($row['service_location']); ?>
						</td>
						<td>
							<?php 
								$date=date_create($row['acquired_time']);
								echo date_format($date, 'l F d, Y h:ia');
							?>
						</td>
					</tr>
					<?php
						}
					}
					else{
					?>
					<br>
					<div class="alert alert-danger"><h1>YOU HAVEN'T ACQUIRE ANY SERVICES YET.</h1></div>
					<?php } ?>
				</table>
			</div>
		</div>

	</div>
	<?php
		}
	}
	?>
</div>