<?php
	session_start();

	function matanda_ph(){
		return new PDO("mysql:host=localhost;dbname=capstone;", 'root', '');
	}
/*-----------------------------Admin Login-----------------------------*/
	
	function admin_login($username, $password){
		$db = matanda_ph();
		$sql = "SELECT * FROM admin WHERE username = ? AND password = ?";
		$query = $db->prepare($sql);
		$query->execute(array($username, $password));
		$admin = $query->fetch();
		$db = null;

		if($admin){
			$_SESSION['islogin'] = true;
			$_SESSION['admin_id'] = $admin['admin_id'];
			$_SESSION['username'] = $username;
			return true;
		}
		return false;
	}

/*-----------------------------Government Admin-----------------------------*/
	
	function govadmin_login($username, $password){
		$db = matanda_ph();
		$sql = "SELECT * FROM gov_admin WHERE username = ? AND password = ?";
		$query = $db->prepare($sql);
		$query->execute(array($username, $password));
		$govadmin = $query->fetch();
		$db = null;

		if($govadmin){
			$_SESSION['islogin'] = true;
			$_SESSION['govadmin_id'] = $govadmin['govadmin_id'];
			$_SESSION['username'] = $username;
			return true;
		}
		return false;
	}

	function get_all_seniors(){
		$db = matanda_ph();
		$sql = "SELECT * FROM senior_accounts ORDER BY senior_id DESC";
		$query = $db->prepare($sql);
		$query->execute();
		$show = $query->fetchAll();
		$db = null;

		return $show;
	}

	function get_all_seniors_gov(){
		$db = matanda_ph();
		$sql = "SELECT * FROM seniorcitizens ORDER BY seniors_id DESC";
		$query = $db->prepare($sql);
		$query->execute();
		$shows = $query->fetchAll();
		$db = null;

		return $shows;
	}

	function get_senior_status($senior_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM senior_accounts WHERE senior_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($senior_id));
		$senior = $query->fetch();
		$db = null;

		return $senior;
	}

	function edit_senior_status($senior_id, $status){
		$db = matanda_ph();
		$sql = "UPDATE senior_accounts SET status=? WHERE senior_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($status, $senior_id));
		$db = null;
	}


/*-----------------------------User Login-----------------------------*/

	function user_islogin(){
		if(isset($_SESSION['islogin']))
			return true;
		return false;
	}

	function user_logout(){
		unset($_SESSION['islogin']);
		unset($_SESSION['username']);
		unset($_SESSION['password']);
		session_destroy();
	}


	function user_login($username, $password){
		$db = matanda_ph();
		$sql = "SELECT * FROM user_accounts WHERE username = ? AND password = ?";
		$query = $db->prepare($sql);
		$query->execute(array($username, $password));
		$user = $query->fetch();

		if($user){
			$_SESSION['islogin'] = true;
			$_SESSION['user_id'] = $user['user_id'];
			$_SESSION['organization'] = $user['organization'];
			$_SESSION['type'] = $user['type'];
			$_SESSION['status'] = $user['status'];
			$_SESSION['username'] = $username;
			return true;
		}
		return false;
	}

/*-----------------------------Senior Registration-----------------------------*/

	function senior_login($username, $password){
		$db = matanda_ph();
		$sql = "SELECT * FROM senior_accounts WHERE username = ? AND password = ?";
		$query = $db->prepare($sql);
		$query->execute(array($username, $password));
		$user = $query->fetch();

		if($user){
			$_SESSION['islogin'] = true;
			$_SESSION['senior_id'] = $user['senior_id'];
			$_SESSION['fname'] = $user['fname'];
			$_SESSION['type'] = $user['type'];
			$_SESSION['status'] = $user['status'];
			return true;
		}
		return false;
	}

	function add_senior($seniorid, $fname, $mname, $lname, $gender, $bdate, $bplace, $age, $region, $province, $city, $baranggay, $sitio, $medrecord, $workexp, $contnum, $username, $password, $type, $status){
		$db = matanda_ph();
		$sql = "INSERT INTO senior_accounts(seniorid, fname, mname, lname, gender, bdate, bplace, age, region, province, city, baranggay, sitio, medrecord, workexp, contnum, username, password, type, status)VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($seniorid, $fname, $mname, $lname, $gender, $bdate, $bplace, $age, $region, $province, $city, $baranggay, $sitio, $medrecord, $workexp, $contnum, $username, $password, $type, $status));
		$db = null;
	}

	function find_senior_id($seniorid){
		$find = false;

		$db = matanda_ph();
		$sql = "SELECT * FROM senior_accounts WHERE seniorid = ?";
		$query = $db->prepare($sql);
		$query->execute(array($seniorid));
		$find = $query->fetch();
		$db = null;

		return $find;
	}

	function get_user_senior($senior_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM senior_accounts WHERE senior_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($senior_id));
		$user = $query->fetchAll();
		$db = null;

		return $user;
	}

	function get_senior($senior_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM senior_accounts WHERE senior_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($senior_id));
		$senior = $query->fetch();
		$db = null;

		return $senior;
	}

	function edit_senior($senior_id, $fname, $mname, $lname, $gender, $bdate, $bplace, $age, $region, $province, $city, $baranggay, $sitio, $medrecord, $workexp, $contnum, $seniorprofile, $password){
		$db = matanda_ph();
		$sql = "UPDATE senior_accounts SET fname=?, mname=?, lname=?, gender=?, bdate=?, bplace=?, age=?, region=?, province=?, city=?, baranggay=?, sitio=?, medrecord=?, workexp=?, contnum=?, seniorprofile=?, password=? WHERE senior_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($fname, $mname, $lname, $gender, $bdate, $bplace, $age, $region, $province, $city, $baranggay, $sitio, $medrecord, $workexp, $contnum, $seniorprofile, $password, $senior_id));
		$db = null;		
	}

	function update_age($senior_id, $age){
		$db = matanda_ph();
		$sql = "UPDATE senior_accounts SET age=? WHERE senior_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($age, $senior_id));
		$db = null;
	}

	function senior_search($keyword){
		$search_results = array();

		$db = matanda_ph();
		$sql = "SELECT * FROM senior_accounts WHERE seniorid LIKE ? OR age LIKE ?";
		$query = $db->prepare($sql);
		$keyword = "%". $keyword ."%";
		$query->execute(array($keyword, $keyword));
		$search_results = $query->fetchAll();
		$db = null;

		return $search_results;
	}

/*-----------------------------Notifications-----------------------------*/

	function add_notification($user_id, $notif_comment, $posted_time){
		$db = matanda_ph();
		$sql = "INSERT INTO notifications(user_id, notif_comment, posted_time)VALUES(?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($user_id, $notif_comment, $posted_time));
		$db = null;
	}

	function get_all_notification(){
		$db = matanda_ph();
		$sql = "SELECT * FROM notifications AS n INNER JOIN user_accounts AS ua ON n.user_id = ua.user_id ORDER BY notification_id DESC";
		$query = $db->prepare($sql);
		$query->execute();
		$show = $query->fetchAll();
		$db = null;

		return $show;
	}

	function get_notification(){
		$db = matanda_ph();
		$sql = "SELECT * FROM notifications WHERE notif_status = 0";
		$query = $db->prepare($sql);
		$query->execute();
		$notif = $query->fetchAll();
		$db = null;

		return $notif;
	}

	function edit_notification(){
		$db = matanda_ph();
		$sql = "UPDATE notifications SET notif_status=1 WHERE notif_status = 0";
		$query = $db->prepare($sql);
		$query->execute();
		$db = null;
	}


/*-----------------------------User Registration-----------------------------*/

	function find_user($organization){
		$find = false;

		$db = matanda_ph();
		$sql = "SELECT * FROM user_accounts WHERE organization = ?";
		$query = $db->prepare($sql);
		$query->execute(array($organization));
		$find = $query->fetch();
		$db = null;

		return $find;
	}

	function add_user($organization, $org_address, $org_num, $org_email, $org_website, $username, $password, $type, $status){
		$db = matanda_ph();
		$sql = "INSERT INTO user_accounts(organization, org_address, org_num, org_email, org_website, username, password, type, status)VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($organization, $org_address, $org_num, $org_email, $org_website, $username, $password, $type, $status));
		$db = null;
	}

	function get_user($user_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM user_accounts WHERE user_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($user_id));
		$user = $query->fetch();
		$db = null;

		return $user;
	}

	function edit_user_profile($user_id, $organization, $org_address, $org_num, $org_email, $org_website, $profilepicture, $password){
		$db = matanda_ph();
		$sql = "UPDATE user_accounts SET organization=?, org_address=?, org_num=?, org_email=?, org_website=?, profilepicture=?, password=? WHERE user_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($organization, $org_address, $org_num, $org_email, $org_website, $profilepicture, $password, $user_id));
		$db = null;
	}

	function get_users($user_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM user_accounts WHERE user_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($user_id));
		$user = $query->fetchAll();
		$db = null;

		return $user;
	}


/*--------------------------------Discounts--------------------------------*/

	function add_discount($user_id, $discount_content, $posted_time){
		$db = matanda_ph();
		$sql = "INSERT INTO discounts(user_id, discount_content, posted_time)VALUES(?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($user_id, $discount_content, $posted_time));
		$db = null;
	}

	function get_all_discounts(){
		$db = matanda_ph();
		$sql = "SELECT * FROM discounts AS d INNER JOIN user_accounts AS ua ON d.user_id = ua.user_id ORDER BY d.discount_id DESC";
		$query = $db->prepare($sql);
		$query->execute();
		$show = $query->fetchAll();
		$db = null;

		return $show;
	}

	function get_discount($discount_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM discounts AS d INNER JOIN user_accounts AS ua ON d.user_id = ua.user_id WHERE d.discount_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($discount_id));
		$getdiscount = $query->fetch();
		$db = null;

		return $getdiscount;
	}

	function edit_discount($discount_id, $discount_content){
		$db = matanda_ph();
		$sql = "UPDATE discounts SET discount_content=? WHERE discount_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($discount_content, $discount_id));
		$db = null;
	}

	function del_discount($discount_id){
		$db = matanda_ph();
		$sql = "DELETE FROM discounts WHERE discount_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($discount_id));
		$db = null;
	}

/*----------------------------------Senior Citizens Law----------------------------------*/

	function add_senior_law($user_id, $law_title, $law_content, $posted_time){
		$db = matanda_ph();
		$sql = "INSERT INTO senior_law(user_id, law_title, law_content, posted_time)VALUES(?, ?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($user_id, $law_title, $law_content, $posted_time));
		$db = null;
	}
	
	function get_all_senior_law(){
		$db = matanda_ph();
		$sql = "SELECT * FROM senior_law AS sl INNER JOIN user_accounts AS ua ON sl.user_id = ua.user_id ORDER BY sl.law_id DESC";
		$query = $db->prepare($sql);
		$query->execute();
		$show = $query->fetchAll();
		$db = null;

		return $show;
	}

	function get_senior_law($law_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM senior_law AS sl INNER JOIN user_accounts AS ua ON sl.user_id = ua.user_id WHERE sl.law_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($law_id));
		$getlaw = $query->fetch();
		$db = null;

		return $getlaw;
	}

	function edit_senior_law($law_id, $law_title, $law_content){
		$db = matanda_ph();
		$sql = "UPDATE senior_law SET law_title=?, law_content=? WHERE law_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($law_title, $law_content, $law_id));
		$db = null;
	}

	function del_senior_law($law_id){
		$db = matanda_ph();
		$sql = "DELETE FROM senior_law WHERE law_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($law_id));
		$db = null;
	}

/*----------------------------------Insurances----------------------------------*/

	// function add_insurance($user_id, $insurance_content){
	// 	$db = matanda_ph();
	// 	$sql = "INSERT INTO insurances(user_id, insurance_content)VALUES(?, ?)";
	// 	$query = $db->prepare($sql);
	// 	$query->execute(array($user_id, $insurance_content));
	// 	$db = null;
	// }

	// function get_all_insurances(){
	// 	$db = matanda_ph();
	// 	$sql = "SELECT * FROM insurances AS i INNER JOIN user_accounts AS ua ON i.user_id = ua.user_id ORDER BY i.insurance_id DESC";
	// 	$query = $db->prepare($sql);
	// 	$query->execute();
	// 	$show = $query->fetchAll();
	// 	$db = null;

	// 	return $show;
	// }

	// function get_insurance($insurance_id){
	// 	$db = matanda_ph();
	// 	$sql = "SELECT * FROM insurances WHERE insurance_id = ?";
	// 	$query = $db->prepare($sql);
	// 	$query->execute(array($insurance_id));
	// 	$getinsurance = $query->fetch();
	// 	$db = null;

	// 	return $getinsurance;
	// }

	// function edit_insurance($insurance_id, $insurance_content){
	// 	$db = matanda_ph();
	// 	$sql = "UPDATE insurances SET insurance_content=? WHERE insurance_id = ?";
	// 	$query = $db->prepare($sql);
	// 	$query->execute(array($insurance_content, $insurance_id));
	// 	$db = null;
	// }

	// function del_insurance($insurance_id){
	// 	$db = matanda_ph();
	// 	$sql = "DELETE FROM insurances WHERE insurance_id = ?";
	// 	$query = $db->prepare($sql);
	// 	$query->execute(array($insurance_id));
	// 	$db = null;
	// }


/*----------------------------------Health----------------------------------*/

	function add_health($user_id, $health_content, $posted_time){
		$db = matanda_ph();
		$sql = "INSERT INTO healths(user_id, health_content, posted_time)VALUES(?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($user_id, $health_content, $posted_time));
		$db = null;
	}

	function get_all_healths(){
		$db = matanda_ph();
		$sql = "SELECT * FROM healths AS h INNER JOIN user_accounts AS ua ON h.user_id = ua.user_id ORDER BY h.health_id DESC";
		$query = $db->prepare($sql);
		$query->execute();
		$show = $query->fetchAll();
		$db = null;

		return $show;
	}

	function get_health($health_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM healths AS h INNER JOIN user_accounts AS ua ON h.user_id = ua.user_id WHERE h.health_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($health_id));
		$gethealth = $query->fetch();
		$db = null;

		return $gethealth;
	}

	function edit_health($health_id, $health_content){
		$db = matanda_ph();
		$sql = "UPDATE healths SET health_content=? WHERE health_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($health_content, $health_id));
		$db = null;
	}

	function del_health($health_id){
		$db = matanda_ph();
		$sql = "DELETE FROM healths WHERE health_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($health_id));
		$db = null;
	}

/*----------------------------------Jobs----------------------------------*/

	function add_jobs($user_id, $company_name, $job_title, $job_description, $job_location, $office_location, $office_time, $office_day, $posted_time){
		$db = matanda_ph();
		$sql = "INSERT INTO jobs(user_id, company_name, job_title, job_description, job_location, office_location, office_time, office_day, posted_time)VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($user_id, $company_name, $job_title, $job_description, $job_location, $office_location, $office_time, $office_day, $posted_time));
		$db = null;
	}

	function get_all_jobs(){
		$db = matanda_ph();
		$sql = "SELECT * FROM jobs AS j INNER JOIN user_accounts AS ua ON j.user_id = ua.user_id ORDER BY j.job_id DESC";
		$query = $db->prepare($sql);
		$query->execute();
		$show = $query->fetchAll();
		$db = null;

		return $show;
	}

	function get_job($job_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM jobs AS j INNER JOIN user_accounts AS ua ON j.user_id = ua.user_id WHERE j.job_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($job_id));
		$getjob = $query->fetch();
		$db = null;

		return $getjob;
	}

	function edit_job($job_id, $company_name, $job_title, $job_description, $job_location, $office_location, $office_time, $office_day){
		$db = matanda_ph();
		$sql = "UPDATE jobs SET company_name=?, job_title=?, job_description=?, job_location=?, office_location=?, office_time=?, office_day=? WHERE job_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($company_name, $job_title, $job_description, $job_location, $office_location, $office_time, $office_day, $job_id));
		$db = null;
	}

	function del_job($job_id){
		$db = matanda_ph();
		$sql = "DELETE FROM jobs WHERE job_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($job_id));
		$db = null;
	}

	function get_job_aply($job_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM jobs AS j INNER JOIN user_accounts AS ua ON j.user_id = ua.user_id WHERE j.job_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($job_id));
		$jobapply = $query->fetch();
		$db = null;

		return $jobapply;
	}

/*----------------------------------Job Apply----------------------------------*/

	function add_job_apply($senior_id, $job_id, $applied_time){
		$db = matanda_ph();
		$sql = "INSERT INTO job_apply(senior_id, job_id, applied_time)VALUES(?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($senior_id, $job_id, $applied_time));
		$db = null;
	}

	function find_job_apply($senior_id, $job_id){
		$find = false;

		$db = matanda_ph();
		$sql = "SELECT * FROM job_apply WHERE senior_id =? AND job_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($senior_id, $job_id));
		$find = $query->fetch();
		$db = null;

		return $find;
	}

	function senior_apply_job($senior_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM job_apply AS ja INNER JOIN jobs AS j ON ja.job_id = j.job_id INNER JOIN senior_accounts AS sa ON ja.senior_id = sa.senior_id WHERE ja.senior_id = ? ORDER BY ja.apply_id DESC";
		$query = $db->prepare($sql);
		$query->execute(array($senior_id));
		$senior_apply = $query->fetchAll();
		$db = null;

		return $senior_apply;
	}

	function job_application_list($job_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM job_apply AS ja INNER JOIN jobs AS j ON ja.job_id = j.job_id INNER JOIN senior_accounts AS sa ON ja.senior_id = sa.senior_id WHERE ja.job_id = ? ORDER BY ja.apply_id DESC";
		$query = $db->prepare($sql);
		$query->execute(array($job_id));
		$applylist = $query->fetchAll();
		$db = null;

		return $applylist;
	}


/*----------------------------------Events----------------------------------*/

	function find_date_event($event_date){
		$find = false;

		$db = matanda_ph();
		$sql = "SELECT * FROM events WHERE event_date = ?";
		$query = $db->prepare($sql);
		$query->execute(array($event_date));
		$find = $query->fetch();
		$db = null;

		return $find;
	}

	function add_events($user_id, $event, $event_organizer, $event_description, $event_location, $event_date, $event_start, $event_end, $posted_time){
		$db = matanda_ph();
		$sql = "INSERT INTO events(user_id, event, event_organizer, event_description, event_location, event_date, event_start, event_end, posted_time)VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($user_id, $event, $event_organizer, $event_description, $event_location, $event_date, $event_start, $event_end, $posted_time));
		$db = null;
	}

	function get_all_events(){
		$db = matanda_ph();
		$sql = "SELECT * FROM events AS e INNER JOIN user_accounts AS ua ON e.user_id = ua.user_id ORDER BY e.event_id DESC";
		$query = $db->prepare($sql);
		$query->execute();
		$show = $query->fetchAll();
		$db = null;

		return $show;
	}

	function get_event($event_id){
		$db = matanda_ph();	
		$sql = "SELECT * FROM events AS e INNER JOIN user_accounts AS ua ON e.user_id = ua.user_id WHERE e.event_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($event_id));
		$getevent = $query->fetch();
		$db = null;

		return $getevent;
	}

	
	function edit_event($event_id, $event, $event_organizer, $event_description, $event_location, $event_date, $event_start, $event_end){
		$db = matanda_ph();
		$sql = "UPDATE events SET event=?, event_organizer=?, event_description=?, event_location=?, event_date=?, event_start=?, event_end=? WHERE event_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($event, $event_organizer, $event_description, $event_location, $event_date, $event_start, $event_end, $event_id));
		$db = null;
	}

	function del_event($event_id){
		$db = matanda_ph();
		$sql = "DELETE FROM events WHERE event_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($event_id));
		$db = null;
	}

	function get_event_join($event_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM events AS e INNER JOIN user_accounts AS ua ON e.user_id = ua.user_id WHERE e.event_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($event_id));
		$eventjoin = $query->fetch();
		$db = null;

		return $eventjoin;
	}

/*----------------------------------Join Events----------------------------------*/
	
	function add_join_event($senior_id, $event_id, $join_time){
		$db = matanda_ph();
		$sql = "INSERT INTO event_join(senior_id, event_id, join_time)VALUES(?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($senior_id, $event_id, $join_time));
		$db = null;
	}

	function find_event_join($senior_id, $event_id){
		$find = false;

		$db = matanda_ph();
		$sql = "SELECT * FROM event_join WHERE senior_id = ? AND event_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($senior_id, $event_id));
		$find = $query->fetch();
		$db = null;

		return $find;
	}

	function senior_join_event($senior_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM event_join AS ej INNER JOIN events AS e ON ej.event_id = e.event_id INNER JOIN senior_accounts AS sa ON ej.senior_id = sa.senior_id WHERE ej.senior_id = ? ORDER BY ej.join_id DESC";
		$query = $db->prepare($sql);
		$query->execute(array($senior_id));
		$senior_join = $query->fetchAll();
		$db = null;

		return $senior_join;
	}

	function event_join_list($event_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM event_join AS ej INNER JOIN events AS e ON ej.event_id = e.event_id INNER JOIN senior_accounts AS sa ON ej.senior_id = sa.senior_id WHERE ej.event_id = ? ORDER BY ej.join_id DESC";
		$query = $db->prepare($sql);
		$query->execute(array($event_id));
		$joinlist = $query->fetchAll();
		$db = null;

		return $joinlist;
	}

/*----------------------------------Services----------------------------------*/

	function find_date_service($service_date){
		$find = false;

		$db = matanda_ph();
		$sql = "SELECT * FROM services WHERE service_date = ?";
		$query = $db->prepare($sql);
		$query->execute(array($service_date));
		$find = $query->fetch();
		$db = null;

		return $find;
	}
	
	function add_services($user_id, $service, $service_offer, $service_date, $service_start, $service_end, $service_location, $posted_time){
		$db = matanda_ph();
		$sql = "INSERT INTO services(user_id, service, service_offer, service_date, service_start, service_end, service_location, posted_time)VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($user_id, $service, $service_offer, $service_date, $service_start, $service_end, $service_location, $posted_time));
		$db = null;
	}

	function get_all_services(){
		$db = matanda_ph();
		$sql = "SELECT * FROM services AS s INNER JOIN user_accounts AS ua ON s.user_id = ua.user_id ORDER BY s.service_id DESC";
		$query = $db->prepare($sql);
		$query->execute();
		$show = $query->fetchAll();
		$db = null;

		return $show;
	}

	function get_service($service_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM services AS s INNER JOIN user_accounts AS ua ON s.user_id = ua.user_id WHERE s.service_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($service_id));
		$getservice = $query->fetch();
		$db = null;

		return $getservice;
	}

	function edit_service($service_id, $service, $service_offer, $service_date, $service_start, $service_end, $service_location){
		$db = matanda_ph();
		$sql = "UPDATE services SET service=?, service_offer=?, service_date=?, service_start=?, service_end=?, service_location=? WHERE service_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($service, $service_offer, $service_date, $service_start, $service_end, $service_location, $service_id));
		$db = null;
	}	

	function del_service($service_id){
		$db = matanda_ph();
		$sql = "DELETE FROM services WHERE service_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($service_id));
		$db = null;
	}

	function get_service_acquire($service_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM services AS s INNER JOIN user_accounts AS ua ON s.user_id = ua.user_id WHERE s.service_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($service_id));
		$serviceacquire = $query->fetch();
		$db = null;

		return $serviceacquire;
	}

/*----------------------------------Services Acquired----------------------------------*/
	
	function add_acquire_service($senior_id, $service_id, $acquired_time){
		$db = matanda_ph();
		$sql = "INSERT INTO services_acquired(senior_id, service_id, acquired_time)VALUES(?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($senior_id, $service_id, $acquired_time));
		$db = null;
	}

	function find_service_acquire($senior_id, $service_id){
		$find = false;

		$db = matanda_ph();
		$sql = "SELECT * FROM services_acquired WHERE senior_id = ? AND service_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($senior_id, $service_id));
		$find = $query->fetch();
		$db = null;

		return $find;
	}

	function senior_acquire_service($senior_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM services_acquired AS a INNER JOIN services AS s ON a.service_id = s.service_id INNER JOIN senior_accounts AS sa ON a.senior_id = sa.senior_id WHERE a.senior_id = ? ORDER BY a.acquire_id DESC";
		$query = $db->prepare($sql);
		$query->execute(array($senior_id));
		$senior_acquire = $query->fetchAll();
		$db = null;

		return $senior_acquire;
	}

	function service_acquire_list($service_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM services_acquired AS a INNER JOIN services AS s ON a.service_id = s.service_id INNER JOIN senior_accounts AS sa ON a.senior_id = sa.senior_id WHERE a.service_id = ? ORDER BY a.acquire_id DESC";
		$query = $db->prepare($sql);
		$query->execute(array($service_id));
		$acquirelist = $query->fetchAll();
		$db = null;

		return $acquirelist;	
	}

/*----------------------------------Government Programs----------------------------------*/

	function add_program($user_id, $program_title, $program_description, $posted_time){
		$db = matanda_ph();
		$sql = "INSERT INTO govprograms(user_id, program_title, program_description, posted_time)VALUES(?, ?, ?, ?)";
		$query = $db->prepare($sql);
		$query->execute(array($user_id, $program_title, $program_description, $posted_time));
		$db = null;
	}

	function get_all_programs(){
		$db = matanda_ph();
		$sql = "SELECT * FROM govprograms AS g INNER JOIN user_accounts AS ua ON g.user_id = ua.user_id ORDER BY g.program_id DESC";
		$query = $db->prepare($sql);
		$query->execute();
		$show = $query->fetchAll();
		$db = null;

		return $show;
	}

	function get_program($program_id){
		$db = matanda_ph();
		$sql = "SELECT * FROM govprograms AS g INNER JOIN user_accounts AS ua ON g.user_id = ua.user_id WHERE g.program_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($program_id));
		$getprogram = $query->fetch();
		$db = null;

		return $getprogram;
	}

	function edit_program($program_id, $program_title, $program_description){
		$db = matanda_ph();
		$sql = "UPDATE govprograms SET program_title=?, program_description=? WHERE program_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($program_title, $program_description, $program_id));
		$db = null;
	}

	function del_program($program_id){
		$db = matanda_ph();
		$sql = "DELETE FROM govprograms WHERE program_id = ?";
		$query = $db->prepare($sql);
		$query->execute(array($program_id));
		$db = null;
	}

?>