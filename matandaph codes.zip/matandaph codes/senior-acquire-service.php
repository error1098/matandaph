<?php
	include_once("header3.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$service_id = $_GET['service_id'];
	$serviceacquire = get_service_acquire($service_id);

	$message = "";
	if(isset($_POST['submit']))
	{
		$service_id = $_POST['service_id'];
		$senior_id = $_POST['senior_id'];
		$acquired_time = $_POST['acquired_time'];

		$existing_acquire = find_service_acquire($senior_id, $service_id);
		if($existing_acquire){
			$message = "<div class='alert alert-danger'>You have already registered to this service.</div>";
		}
		else{
			add_acquire_service($senior_id, $service_id, $acquired_time);
			$message = "<div class='alert alert-info'>You have successfully registered.</div>";
		}
	}
?>
<div class="container">
	<?php echo $message; ?>
	<div class="thumbnail">
		<form method="post">
				<input type="hidden" name="service_id" value="<?php echo htmlentities($serviceacquire['service_id']) ?>">

				<div class="media">
					<div class="media-left">
						<?php
						if(!empty($serviceacquire['profilepicture'])){
						?>
						<span><img src="profilepictures/<?php echo htmlentities($serviceacquire['profilepicture']); ?>" class="profile-pic"></span>
						<?php
						}
						else{
						?>
						<span><img src="images/img_avatar3.png" class="profile-pic"></span>
						<?php } ?>
					</div>

					<div class="media-body">
						<h4 class="media-heading"> <span><b><?php echo htmlentities($serviceacquire['organization']); ?></b></span></h4>
						<p class="media-content"><?php echo htmlentities($serviceacquire['service']); ?></p>
						<p class="media-content">Service/s Offered:<br /><?php echo htmlentities($serviceacquire['service_offer']); ?></p>
						<p class="media-content">Service/s Schedule: <?php
							$date=date_create($serviceacquire['service_date']);
							echo htmlentities(date_format($date, "F d, Y, l"));
							echo " from ";
							$stime=date_create($serviceacquire['service_start']);
							echo htmlentities(date_format($stime, "h:i A"));
							echo " to ";
							$etime=date_create($serviceacquire['service_end']);
							echo htmlentities(date_format($etime, "h:i A"));
							echo " to be held at ";
							echo htmlentities($serviceacquire['service_location']); 
						?></p>
					</div>
				</div>
			</div>

			<div class="thumbnail">
			<input type="hidden" name="senior_id" value="<?php echo htmlentities($row['senior_id']); ?>">
			
			<div class="thumbnail">
				<div class="form-group">
					<label class="control-label">Senior Citizen's ID Number</label>
					<input type="text" name="seniorid" class="form-control" value="<?php echo htmlentities($row['seniorid']); ?>" readonly>
				</div>
			</div>

			<div class="row">
				<div class="col-sm-6">
					<div class="thumbnail">
						<div class="form-group">
							<label class="control-label">First Name</label>
							<input type="text" name="fname" class="form-control" value="<?php echo htmlentities($row['fname']); ?>" readonly>
						</div>

						<div class="form-group">
							<label class="control-label">Middle Name</label>
							<input type="text" name="mname" class="form-control" value="<?php echo htmlentities($row['mname']); ?>" placeholder="Enter middle name (optional)" readonly>
						</div>

						<div class="form-group">
							<label class="control-label">Last Name</label>
							<input type="text" name="lname" class="form-control" value="<?php echo htmlentities($row['lname']); ?>" readonly>
						</div>
					</div>
				</div>

				<div class="col-sm-6">
					<div class="thumbnail">
						<div class="form-group">
							<label class="control-label">Gender</label>
							<input type="text" name="gender" class="form-control" value="<?php echo htmlentities($row['gender']); ?>" readonly>
						</div>

						<div class="form-group">
							<label class="control-label">Date of Birth</label>
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<input type="text" name="bmonth" class="form-control" value="<?php echo htmlentities($row['bmonth']); ?>" readonly>
									</div>
								</div>

								<div class="col-sm-4">
									<div class="form-group">
										<input type="text" name="bdate" class="form-control" value="<?php echo htmlentities($row['bdate']); ?>" readonly>
									</div>
								</div>

								<div class="col-sm-4">
									<div class="form-group">
										<input type="text" name="byear" class="form-control" value="<?php echo htmlentities($row['byear']); ?>" readonly>
									</div>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="control-label">Birth Place</label>
							<input type="text" name="bplace" class="form-control" value="<?php echo htmlentities($row['bplace']); ?>" readonly>
						</div>
					</div>
				</div>
			</div>

			<div class="thumbnail">
				<div class="form-group">
					<label class="control-label">Region</label>
					<input type="text" name="region" class="form-control" value="<?php echo htmlentities($row['region']); ?>" readonly>
				</div>

				<div class="form-group">
					<label class="control-label">Province</label>
					<input type="text" name="provine" class="form-control" value="<?php echo htmlentities($row['province']); ?>" readonly>
				</div>

				<div class="form-group">
					<label class="control-label">City/Municipality</label>
					<input type="text" name="city" class="form-control" value="<?php echo htmlentities($row['city']); ?>" readonly>
				</div>

				<div class="form-group">
					<label class="control-label">Baranggay</label>
					<input type="text" name="baranggay" class="form-control" value="<?php echo htmlentities($row['baranggay']); ?>" readonly>
				</div>

				<div class="form-group">
					<label class="control-label">Sitio/Baranggay</label>
					<input type="text" name="sitio" class="form-control" value="<?php echo htmlentities($row['sitio']); ?>" readonly>
				</div>
			</div>

			<div class="form-group">
				<label class="control-label">Medical Record</label>
				<img src="seniormedrecord/<?php echo htmlentities($row['medrecord']); ?>" width="100%" height="100%">
			</div>

			<input type="hidden" name="acquired_time" value="<?php echo date('Y-m-d h:ia'); ?>">

			<div class="form-group">
				<input type="submit" name="submit" class="btn btn-primary" value="Register">
				<a href="senior-events.php" class="btn btn-default">Cancel</a>
			</div>
		</form>
	</div>
</div>