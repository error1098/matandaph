<?php
	include_once("header.php");

	if(!user_islogin()){
		header('Location: login.php');
		exit();
	}

	$event_id = $_GET['event_id'];
	$joinlist = event_join_list($event_id);
?>
<div class="container">
	<div class="thumbnail">
		<h3>List of Senior Citizens who join this event.</h3>
		<table class="table table-striped table-bordered table-condensed">
			<tr class="info">
				<td>Event</td>
				<td>Event Organizer</td>
				<td>Event Location</td>
				<td>Date and Time of Event</td>
				<td>Participat's Senior Citizen ID</td>
				<td>Name of Participant</td>
				<td>Age</td>
				<td>Address</td>
				<td>Date and Time of Registration</td>
			</tr>

			<?php
				if(count($joinlist)>0){
					foreach($joinlist as $row){
			?>
			<tr>
				<td>
					<?php echo htmlentities($row['event']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['event_organizer']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['event_location']); ?>
				</td>
				<td>
					<?php
						$date=date_create($row['event_date']);
						echo date_format($date, 'F d, Y');
						echo " from ";
						$stime=date_create($row['event_start']);
						echo date_format($stime, 'h:ia');
						echo " to ";
						$etime=date_create($row['event_end']);
						echo date_format($etime, 'h:ia');
					?>
				</td>
				<td>
					<?php echo htmlentities($row['seniorid']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['fname']." ".$row['mname']." ".$row['lname']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['age']); ?>
				</td>
				<td>
					<?php echo htmlentities($row['sitio']." ".$row['baranggay'].", ".$row['city']); ?>
				</td>
				<td>
					<?php 
						$date=date_create($row['join_time']);
						echo date_format($date, 'l F d, Y h:ia');
					?>
				</td>
			</tr>
			<?php
				}
			}
			else{
			?>
			<tr>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
				<td>No Entry</td>
			</tr>
			<?php } ?>
		</table>
	</div>
</div>